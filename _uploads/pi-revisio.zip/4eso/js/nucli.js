/* ============================================================================
   nucli.js · el poc que comparteixen tots els mòduls
   ----------------------------------------------------------------------------
   Aquest fitxer defineix l'únic objecte global del projecte, `CE`, i s'ha de
   carregar abans que cap mòdul.

   PER QUÈ SCRIPTS CLÀSSICS I NO MÒDULS ES
   Els mòduls ES (`type="module"`) no funcionen obrint el fitxer amb doble clic
   (`file://`) perquè el navegador els bloqueja per CORS. Aquest projecte s'ha
   de poder obrir des d'un llapis de memòria i sense servidor, igual que la
   resta del material del departament. Per això: scripts clàssics, cada mòdul
   dins d'una funció que s'executa tota sola, i un sol nom global.

   AFEGIR UN MÒDUL NOU
     1. crea js/moduls/<nom>.js amb l'embolcall
        (function(){ "use strict"; const {$, ...} = CE;  ...  CE.registra("id", inicia); })();
     2. posa-hi el <script src> a caixa-eines.html;
     3. afegeix el <button class="segment" data-tasca="n" data-mod="id">, amb el
        següent número lliure (surt als enllaços ?task=n i no es renumera mai),
        i la <section id="mod-id">.
     Si el mòdul té subtasques, cada panell va dins d'un
     <div class="subtasca" data-sub="n"> i s'hi crida CE.subtasques().
     No cal tocar app.js.

   LES FRASES NO VAN AL CODI NI AL MARCATGE
     Viuen a dades/textos.js. Al marcatge, data-text="1.2.titol"; al codi,
     CE.txt("1.2.encert", { nom: "√5" }). Així es poden canviar totes des d'un
     sol fitxer, o des de textos.html.

   ELS ALTRES DOS FITXERS COMPARTITS
     js/codi.js   el codi de verificació (CE.codi), que també llegeix verifica.html;
     ../comu/js/tasca.js  les tasques amb passos: inici, «pas X de Y», final, progrés
                  desat, retroacció literal (CE.tasca, CE.retroaccio) i el camí guiat
                  entre exercicis (CE.cami). És comú als dos cursos.
   ========================================================================== */

window.CE = (function () {
  "use strict";

  const $  = (s, arrel = document) => arrel.querySelector(s);
  const $$ = (s, arrel = document) => Array.from(arrel.querySelectorAll(s));

  /** Format català: coma decimal i sense zeros finals inútils.
      Compte: els zeros només es retallen DESPRÉS de la coma. Si es retallessin
      sempre, "20" es convertiria en "2" i les marques dels eixos mentirien. */
  function num(x, dec = 2) {
    if (x === 0) x = 0;                 // normalitza el -0 de resoldre equacions
    let s = Number(x).toFixed(dec);
    if (s.includes(".")) s = s.replace(/0+$/, "").replace(/\.$/, "");
    return s.replace(".", ",");
  }
  /** Com num(), però conservant tots els decimals demanats. */
  const fix   = (x, dec) => Number(x).toFixed(dec).replace(".", ",");
  const euros = x => fix(x, 2) + " €";

  /** localStorage protegit: en previsualitzacions o amb cookies bloquejades no
      existeix, i llavors es fa servir un objecte en memòria. Cada operació va
      dins d'un try: el disc ple o una pestanya privada no han de trencar l'app. */
  const memoria = (() => {
    try {
      localStorage.setItem("__p", "1"); localStorage.removeItem("__p");
      const prova = f => { try { return f(); } catch (e) { return null; } };
      return { get: k => prova(() => localStorage.getItem(k)),
               set: (k, v) => prova(() => localStorage.setItem(k, v)),
               esborra: k => prova(() => localStorage.removeItem(k)) };
    } catch (e) {
      const m = {};
      return { get: k => m[k] ?? null, set: (k, v) => { m[k] = v; },
               esborra: k => { delete m[k]; } };
    }
  })();

  /** Una data escrita sencera: «dilluns 21 de setembre de 2026».
      Lectura Fàcil demana els dies i els mesos amb lletres, sense xifres ni
      barres. Es fa a mà i no amb Intl perquè cada navegador hi posa comes o
      majúscules diferents, i la frase ha de ser sempre la mateixa. */
  const DIES = ["diumenge", "dilluns", "dimarts", "dimecres", "dijous", "divendres", "dissabte"];
  const MESOS = ["de gener", "de febrer", "de març", "d'abril", "de maig", "de juny", "de juliol",
                 "d'agost", "de setembre", "d'octubre", "de novembre", "de desembre"];
  const diaLlarg = d => DIES[d.getDay()] + " " + d.getDate() + " " + MESOS[d.getMonth()] +
                        " de " + d.getFullYear();

  /** El catàleg de tasques que poden donar codi de verificació. Cada mòdul hi
      diu el nom de la tasca, el dels seus casos i què vol dir cada recompte del
      codi. Així verifica.html pot posar nom a un codi sense duplicar res: carrega
      els mòduls i els llegeix d'aquí. */
  const cataleg = {};
  function registraCataleg(id, fitxa) { cataleg[id] = fitxa; }

  const SVGNS = "http://www.w3.org/2000/svg";
  /** Crea un node SVG. Els colors es passen dins de `style` amb var(--…) perquè
      el mode fosc funcioni sense duplicar codi. */
  function el(nom, atr = {}, text) {
    const n = document.createElementNS(SVGNS, nom);
    for (const k in atr) n.setAttribute(k, atr[k]);
    if (text != null) n.textContent = text;
    return n;
  }
  /** Instància d'un pictograma declarat als <symbol> de la pàgina. */
  function icona(id, mida) {
    const s = el("svg", { viewBox: "0 0 32 32", width: mida, height: mida });
    s.appendChild(el("use", { href: "#" + id }));
    return s;
  }

  /** Fila de pastilles amb selecció exclusiva. `aoTriar` rep (element, índex). */
  function pastilles(cont, llista, aoTriar, iniciX = 0) {
    cont.textContent = "";
    llista.forEach((it, i) => {
      const b = document.createElement("button");
      b.className = "pastilla";
      b.textContent = it.et;
      b.setAttribute("aria-pressed", i === iniciX);
      b.onclick = () => {
        $$(".pastilla", cont).forEach(x => x.setAttribute("aria-pressed", "false"));
        b.setAttribute("aria-pressed", "true");
        aoTriar(it, i);
      };
      cont.appendChild(b);
    });
  }

  /** Una frase de dades/textos.js, amb els forats {x} omplerts i els
      *asteriscs* convertits en negreta. La clau és «grup.nom»: txt("1.2.encert").
      Si la frase no hi és, retorna la clau entre claudàtors, que canta prou
      per adonar-se'n de seguida sense petar. */
  function txt(clau, valors) {
    const i = clau.lastIndexOf(".");
    const grup = (window.TEXTOS || {})[clau.slice(0, i)] || {};
    let t = grup[clau.slice(i + 1)];
    if (t == null) return "[" + clau + "]";
    if (valors) for (const k in valors) t = t.split("{" + k + "}").join(valors[k]);
    return t.replace(/\*([^*]+)\*/g, "<b>$1</b>");
  }

  /** Omple tots els elements amb data-text="clau" d'un tros de pàgina.
      Així el marcatge no porta cap frase a dins. */
  function omplirTextos(arrel) {
    $$("[data-text]", arrel).forEach(n => { n.innerHTML = txt(n.dataset.text); });
  }

  /** Panells numerats dins d'un mòdul: la «tasca 1» passa a ser 1.1, 1.2, 1.3…
      Cada panell és un <div class="subtasca" data-sub="n">, i la barra de dalt
      (.subbarra) només porta el nom, .sub-rotul.
      El mòdul només ha de dir què vol fer quan se n'ensenya un; el rètol i el
      botó «Exercici següent» van d'aquí. Cada mòdul deixa el seu control a
      CE.subs[id], per a les proves.
      Es pot cridar diverses vegades: el camí guiat no es duplica. */
  function subtasques(arrel, aoMostrar) {
    const panells = $$(".subtasca", arrel);
    if (!panells.length) return null;

    // EL CAMÍ GUIAT (6/11/2026): cap fletxa a la barra, que només porta el nom; un
    // sol botó a baix, «Exercici següent» (CE.cami, a ../comu/js/tasca.js). Un enllaç
    // a un exercici concret (?task=1.2) porta a aquell exercici i prou: sense botó.
    // CE.subDemanada el posa app.js abans d'obrir el mòdul.
    const rotul = $(".sub-rotul", arrel);
    const barra = $(".subbarra", arrel);
    const fixa = window.CE.subDemanada != null;
    if (barra && fixa) barra.classList.add("fixa");
    const id = arrel.id.replace("mod-", "");
    // el número de tasca surt de la pestanya, per no repetir-lo al marcatge
    const pestanya = $('.segment[data-mod="' + id + '"]');
    const tasca = pestanya ? pestanya.dataset.tasca : "";
    let ara = 1, guia = null;

    function mostra(n) {
      ara = Math.max(1, Math.min(panells.length, Number(n) || 1));
      panells.forEach(p => { p.hidden = Number(p.dataset.sub) !== ara; });
      if (rotul) {
        const nom = txt(tasca + "." + ara + ".nom").replace(/^\[.*\]$/, "");
        rotul.dataset.nom = nom;
        rotul.dataset.escrit = "0|" + nom;
        rotul.innerHTML = "<b>" + tasca + "." + ara + "</b> " + nom;
      }
      if (aoMostrar) aoMostrar(ara);
      if (guia) guia();
    }

    const control = { mostra, quantes: panells.length, actual: () => ara };
    guia = window.CE.cami ? window.CE.cami(arrel, control, fixa) : null;
    (window.CE.subs = window.CE.subs || {})[id] = control;
    return control;
  }

  const moduls = {};
  /** Cada mòdul es dona d'alta amb el seu identificador i la funció d'arrencada.
      La funció s'ha de poder cridar diverses vegades sense duplicar res. */
  function registra(id, inicia) {
    if (moduls[id]) console.warn("CE: el mòdul «" + id + "» ja estava registrat");
    moduls[id] = inicia;
  }

  return { $, $$, num, fix, euros, memoria, el, icona, pastilles,
           txt, omplirTextos, subtasques, moduls, registra,
           diaLlarg, cataleg, registraCataleg,
           // les claus de la memòria del navegador: les llegeix ../comu/js/tasca.js
           prefix: "pi-" };
})();

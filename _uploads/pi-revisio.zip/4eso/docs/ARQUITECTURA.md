# Arquitectura

> **Des del 6/11/2026**, el mapa del lloc, la closca de pantalla (capçalera, botons, colors) i les seves regles són a [`comu/docs/SITE-MAP.md`](../../comu/docs/SITE-MAP.md). Aquest document parla del que és propi d'aquest curs; on parli de pàgines o enllaços d'abans (`fitxes/`, la caixa sencera, `?task=n`, «← unitat N»), mana el mapa.

Com està muntat el projecte i com ampliar-lo sense trencar res.

---

## 1. Les decisions de partida

**Estàtic i sense pas de compilació.** Igual que la resta del material del departament.
S'ha de poder obrir des d'un llapis de memòria, sense servidor i sense connexió.

**Scripts clàssics, no mòduls ES.** Els mòduls ES (`type="module"`) els bloqueja el
navegador per CORS quan s'obre un fitxer amb doble clic (`file://`). Per això: scripts
clàssics, un sol nom global (`CE`) i cada mòdul dins d'una funció que s'executa tota
sola. L'encapsulació la fa l'embolcall, no el sistema de mòduls.

**Cap dependència externa.** Ni CDN, ni fonts remotes, ni biblioteques. El filtre del
centre bloqueja recursos externs, i a més volem que funcioni sense xarxa.

**Dues paletes, mai barrejades.** El paper és blanc i negre; la pantalla té color.
Totes dues viuen a `css/tokens.css`, en seccions separades i documentades.

**Cap `@import` als fulls d'estil.** Encadenar CSS obliga el navegador a baixar-se un
fitxer, llegir-lo, descobrir l'import i baixar-se el segon: dues anades i tornades en
sèrie bloquejant el pintat. `tokens.css` s'enllaça des de l'HTML, abans del full que el
fa servir. El test ho comprova.

---

## 2. Els fitxers

Tot és dins de `4eso/`. `_headers`, `robots.txt`, `404.html` i `favicon.svg` són a l'arrel del
repositori, perquè són de tot el lloc, i el motor dels exàmens DOCX és a
`comu/examens/nucli.js`.

```
├── index.html              pàgina del professorat: caixa sencera, frases, codis
├── uN/index.html             la pàgina d'una unitat (?ud=N): fitxes, targetes, quadern, caixa i detall; la fa ../comu/js/unitat.js
├── eines.html        l'aplicació: només marcatge
│
├── css/
│   ├── tokens.css          variables: paleta de paper, paleta de pantalla, mode fosc
│   ├── fitxa.css           les fitxes imprimibles          (importa tokens)
│   ├── quadern.css         el quadern d'activitats: filtre i impressió (després de fitxa.css)
│   ├── app.css             la caixa d'eines                (importa tokens)
│   └── lloc.css            index.html i uN/index.html        (importa tokens)
│
├── verifica.html           pàgina del professorat: llegir els codis de verificació
│
├── js/
│   ├── nucli.js            l'objecte global CE i el registre de mòduls
│   ├── codi.js             el codi de verificació: fer-lo i llegir-lo
│   ├── app.js              navegació de la caixa d'eines
│   ├── quadern.js          el filtre del quadern d'activitats (apartats i repte)
│   └── moduls/             un fitxer per mòdul, deu en total
│   (el motor de les tasques tancades i la veu són a ../comu/js/tasca.js i veu.js, comuns a
│    tots els cursos des del 6/11/2026; el prefix de la memòria, CE.prefix = «pi-», el posa nucli.js)
│
├── dades/
│   └── unitats.js          font única: les set unitats amb tota la metadada, i les targetes
│
├── fitxes/                 ud1.html … ud7.html, i udN-repas.html (les fa generadors/gen_repas.py)
├── quadern/                udN.html, el quadern d'activitats amb filtre (el fa generadors/gen_quadern.py
│                           a partir de generadors/quadern/udN.py; de moment, només la UD3)
├── targetes/               les tres targetes de consulta, a doble cara
├── generadors/             els scripts Python que dibuixen els SVG i fan els PDF,
│                           i examens/udN.js, el contingut de cada examen DOCX
├── eines/
│   ├── comprova.py         el test del projecte, sense dependències
│   ├── mesura.py           si cada pàgina cap en un A4          (WeasyPrint)
│   ├── prova_caixa.py      la caixa, de punta a punta           (Playwright)
│   ├── prova_quadern.py    el filtre dels quaderns              (Playwright)
│   ├── empremta.py         l'empremta de cada PDF, per saber si és vell
│   └── auditoria.py        dianes i contrast dins del navegador (Playwright)
└── docs/                   la documentació
```

**Qui depèn de qui.** Les fletxes van només en una direcció:

```
tokens.css ← s'enllaça des de l'HTML, ABANS de fitxa.css / app.css / lloc.css
nucli.js   ← codi.js, ../comu/js/tasca.js, ../comu/js/veu.js ← js/moduls/*.js ← app.js
textos.js  ← ../comu/js/tasca.js, js/moduls/*.js
unitats.js ← ../comu/js/portada.js, ../comu/js/unitat.js
```

`app.js` no sap res del contingut dels mòduls: només els identificadors, que llegeix de
l'atribut `data-mod` del marcatge. `unitat.js` (a `comu/js/`) no sap res de cada unitat: les
llegeix de `dades/unitats.js`.

---

## 3. El nucli: `CE`

`js/nucli.js` defineix l'únic objecte global i s'ha de carregar primer.

| | |
|---|---|
| `$`, `$$` | seleccionar un node o una llista |
| `num(x, dec)` | format català, coma decimal, sense zeros finals inútils |
| `fix(x, dec)` | com `num()` però conservant tots els decimals |
| `euros(x)` | `fix(x, 2) + " €"` |
| `el(nom, atributs, text)` | crea un node SVG |
| `icona(id, mida)` | instancia un pictograma declarat als `<symbol>` de la pàgina |
| `pastilles(cont, llista, aoTriar, inicial)` | fila de botons amb selecció exclusiva |
| `memoria` | `localStorage` protegit, amb objecte en memòria si no hi és |
| `registra(id, inicia)` | dona d'alta un mòdul |

**Detall que sembla trivial i no ho és.** `num()` només retalla els zeros que hi ha
*després* de la coma. Si els retallés sempre, «20» es convertiria en «2» i les marques
dels eixos mentirien. Va passar; per això hi ha el comentari al codi.

**Colors dins dels SVG.** Es passen com `style="fill:var(--blau)"` i no com atribut
`fill`. Així el mode fosc funciona sense duplicar codi.

---

## 4. Afegir un mòdul a la caixa d'eines

Tres passos i no cal tocar `app.js`.

**1.** Crea `js/moduls/<nom>.js`:

```js
(function () {
  "use strict";
  const { $, $$, num, euros, el, pastilles } = CE;

  function inicia() {
    if ($("#xxx-pastilles").children.length) return;   // idempotent: es pot cridar dos cops
    // …
  }

  CE.registra("xxx", inicia);
})();
```

**2.** A `eines.html`, el botó i la secció. El botó porta el següent número de
tasca lliure:

```html
<button class="segment" role="tab" data-tasca="8" data-mod="xxx" aria-selected="false">Nom</button>
...
<section id="mod-xxx" class="modul" hidden> … </section>
```

**3.** El `<script src>`, **abans** de `js/app.js`, que ha d'anar sempre l'últim.

**La funció d'arrencada s'ha de poder cridar diverses vegades.** `app.js` la crida cada
vegada que s'obre la pestanya. Per això tots els mòduls comencen comprovant si ja estan
muntats.

**Convenció que fan servir tots.** El mòdul **s'obre ja resolt** amb un exemple marcat
amb `<span class="marca">Exemple</span>`, i un botó el buida per al cas de l'alumnat.
És el mateix criteri que «el primer apartat ja resolt» de les fitxes.

**Enllaços filtrats per a l'alumnat.** `eines.html?task=n` mostra només la tasca 0
(la Calculadora), sempre la primera, i la tasca `n`, que és la que s'obre. Sense `?task`
es veu la caixa sencera; amb `?task=0` o un número que no existeix, només la Calculadora.
En mode filtrat no es fa servir el mòdul desat a `localStorage` i s'amaga l'enllaç a
l'inici. Els números viuen a l'atribut `data-tasca` i ja són en enllaços enviats: **no es
renumeren mai**, ni quan es treu un mòdul. El test comprova que no se'n repeteixi cap i que
la tasca 0 vagi la primera.

---

## 3b. Les frases: `dades/textos.js`

**Cap frase que llegeixi l'alumnat viu al codi ni al marcatge.** Totes són a
`dades/textos.js`, en un sol objecte. El marcatge hi apunta i el codi les demana:

```html
<h2 data-text="1.2.titol"></h2>
```
```js
avis.innerHTML = txt("1.2.encert", { nom: "√5", baix: 2, alt: 3 });
```

`CE.omplirTextos(arrel)` omple tots els `[data-text]` d'un tros de pàgina, i es
crida un cop quan arrenca el mòdul.

**Dues convencions** que fan que les frases es puguin editar sense saber
programar: `*entre asteriscs*` surt en negreta, i `{això}` és un forat que
s'omple amb una dada. Si una clau no existeix, `txt()` retorna `[1.2.titol]`, que
canta prou per adonar-se'n de seguida sense petar.

**`textos.html`** és una pàgina per al professorat: ensenya cada frase en un camp
amb una nota de on surt, avisa en vermell si hi falta un forat, i dona el fitxer
ja muntat per substituir `dades/textos.js`. La capçalera i el bloc `TEXTOS_GUIA`
del fitxer es tornen a escriure tal com són: la pàgina només canvia les frases.

**On no van les frases.** Els `aria-label` es queden al marcatge: són text
d'accessibilitat, no el que es llegeix a la pantalla. I les dades que mouen un
càlcul —els preus del material de l'exercici 1.4, per exemple— es queden al codi;
de `textos.js` en surt només el nom, de manera que canviar-ne el text no pot fer
que l'etiqueta digui un preu que no és.

**El test** comprova que tota clau que es demana existeixi, que cada frase tingui
la seva línia a `TEXTOS_GUIA` i que no n'hi hagi cap sense fer servir. Compte: hi
ha claus que es munten (`"1.3." + quina`, o el `.nom` que llegeix el nucli), i la
comprovació les té en compte; si no, delataria vint frases que sí que s'usen.

## 4a. Subtasques: una tasca partida en 1.1, 1.2, 1.3…

Un mòdul pot tenir diversos exercicis dins. La navegació és genèrica i està al
nucli, de manera que qualsevol mòdul ho pot fer sense codi propi.

**Marcatge.** Dins de la `<section>`, una barra i els panells:

```html
<div class="subbarra">
  <button class="btn tenyit mini sub-enrere" aria-label="Exercici anterior">‹</button>
  <span class="sub-rotul"></span>
  <button class="btn mini sub-avant" aria-label="Exercici següent">›</button>
</div>
<div class="subtasca" data-sub="1" data-nom="Nom curt">…</div>
<div class="subtasca" data-sub="2" data-nom="Nom curt" hidden>…</div>
```

**Al mòdul**, una sola crida. La funció d'arrencada de cada panell es crida el
primer cop que s'ensenya, no abans:

```js
const ARRENCA = { 1: iniciaA, 2: iniciaB, 3: iniciaC };
const jaFetes = new Set();
let subActual = null;

function inicia() {
  const subs = CE.subtasques($("#mod-xxx"), n => {
    subActual = n;
    if (!jaFetes.has(n)) { ARRENCA[n](); jaFetes.add(n); }
  });
  subs.mostra(subActual || CE.subDemanada || 1);
}
```

`subActual` fa que, en tornar a la pestanya, es reprengui on s'estava.

**El camí guiat (6/11/2026).** No hi ha fletxes: la barra només diu on s'és, i un sol botó a
baix, «Exercici següent», porta a l'exercici següent; en una tasca tancada surt quan s'acaba (`CE.cami`,
a `../comu/js/tasca.js`). **Enllaços.** `?task=1` obre la tasca 1 per l'exercici 1, amb el botó;
**`?task=1.3` obre directament el tercer, i prou**: la barra diu on s'és, però el botó no hi és
(`.subbarra.fixa`). És el que permet
enviar un exercici concret i no la tasca sencera, sense que l'alumnat es perdi
pels del costat. És la regla N de `1eso/` (29/9/2026). Si el número no existeix o
el format no és `n` ni `n.m`, es cau a la tasca 0, com sempre.

**El número de subtasca no es renumera mai**, per la mateixa raó que el de tasca:
els enllaços viuen en fulls fotocopiats. Si una subtasca es retira, el seu número
es deixa buit. El test comprova que vagin seguides des de l'1 i que cadascuna
tingui `data-nom`.

## 4c. El valor posicional i el sistema mètric (1.5 i 1.6)

Aquests dos exercicis són **el mateix objecte vist dues vegades**, i per això van
seguits: canviar d'unitat no canvia la llargada, només mou la coma dins de la
taula de columnes.

- **1.5** ensenya la taula (centenes → mil·lèsimes) amb una xifra per columna.
  Tocar-ne una diu què val, i a sota hi ha la descomposició: `3 + 0,4 + 0,07`.
  Un nombre decimal és una suma, i aquí es veu.
- **1.6** posa la mateixa mesura a l'escala `km hm dam m dm cm mm`. Es toca un
  graó i la mesura es reescriu; es diu quants graons s'han mogut i cap a on va
  la coma.

**Res de tot això fa servir aritmètica de coma flotant.** Les mesures es guarden
com a **xifres + exponent** (`{ d: "347", e: -2 }` és 3,47) i la funció
`decimal(xifres, exp)` escriu el resultat movent la coma sobre la cadena. Dos
motius: és exactament l'operació que s'està ensenyant, i és exacta. Amb càlcul
normal, `3,47 × 10` dona `34.699999999999996` i la pantalla mentiria.

Dos casos que s'han hagut d'arreglar i que convé no desfer:

- `decimal("0", exp)` retornava `"00"` per a l'exponent 1, i tocant el zero de
  105,3 deia «val 00». El zero val zero a qualsevol columna.
- A 1.4, el preu del material no surt de `textos.js` sinó del codi, perquè
  canviar-ne el text no pugui fer que l'etiqueta digui un preu que no és.

Les 28 conversions possibles (4 mesures × 7 unitats) es comproven contra el
càlcul normal i coincideixen totes.

## 4b. El mòdul de la calculadora: un pas, una pantalla

Aquest mòdul té una restricció que els altres no tenen: **un pas ha de cabre sencer
a la finestra, sense fer scroll**. El bucle és «prem la tecla a la calculadora de
veritat i avança aquí», i si per veure el teclat i el botó cal moure la pàgina, es
perd el lligam entre les dues coses.

**Dues columnes.** `#mod-calc` és una graella: el triador de casos va en un
`<aside class="triador">` enganxat a l'esquerra i el pas a la dreta. Amb el triador
a sobre, el pas començava a 190 px de l'inici i no hi cabia. Per sota de 46 rem
les dues columnes s'apilen i les pastilles tornen a fila.

**Ordre dins del pas:** el rètol de progrés, la frase que diu el bucle, la pantalla
de la calculadora, els botons i, al final, el mapa del teclat, que serveix per
**situar** la tecla a l'aparell. El pas fa uns 440 px.

**La tecla és EXE, no «=».** El mòdul està contrastat amb el manual oficial de la
fx-82SP CW: la tecla d'executar es diu EXE i no hi ha cap tecla `=`; la pantalla
dona 10 xifres (√7 surt `2.645751311`); en escriure, el decimal **sempre** és un
punt, i el menú «Símbolo decimal» només canvia com surten els resultats. Dues
constants a dalt del mòdul recullen com estan configurades les calculadores del
centre: `ENTRADA_SORTIDA` (`"E Mat/S Decimal"`, el que recomanem, o `"E Mat/S Mat"`,
el de fàbrica, que afegeix SHIFT abans d'EXE quan el resultat no és sencer) i
`SEP_DECIMAL`. La tecla `FORMAT` ja no surt al mapa: obre un menú del qual no es pot
estar segur sense l'aparell a la mà, i amb `E Mat/S Decimal` no cal. Una
autocomprovació avisa per consola si un cas demana una tecla que no és al mapa.

**El teclat de l'ordinador.** Prémer la mateixa tecla al teclat físic avança el pas
(mapa `TECLAT`: xifres, la coma també val per al punt, `* x /` `:` `+ -`, Retorn per
EXE, Retrocés per DEL, Esc per AC, i les fletxes ← → per moure's entre passos). Una
tecla equivocada no fa res i no diu res: aquí no s'avalua. En triar un cas, el focus
va al botó del pas; si no, el Retorn tornava a disparar la pastilla i el cas
començava de nou.

**Dues coses criden l'atenció sense molestar.** La tecla del pas batega
(`@keyframes bategar`) i **es pot tocar per avançar**, igual que el botó: així el
gest de «prem aquesta tecla» i el d'avançar són el mateix. El botó fa una sacsejada
curta cada 3,4 s amb un anell que s'esvaeix (`@keyframes crida`). Totes dues
s'aturen amb `prefers-reduced-motion`.

**Mides que no s'han de tocar sense demanar-ho.** La pantalla de la calculadora i
les tecles d'operació tenen mides fixades pel docent: l'entrada un 30 % més gran que
la base, el rètol del resultat un 10 % més baix i les tecles `× ÷ + − Ans =` un 30 %
més grans. El cos de la pantalla és gris fosc, no negre.

**Què no hi ha, i és a posta.** No hi ha cap rètol que expliqui pas per pas què vol
dir la tecla: hi era i es va treure perquè afegia text a una pantalla que n'havia de
tenir poc. Qui guia és la tecla que batega, la frase del bucle i el rètol
«Tecla 3 de 7: prem ×». L'única nota que queda és la de la coma decimal, i viu a la
columna del triador, on no competeix amb el pas.

---

## 4d. Les tasques tancades: `../comu/js/tasca.js`

Cinc tasques (Calculadora, 1.2, 1.3, Paràboles i Equacions) comparteixen un motor.
Abans, cada mòdul feia el seu comptador i el seu «Un altre» i la tasca no s'acabava
mai: no hi havia manera de saber si algú havia fet cinc exercicis o cinquanta, ni de
dir-li que ja estava. El motor dona quatre coses:

**1 · Un principi i un final visibles.** El rètol `Inici ● ● ○ ○ ○ Final` amb
«Pas 2 de 5» al costat. El pas d'ara és un anell més gran i els fets són cercles
plens: la diferència es veu per la forma, no només pel color.

**2 · Un sol pas a la vista.** El mòdul pinta el pas i prou. A les Paràboles això vol
dir que el dibuix es buida entre passos: el vèrtex que s'ha trobat no es queda a la
pantalla mentre es busquen els talls. Al final, el dibuix sencer les ajunta totes,
que és la conclusió.

**3 · La retroacció sempre amb la mateixa forma**, amb `CE.retroaccio(node, tipus,
cos, pista)`:

| tipus | què escriu |
|---|---|
| `encert` | «Correcte.» i què ha passat |
| `error` | «Incorrecte.» + «Ara provem-ho d'una altra manera.» + una pista que és un camí diferent |
| `mostra` | «Incorrecte.» i la resposta, quan ja no queden intents |
| `be` / `no` | un estat que no és una resposta: «x = 2 no és una solució» |

La paraula «Incorrecte» hi és a posta i no s'ha de suavitzar: el que suavitza és el
que ve després. A les Equacions **provar un valor no és contestar**, i per això allà
no surt mai «Incorrecte».

**4 · Un final amb resum i codi.** En acabar, el pas es canvia per una targeta:
«Has acabat», la frase del resultat, els recomptes (quants passos, quants al primer
intent, quants amb pista, quants amb la resposta ensenyada), el **codi de
verificació** i dos botons, imprimir el resum i tornar a començar. Imprimir posa una
còpia de la targeta a `#zona-impressio`, fill directe del `<body>`, i el `@media
print` d'`app.css` amaga tota la resta.

**La represa.** El progrés es desa a `localStorage` amb la clau `pi-tasca:1.2` i
caduca als 30 dies. **Mai es reprèn sol**: en tornar, la tasca pregunta, diu el dia
en què es va desar i ofereix «Comença de nou», perquè l'ordinador pot ser compartit.
Si no hi ha cap pas fet, no pregunta res i comença.

### `js/codi.js`, el codi de verificació

`K7Q-M2X-9RT`: nou caràcters en Base32 de Crockford, sense I, L, O ni U perquè no es
puguin confondre en copiar-los a mà. Hi caben la tasca, la subtasca, el cas, el dia
del curs i tres recomptes, més 9 bits de control. La càrrega es barreja amb una
màscara reversible treta del control; sense això, tots els codis d'una mateixa tasca
començaven igual i semblaven un error.

**Què és i què no és.** No és un xifratge i no ho ha de semblar: detecta un caràcter
mal copiat (en falla un de cada 280, mesurat provant-los tots) i fa que inventar-se'n
un no sigui fàcil. Res més. `verifica.html` el llegeix, un o molts alhora, tolerant
minúscules, guions i espais, i posa nom a la tasca i al cas amb el catàleg que
registren els mateixos mòduls (`CE.registraCataleg`).

## 5. Afegir una unitat

**1.** Una entrada a `dades/unitats.js`. Els índexs es refan sols.
**2.** La fitxa a `uN/fitxa.html`, amb `<link rel="stylesheet" href="../css/fitxa.css">`.
**3.** Si porta dibuixos nous, un generador a `generadors/`.

L'esquelet d'una fitxa:

```html
<div class="full">
  <div class="previ">Cinc minuts abans, a l'aula de suport: <b>material</b></div>
  <h1>Un títol que és una pregunta</h1>
  <p class="nom">Nom: <span></span></p>
  <div class="obertura">…<div class="q">Què hi veus? <span class="com">Digues-ho o assenyala-ho.</span></div></div>
  <div class="figura"> <!-- l'SVG --> </div>
  <p>La frase que anomena la cosa, SEMPRE després del dibuix.</p>
  <div class="pag">Unitat N · pàgina 1</div>
</div>
```

L'ordre importa: pregunta → dibuix → nom de la cosa. Si la frase va abans del dibuix,
la pregunta d'obertura queda anul·lada. Va passar a tres fitxes i es va corregir.

---

## 6. Els gràfics

**No es dibuixen a mà.** Els SVG de les fitxes els generen els scripts de `generadors/`,
perquè els vèrtexs, les barres, els punts i les marques dels eixos caiguin exactament on
toca. Cada script **imprimeix les seves pròpies comprovacions numèriques** en executar-se.

| Script | Què dibuixa |
|---|---|
| `gen_grafics.py` | les paràboles de la U5 |
| `gen_grafics2.py` | diagrames de punts, barres i arbres de la U6 i la U7 |
| `gen_grafics3.py` | barres de percentatge de la U2 i model d'àrea de la U6 |
| `gen_grafics4.py` | doble recta de la U2, repartiment de la U6, barra de la U7 |
| `gen_grafics5.py` | doble recta del mapa (U3) i les dues paràboles de «A la vida de cada dia» (U5) |
| `posa_grafics.py` | executa els cinc `gen_grafics*.py` i posa cada gràfic a la seva fitxa |
| `gen_repas.py` | les set fitxes de repàs (`uN/repas.html`): el dibuix de la pàgina 1 de la fitxa, «Una de cada» i «Què he après?» |
| `gen_pdf.py` | els PDF de totes les fitxes (alumnat i solucionari) i de les targetes (un per targeta, amb les dues cares) |

**Com arriben a les fitxes.** A cada fitxa, cada gràfic va entre dos marcadors:
`<!--grafic:PILOTA_GRAN--><svg …>…</svg><!--/grafic-->`. `posa_grafics.py` torna a fer
tots els gràfics i substitueix el que hi ha entre els marcadors. Si un marcador anomena un
gràfic que no existeix, o un gràfic no surt a cap fitxa, ho diu i no toca res. Abans
(fins al 29/9/2026) s'enganxaven a mà.

**La lletra dels gràfics.** 12 pt com a mínim tal com surten al PDF (vegeu
`CRITERIS-DISSENY.md`, regla 4). A `gen_grafics.py`, la funció `graf()` té el paràmetre `fs`:
20 per als gràfics d'amplada sencera i 28 per als que van de costat. Les marques dels eixos
són els múltiples del pas (`marques()`): abans es comptava des de l'extrem, i amb un eix que
començava a −0,5 els números sortien desplaçats («−0, 0, 2, 2, 4, 4»).

## 6b. Els PDF i l'alçada de les pàgines

Cada bloc `.full` de l'alumnat ha de ser **exactament una pàgina A4**. Això mai s'havia
verificat amb un motor de paginació, i quan es va fer resulta que set pàgines vessaven,
entre mig centímetre i vuit.

`eines/mesura.py` renderitza cada pàgina en un full molt alt, mira on acaba el contingut
i ho compara amb els 27,1 cm útils d'un A4. També mira l'amplada (29/9/2026): el que es
veu no pot sortir més de mig centímetre pel marge dret, i el text d'una opció per marcar no
pot sortir de la seva capsa. `generadors/gen_pdf.py` falla si el PDF de l'alumnat no té
tantes pàgines com blocs té la fitxa, i si un PDF amb text manuscrit no porta Caveat.

L'ajust es va fer al `@media print` de `fitxa.css`: dibuixos més petits i ritme vertical
més estret. **El cos de 14 pt no s'hi toca.** Si una pàgina no cap, s'arregla la fitxa.

Els generadors de gràfics escriuen un `.json` amb els SVG, i `posa_grafics.py` els posa
a les fitxes entre els marcadors `<!--grafic:NOM-->` i `<!--/grafic-->` (vegeu l'apartat 6).
Els marcadors `§NOM§` i `aplica_millores.py` de què parlaven versions anteriors ja no hi
són. Els comentaris `<!--§obertura p.1§-->` que queden a les fitxes només són de traça.

---

## 6c. La veu: `../comu/js/veu.js`

Cada targeta amb títol porta, a dalt a la dreta, un botó petit i gris amb un altaveu. En
tocar-lo, el navegador llegeix la targeta en veu alta i marca el que llegeix; tornar-lo a tocar
la para, i tocar qualsevol altre botó també. És un sol fitxer per a tots els cursos, a `comu/js/`.
Fa servir la síntesi de veu del navegador (Web Speech API): no cal xarxa ni servidor. Si el
navegador no en té, o si no té cap veu catalana (6/11/2026), el botó no surt.

**Com llegeix, i per què.**

- **En català**, amb la millor veu catalana de l'ordinador: primer les «naturals» (Edge en porta
  dues, Joana i Enric), després qualsevol altra. Si l'ordinador no en té cap, el navegador fa
  servir la que té.
- **A poc a poc**: velocitat 0,85 (la normal és 1). Més lenta, la veu s'arrossega i es fa
  estranya; més ràpida, no dona temps.
- **Amb el to natural** (1). Un to més agut sona infantil.
- **Un bloc cada vegada**, amb una pausa de 450 ms entre bloc i bloc: el títol, la consigna,
  «Pas 2 de 5», la pregunta, cada línia de la lectura, l'avís. Una idea, i un silenci.
- **Només quan es demana, i sempre igual.** Res no parla sol en obrir la pàgina.
- **Els símbols, amb paraules**: «3 · 4 = 12» es diu «3 per 4 és igual a 12»; «7²», «7 al
  quadrat»; «km²», «quilòmetres quadrats»; «√7», «l'arrel quadrada de 7». El punt volat de
  «col·lecció» no es toca. Les fraccions i les expressions amb forat ja porten la seva lectura a
  `aria-label` (`role="img"`), i es diu aquesta: «tres vuitens».
- **No es llegeix** el que no és text per llegir: els botons, els dibuixos (`svg`), l'etiqueta
  «Exemple» (`.marca`) ni l'«Inici» i el «Final» del rètol de progrés (`.fita`).
- **Les caselles i els desplegables** (6/11/2026). Si hi ha alguna cosa escrita o triada, es diu
  seguit, dins de la frase: «El nombre √7 és entre 2 i 3» es diu «El nombre l'arrel quadrada de 7
  és entre 2 i 3». Si són buits, o el desplegable encara diu «…», es fa una pausa curta (una coma
  al text que es diu): «El nombre, és entre, i.». Abans se saltaven i la frase sortia enganxada.
  Només `input` de text o de número i `select`; els altres camps se salten com sempre. Ara n'hi ha
  a les pestanyes «Com ho dic», «Escales» i «Percentatges». El retolador
  travessa la casella amb l'alçada d'una línia de text, sense engreixar-se.

**Com marca el que llegeix** («focus i retolador que omple», 6/11/2026). Dues coses, i prou:

- **Focus.** El bloc que sona (`.veu-bloc`) queda com és, i tot el que l'envolta dins de la
  targeta s'esvaeix fins a l'opacitat 0,3 (`.veu-apagat`, amb una transició suau de `.veu-fos`).
  Funciona a tots els navegadors i amb totes les veus.
- **Retolador que omple.** Si la veu diu per on va (Edge i Safari ho fan; la veu de Google
  d'Android i moltes de Chrome, no), una franja groga omple la línia de l'esquerra a la dreta
  fins al final de la paraula que sona, amb una transició lineal que dura el que es triga a dir
  la paraula. No salta de paraula en paraula: avança. Quan la veu no diu per on va, no s'endevina
  res: només hi ha el focus.

La franja no és dins del text: és una capa a part (`.veu-capa`, posada al `body`) amb un `div`
per línia (`.veu-retolador`), col·locat amb `Range.getClientRects()` i barrejat amb
`mix-blend-mode: multiply` perquè la lletra quedi negra a sobre del groc. Es fa així perquè
`::highlight` no es pot animar. Si es canvia la mida de la finestra, la franja s'esborra i torna a
sortir a la paraula següent. Amb `prefers-reduced-motion`, la franja creix sense transició.
Els estils són al final de `css/app.css`.

Història: la primera versió marcava el bloc amb `CSS.highlights` i un blau molt suau, i no es
veia res (23/10/2026). La segona marcava el bloc de groc i la paraula amb un groc més fort que
saltava de paraula en paraula: era massa brusc i feia que la mirada esperés el salt en lloc de
llegir (6/11/2026).

**Les frases del botó** són `comu.veu_escolta` («Escolta la targeta») i `comu.veu_para` («Para
la veu»), a `dades/textos.js`. Les velocitats i la pausa, a dalt de `../comu/js/veu.js`.

**Una eina nova no ha de fer res**: el botó surt sol a cada `.targeta` que tingui un `<h2>`.
Si un text de l'eina es llegeix malament, el remei és un `aria-label` amb la lectura en paraules
(i `role="img"`) a l'element que el conté, com les fraccions.

---

## 7. Comprovacions

`python3 eines/comprova.py` verifica, per a les fitxes: cap valor cromàtic, HTML ben
tancat, numeració de pàgines seguida, rètol de material, obertura i solucionari, i la pàgina
«A la vida de cada dia» a les de la unitat o «Una de cada» i «Què he après?» a les de repàs.
Per a les targetes: B/N, cares numerades «· cara N» i sense solucionari. Els PDF que
hi han de ser surten de les fonts, i `dades/unitats.js` ha de coincidir amb el disc. I per a l'app: que els identificadors del marcatge coincideixin amb
els mòduls registrats i que no hi hagi recursos remots. A més:

| Secció | Què mira |
|---|---|
| FRASES | que cap `data-text` ni cap `txt()` demani una frase que no existeix, i que no en sobri cap |
| LECTURA FÀCIL | frases de més de 20 paraules, paraules repetides, «clica aquí», xifres romanes, hores de 24 h i majúscules (UNE 153101:2018 EX) |
| CONTRAST | 17 parelles de color de `tokens.css`, en mode clar i fosc, amb els mínims de la WCAG 2.2 AA |

No té cap dependència: es pot passar a qualsevol ordinador. Convé fer-ho abans de
publicar res.

`python3 eines/auditoria.py` és la segona xarxa, i necessita Playwright. Obre la caixa
d'eines en un Chromium de veritat, en mode clar i fosc i a dues amplades, i mesura el que
només es pot mesurar amb el navegador: la mida real de cada diana tàctil (WCAG 2.2 SC
2.5.8, mínim 24 × 24 px), el contrast de cada text **amb el fons compost capa a capa**, i
que cap element enfocable no es quedi sense indicador de focus. Inclou els estats difícils
(un error amb pista, el resum final), que és on solen aparèixer els problemes.

També mesura **la lletra de les fitxes al paper** (29/9/2026): maqueta cada fitxa com el
PDF (el full d'estil de `gen_pdf.py` i els 18,2 cm útils d'un A4) i mira la mida real de
cada text de l'alumnat, amb els dibuixos escalats. Cap text per sota de 14 pt, i cap rètol
de gràfic per sota de 12 pt. El solucionari, el rètol del graó físic i el peu de pàgina
són per a l'adult i no hi compten.

    python3 eines/auditoria.py --md /tmp/informe.md

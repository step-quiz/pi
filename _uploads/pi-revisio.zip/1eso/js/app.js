/* ============================================================================
   app.js · navegació de la caixa d'eines
   ----------------------------------------------------------------------------
   L'única feina d'aquest fitxer és ensenyar una secció i amagar les altres.
   No sap res del que fa cada mòdul: només l'identificador, que llegeix de
   l'atribut data-mod dels botons. Afegir un mòdul no obliga a tocar-lo.

   Còpia del de la caixa de 4eso/. Dues diferències: la clau del navegador
   comença per «pi1-», i la subtasca demanada (?task=1.3) va lligada a la seva
   tasca, perquè aquí tots els mòduls en tenen.

   UNA SOLA EINA, PER A LES PROVES · eines.html?task=n
   Ja no s'enllaça enlloc (6/11/2026): l'alumnat entra amb eines.html?u=N (més avall).
   Només es veuen dues pestanyes: la tasca 0 (les Taules), sempre la
   primera, i la tasca n. Els números són l'atribut data-tasca de cada botó.
     - Sense ?task es veu la caixa sencera, com sempre.
     - ?task=0, o un número que no existeix: només la tasca 0.
     - ?task=1.2 obre la tasca 1 directament per la subtasca 2.
     - S'obre directament la tasca n.
     - No es llegeix ni s'escriu el mòdul desat: en un ordinador compartit,
       cada persona entraria on ho va deixar l'anterior.

   LES EINES D'UNA UNITAT · eines.html?u=N
   L'enllaç que el docent copia a la pàgina de la unitat i envia a l'alumnat. Només es
   veuen les eines de la unitat N, i la capçalera no porta cap enllaç. Vegeu aplicaUnitat().
   ========================================================================== */

(function () {
  "use strict";
  const { $, $$, moduls, memoria } = CE;

  const CLAU = "pi1-caixa-modul";  // últim mòdul obert; pi1-, perquè no es barregi amb l'altra caixa
  let permesos = null;             // null: totes les pestanyes; si no, els data-mod visibles

  function obre(id) {
    if (permesos && !permesos.includes(id)) return;
    // Encara no s'ha carregat: es carrega (CE.carrega) i, quan ja hi és, s'obre.
    if (!moduls[id]) {
      CE.carrega(id).then(() => obre(id), e => console.error(e.message));
      return;
    }
    $$(".modul").forEach(s => { s.hidden = true; });
    $$(".segment[data-mod]").forEach(p => p.setAttribute("aria-selected", String(p.dataset.mod === id)));

    const sec = $("#mod-" + id);
    if (!sec) return;
    sec.hidden = false;

    const inicia = moduls[id];
    if (inicia) inicia();
    else console.warn("CE: no hi ha cap mòdul registrat amb l'identificador «" + id + "»");

    if (!permesos) memoria.set(CLAU, id);
  }

  /** Llegeix ?task=n i amaga la resta de pestanyes. Retorna el mòdul que s'ha
      d'obrir, o null si l'adreça no porta filtre. */
  function aplicaFiltre(botons) {
    const valor = new URLSearchParams(location.search).get("task");
    if (valor === null) return null;

    // «1» obre la tasca 1; «1.2» obre directament la subtasca 1.2, que és el que
    // permet enviar un exercici concret i no la tasca sencera.
    const parts = valor.trim().split(".");
    const bo = parts.length <= 2 && parts.every(x => /^\d+$/.test(x));

    const tasca = n => botons.find(b => b.dataset.tasca === n);
    const base = tasca("0");
    const triada = bo ? tasca(String(Number(parts[0]))) : undefined;
    // Aquí TOTS els mòduls tenen subtasques. La subtasca demanada va lligada a
    // la seva tasca: ?task=1.3 obre la 1.3, però la pestanya Taules, que també
    // surt, s'obre per la 0.1 i no per la 0.3. Cada mòdul ho pregunta amb
    // CE.subDemanada(tasca).
    CE.demanada = (triada && parts.length === 2) ? { tasca: triada.dataset.tasca, sub: Number(parts[1]) } : null;
    if (!triada) console.warn("CE: ?task=" + valor + " no és cap tasca; només es mostra la tasca 0");

    const visibles = [...new Set([base, triada])].filter(Boolean);
    if (!visibles.length) return null;   // marcatge sense tasca 0: millor ensenyar-ho tot que res

    permesos = visibles.map(b => b.dataset.mod);
    botons.forEach(b => { b.hidden = !permesos.includes(b.dataset.mod); });
    return (triada || base).dataset.mod;
  }

  /* LES EINES DE CADA UNITAT (30/9/2026)
     La caixa sencera té 29 pestanyes seguides. A sobre hi ha una fila de botons,
     «Totes · Unitat 1 · … · Unitat 7», que deixa veure només les eines d'una unitat
     (l'atribut data-unitats de cada pestanya; la tasca 0 surt sempre). La tria es
     desa. Als enllaços ?task=n no surt: allà ja només hi ha dues pestanyes. */
  const CLAU_UNITAT = "pi1-caixa-unitat";
  const unitatsDe = b => (b.dataset.unitats || "").split(" ");

  function triaUnitat(botons, u, obreLaPrimera) {
    botons.forEach(b => { b.hidden = !(u === "totes" || b.dataset.tasca === "0" || unitatsDe(b).includes(u)); });
    $$("#tria-unitat .pastilla").forEach(p => p.setAttribute("aria-pressed", String(p.dataset.unitat === u)));
    if (obreLaPrimera) {
      const actiu = botons.find(b => b.getAttribute("aria-selected") === "true");
      if (!actiu || actiu.hidden || (u !== "totes" && actiu.dataset.tasca === "0")) {
        const primera = botons.find(b => !b.hidden && b.dataset.tasca !== "0") || botons[0];
        if (primera) obre(primera.dataset.mod);
      }
    }
  }

  function filaUnitats(botons) {
    const fila = $("#tria-unitat");
    if (!fila) return;
    if (permesos) { fila.hidden = true; return; }
    fila.setAttribute("aria-label", CE.txt("comu.tria_nom"));
    const nums = [...new Set(botons.flatMap(unitatsDe).filter(u => /^\d+$/.test(u)))].sort((a, b) => a - b);
    ["totes", ...nums].forEach(u => {
      const p = document.createElement("button");
      p.className = "pastilla";
      p.dataset.unitat = u;
      p.innerHTML = u === "totes" ? CE.txt("comu.tria_totes") : CE.txt("comu.tria_unitat", { n: u });
      p.onclick = () => { memoria.set(CLAU_UNITAT, u); triaUnitat(botons, u, true); };
      fila.appendChild(p);
    });
    const desada = memoria.get(CLAU_UNITAT);
    triaUnitat(botons, desada && (desada === "totes" || nums.includes(desada)) ? desada : "totes", false);
  }

  /** eines.html?u=N: l'enllaç que el docent envia a l'alumnat (6/11/2026). ../comu/js/alumne.js
      ja ha llegit la unitat (PI.einesUnitat). Només es veuen les eines del camp tasques de
      dades/unitats.js, en aquest ordre, i s'obre la primera. Com amb ?task, no es desa res.
      MENYS LLOCS ON CLICAR (6/11/2026): les eines «de sempre» (data-comuna, les Taules) ja no
      surten totes soles; només on les posa tasques. I amb una sola eina no hi ha pestanyes. */
  function aplicaUnitat(botons) {
    const u = window.PI && window.PI.einesUnitat;
    if (!u) return null;
    const nums = (u.tasques || []).map(String);
    const visibles = nums.map(n => botons.find(b => b.dataset.tasca === n)).filter(Boolean);
    if (!visibles.length) return null;
    permesos = visibles.map(b => b.dataset.mod);
    botons.forEach(b => { b.hidden = !permesos.includes(b.dataset.mod); });
    const barra = visibles[0].parentElement;
    visibles.forEach(b => barra.appendChild(b));
    // Amb una sola eina, cap pestanya: no hi ha res a triar.
    barra.hidden = visibles.length === 1;
    return visibles[0].dataset.mod;
  }


  function arrenca() {
    const botons = $$(".segment[data-mod]");
    botons.forEach(p => { p.onclick = () => obre(p.dataset.mod); });

    let inicial = aplicaFiltre(botons) || aplicaUnitat(botons);
    filaUnitats(botons);
    if (!inicial) {
      const desat = memoria.get(CLAU);
      const visible = b => b && !b.hidden;
      inicial = (desat && visible(botons.find(b => b.dataset.mod === desat)))
        ? desat : (botons.find(b => !b.hidden) || botons[0] || {}).dataset.mod;
    }
    if (inicial) obre(inicial);
  }

  // app.js va l'últim dels <script> de la pàgina. Els mòduls es carreguen quan
  // s'obren (CE.carrega), i per això obre() espera que s'hagin registrat.
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", arrenca);
  else arrenca();

  CE.obre = obre;                  // útil per provar-ho des de la consola
})();

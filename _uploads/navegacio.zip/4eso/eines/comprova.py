#!/usr/bin/env python3
"""Comprovacions del projecte. Es passa abans de publicar res.

    python3 4eso/eines/comprova.py      (des de l'arrel del repositori)

Verifica les regles que és fàcil trencar sense adonar-se'n: que les fitxes no
tinguin cap color, que l'HTML tanqui bé, que la numeració de pàgines sigui
seguida, que cada fitxa porti el rètol de material, la pregunta d'obertura i
la pàgina de la vida de cada dia (i «Una de cada» a les de repàs), que les
targetes de consulta siguin en B/N i amb les cares numerades, que els mòduls
declarats al marcatge de l'app siguin els que es registren, que els fulls d'estil tanquin totes les
claus i no facin servir variables que no existeixen, que les frases de
l'alumnat segueixin les regles de Lectura Fàcil que es poden comprovar soles,
i que els colors de la pantalla tinguin el contrast que demana la WCAG 2.2 AA.
"""
import re, sys, glob, os, json
from html.parser import HTMLParser

ARREL = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))   # la carpeta del curs
REPO = os.path.dirname(ARREL)          # l'arrel: els cursos, comu/ i el desplegament
BUIDES = {'area','base','br','col','embed','hr','img','input','link','meta','source',
          'track','wbr','path','circle','rect','line','text','use','stop','polygon',
          'polyline','ellipse'}
falles = []

class Estructura(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.pila, self.err = [], []

    def handle_starttag(self, t, a):
        if t not in BUIDES:
            self.pila.append(t)

    def handle_endtag(self, t):
        if t in BUIDES:
            return
        if self.pila and self.pila[-1] == t:
            self.pila.pop()
        else:
            self.err.append(t)

def rgb(h):
    h = h.lstrip('#')
    h = ''.join(c * 2 for c in h) if len(h) == 3 else h
    return int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)

def cromatics(text):
    return sorted({h for h in re.findall(r'#[0-9A-Fa-f]{3,6}\b', text)
                   if len(set(rgb(h))) > 1})

def comprova(condicio, missatge):
    if not condicio:
        falles.append(missatge)
    return condicio

def ruta(*p):
    return os.path.join(ARREL, *p)

print("FITXES")
css_fitxa = open(ruta('css', 'fitxa.css'), encoding='utf-8').read()
comprova(not cromatics(css_fitxa), "css/fitxa.css conté color")
print(f"  css/fitxa.css                cap color: {not cromatics(css_fitxa)}")

for f in sorted(glob.glob(ruta('fitxes', '*.html'))):
    nom = os.path.basename(f)
    s = open(f, encoding='utf-8').read()
    e = Estructura(); e.feed(s)
    estructura = not e.err and not e.pila
    color = cromatics(s)
    pags = [int(n) for n in re.findall(r'· pàgina (\d+)</div>', s)]
    seguida = pags == list(range(1, len(pags) + 1))
    enllac = 'css/fitxa.css' in s
    inline = '<style>' in s

    comprova(estructura, f"{nom}: HTML mal tancat")
    comprova(not color, f"{nom}: hi ha color ({color})")
    comprova(seguida, f"{nom}: numeració de pàgines {pags}")
    comprova(enllac and not inline, f"{nom}: no enllaça css/fitxa.css o encara té <style>")
    comprova(s.count('class="previ"') == 1, f"{nom}: falta el rètol de material")
    comprova(s.count('Què hi veus?') == 1, f"{nom}: falta la pregunta d'obertura")
    comprova(s.count('class="full sol"') >= 1, f"{nom}: falta el solucionari")
    if re.fullmatch(r'ud\d+\.html', nom):
        # La pàgina de la vida de cada dia: un context real i una segona situació
        # amb la mateixa decisió, perquè el que s'aprèn no es quedi lligat a un cas.
        comprova(s.count('class="full vida"') == 1, f"{nom}: falta la pàgina «A la vida de cada dia»")
    else:
        # La fitxa de repàs (udN-repas.html): un exercici de cada tipus de la unitat
        # i l'autoavaluació en frases que l'alumnat pot marcar.
        comprova(re.fullmatch(r'ud\d+-repas\.html', nom), f"{nom}: nom de fitxa desconegut")
        comprova('Una de cada' in s, f"{nom}: falta «Una de cada»")
        comprova('Què he après?' in s, f"{nom}: falta «Què he après?»")
    print(f"  {nom:12} {len(pags)} pàg · html {'ok' if estructura else 'ERROR'}"
          f" · color {'cap' if not color else color} · css extern {enllac and not inline}")

print("\nTARGETES")
# Les targetes de consulta (targetes/*.html): B/N com les fitxes, cares numerades
# «· cara N» i sense solucionari. Cada una fa un sol PDF, targeta-NOM.pdf.
for f in sorted(glob.glob(ruta('targetes', '*.html'))):
    nom = os.path.basename(f)
    s = open(f, encoding='utf-8').read()
    e = Estructura(); e.feed(s)
    estructura = not e.err and not e.pila
    color = cromatics(s)
    cares = [int(n) for n in re.findall(r'· cara (\d+)</div>', s)]
    blocs = len(re.findall(r'<div class="full[^"]*">.*?\n</div>', s, re.S))
    comprova(estructura, f"targetes/{nom}: HTML mal tancat")
    comprova(not color, f"targetes/{nom}: hi ha color ({color})")
    comprova(cares == list(range(1, blocs + 1)) and blocs, f"targetes/{nom}: cares {cares} per a {blocs} blocs")
    comprova('../css/fitxa.css' in s and '<style>' not in s, f"targetes/{nom}: no enllaça css/fitxa.css")
    comprova('class="full sol"' not in s, f"targetes/{nom}: una targeta no porta solucionari")
    print(f"  {nom:18} {len(cares)} cares · html {'ok' if estructura else 'ERROR'}"
          f" · color {'cap' if not color else color}")

SENCER_Q = re.compile(r'\b(nombres?|quantitats?|coses?|xifres?|dos)\s+sencer(s|a|es)?\b', re.I)

print("\nQUADERNS")
# El quadern d'activitats de cada unitat (quadern/udN.html): B/N com les fitxes, i el
# filtre ha de poder treure apartats i activitats sense deixar el solucionari descompassat. No
# s'edita a mà: el fa generadors/gen_quadern.py a partir de generadors/quadern/udN.py,
# i aquí es torna a fer per veure que el fitxer publicat és el que surt del generador.
css_quadern = open(ruta('css', 'quadern.css'), encoding='utf-8').read()
comprova(not cromatics(css_quadern), "css/quadern.css conté color")
sys.path.insert(0, ruta('generadors'))
import gen_quadern   # noqa: E402  (només biblioteca estàndard)
fonts_q = gen_quadern.unitats()
fitxers_q = sorted(int(re.search(r'ud(\d+)\.html$', f)[1]) for f in glob.glob(ruta('quadern', 'ud*.html')))
comprova(fonts_q == fitxers_q, f"quaderns: generadors/quadern/ té {fonts_q} i quadern/ té {fitxers_q}")
for f in sorted(glob.glob(ruta('quadern', '*.html'))):
    nom = os.path.basename(f)
    s = open(f, encoding='utf-8').read()
    e = Estructura(); e.feed(s)
    estructura = not e.err and not e.pila
    color = cromatics(s)
    acts = re.findall(r'<div class="exercici act"( data-repte)?>', s)
    sols = re.findall(r'<div class="sol-act"( data-repte)?>', s)
    comprova(re.fullmatch(r'ud\d+\.html', nom), f"quadern/{nom}: nom de quadern desconegut")
    comprova(estructura, f"quadern/{nom}: HTML mal tancat")
    comprova(not color, f"quadern/{nom}: hi ha color ({color})")
    comprova('../css/fitxa.css' in s and '../css/quadern.css' in s and '../js/quadern.js' in s,
             f"quadern/{nom}: ha d'enllaçar css/fitxa.css, css/quadern.css i js/quadern.js")
    comprova(acts and acts == sols, f"quadern/{nom}: les activitats i el solucionari no porten les mateixes marques")
    # Cada activitat: l'a) i 12 apartats per fer, amb la marca de la quantitat a partir de la
    # qual surten (3 a petit, 3 més a mitjà, 6 més a elevat), sempre de menys a més perquè
    # les lletres que queden vagin seguides. Al solucionari, el mateix.
    esperat = ['1'] * 4 + ['2'] * 3 + ['3'] * 6
    tall = s.index('<div class="quadern sol"')
    for part, marca, on in ((s[:tall], '<div class="exercici act"', "l'activitat"),
                            (s[tall:], '<div class="sol-act"', "el solucionari de l'activitat")):
        for i, tros in enumerate(part.split(marca)[1:], 1):
            marques = re.findall(r'class="ap[^"]*" data-n="(\d)"', tros)
            comprova(marques == esperat, f"quadern/{nom}: {on} {i} té els apartats {''.join(marques)}"
                                         f" (han de ser {''.join(esperat)})")
    # Consignes d'una sola frase i curtes, com a la fitxa (regla 3 i Lectura Fàcil).
    for q in re.findall(r'<div class="q">(.*?)(?:\n|</div>)', s):
        q = re.sub(r'<[^>]+>', '', q)
        comprova(len(re.findall(r"[\w·'’]+", q)) <= 20, f"quadern/{nom}: consigna de més de 20 paraules: «{q}»")
    alumnat = re.sub(r'<!--.*?-->', '', s[:s.index('<div class="quadern sol"')], flags=re.S)
    comprova(not re.search(r'adapta(t|da|ts|des|ció|cions)\b', alumnat, re.I),
             f"quadern/{nom}: l'alumnat no ha de llegir «adaptat»")
    comprova(not SENCER_Q.search(alumnat), f"quadern/{nom}: «sencer» parlant de nombres (el terme és «enter»)")
    n = int(re.search(r'ud(\d+)', nom)[1])
    if n in fonts_q:
        comprova(gen_quadern.genera(n) == s,
                 f"quadern/{nom} no és el que surt de generadors/quadern/ud{n}.py "
                 "(no s'edita a mà: passa python3 generadors/gen_quadern.py)")
    print(f"  {nom:12} html {'ok' if estructura else 'ERROR'} · color {'cap' if not color else color}"
          f" · {sum(1 for r in acts if not r)} activitats i {sum(1 for r in acts if r)} de repte, de 3, 6 o 12 apartats")

print("\nCAIXA D'EINES")
app = open(ruta('caixa-eines.html'), encoding='utf-8').read()
e = Estructura(); e.feed(app)
comprova(not e.err and not e.pila, "caixa-eines.html: HTML mal tancat")

pestanyes = sorted({m for m in re.findall(r'data-mod="(\w+)"', app)})
seccions = sorted({m for m in re.findall(r'<section id="mod-(\w+)"', app)})
fitxers = sorted(glob.glob(ruta('js', 'moduls', '*.js')))
registrats = sorted({re.search(r'CE\.registra\("(\w+)"', open(x, encoding='utf-8').read()).group(1)
                     for x in fitxers})
carregats = re.findall(r'<script src="js/moduls/([\w-]+)\.js"', app)

comprova(pestanyes == seccions == registrats,
         f"identificadors descompassats: marcatge {pestanyes} · registrats {registrats}")
comprova(sorted(carregats) == sorted(os.path.basename(x)[:-3] for x in fitxers),
         "hi ha mòduls a js/moduls que no es carreguen, o a l'inrevés")
comprova(app.rindex('js/app.js') > max(app.rindex(f'js/moduls/{c}.js') for c in carregats),
         "js/app.js s'ha de carregar després de tots els mòduls")
print(f"  mòduls: {len(registrats)} · marcatge i registre coincideixen: {pestanyes == registrats}")
print(f"  app.js va l'últim: {app.rindex('js/app.js') > max(app.rindex(f'js/moduls/{c}.js') for c in carregats)}")

# Els números de tasca surten als enllaços que el docent envia (caixa-eines?task=n).
# Cada pestanya en porta un, sense repetir-se, i la tasca 0 va la primera perquè es
# mostra sempre. Un número ja enviat no es canvia mai: un mòdul nou pren el següent.
pestanyes_html = re.findall(r'<button[^>]*class="segment"[^>]*>', app)
numeros = [(re.search(r'data-tasca="([^"]*)"', b) or [None, None])[1] for b in pestanyes_html]
mods = [(re.search(r'data-mod="(\w+)"', b) or [None, '?'])[1] for b in pestanyes_html]
tasques_ok = (bool(numeros) and all(n is not None and re.fullmatch(r'0|[1-9]\d*', n) for n in numeros)
              and len(set(numeros)) == len(numeros) and numeros[0] == "0")
comprova(tasques_ok, f"data-tasca de les pestanyes: {numeros} "
                     "(cal un número a cada una, sense repetir, i el 0 el primer)")
print("  tasques: " + " · ".join(f"{n} {m}" for n, m in zip(numeros, mods)))

print("\nFRASES")
# Les frases viuen a dades/textos.js. El marcatge i el codi només hi apunten:
# si una clau no existeix, a la pantalla surt «[1.2.titol]», i això s'ha de
# detectar aquí i no a classe.
textos = open(ruta('dades', 'textos.js'), encoding='utf-8').read()
# Els grups poden ser «1.2» (una subtasca), «5» (una tasca sense subtasques) o
# «comu» (frases compartides). El nom del grup és tot el que va abans de
# l'últim punt de la clau, igual que fa CE.txt().
def claus_de(bloc):
    out = set()
    for grup, cos in re.findall(r'^  "([\w.]+)":\s*\{(.*?)\n  \}', bloc, re.S | re.M):
        for nom in re.findall(r'^\s{4}(\w+):', cos, re.M):
            out.add(grup + "." + nom)
    return out

tall = textos.index("window.TEXTOS_GUIA")
definides = claus_de(textos[:tall])
guiades = claus_de(textos[tall:])

# Les claus no sempre s'escriuen senceres: n'hi ha que es munten amb un
# prefix («1.3.» + quina) o amb el sufix «.nom» des del nucli. Si no es té en
# compte, l'avís d'orfes en delata vint que sí que es fan servir i s'acaba
# ignorant, que és pitjor que no tenir-lo.
grups = sorted({c.rsplit(".", 1)[0] for c in definides}, key=len, reverse=True)
g = "(?:" + "|".join(re.escape(x) for x in grups) + ")"
usades = set(re.findall(r'data-text="(' + g + r'\.\w+)"', app))
prefixos = set()
for f in sorted(glob.glob(ruta('js', '**', '*.js'), recursive=True)):
    codi = open(f, encoding='utf-8').read()
    # Una clau entre cometes que no va seguida d'un «+» (si hi va, és un prefix).
    # El nom comença per una lletra: així "0.01", que és un número, no compta
    # com a clau del grup «0».
    usades |= set(re.findall(r'"(' + g + r'\.[A-Za-z_]\w*)"(?!\s*\+)', codi))
    prefixos |= set(re.findall(r'"(' + g + r')\.\w*"\s*\+', codi))

comprova(not (usades - definides), f"frases que es demanen i no existeixen: {sorted(usades - definides)}")
comprova(not (definides - guiades), f"frases sense explicació a TEXTOS_GUIA: {sorted(definides - guiades)}")

orfes = sorted(c for c in definides - usades
               if not c.endswith(".nom")                 # les llegeix el nucli
               and c.rsplit(".", 1)[0] not in prefixos)  # clau muntada amb prefix
print(f"  frases definides: {len(definides)} · totes les que es demanen existeixen: {not (usades - definides)}")
print(f"  frases sense fer servir: {orfes if orfes else 'cap'}")

print("\nLECTURA FÀCIL")
# Les regles de la norma UNE 153101:2018 EX que es poden comprovar sense llegir.
# Les altres (una idea per frase, res de metàfores, la mateixa paraula per a la
# mateixa cosa) són a la capçalera de dades/textos.js i les ha de mirar una persona.
#   Falla: una frase de més de 20 paraules, una paraula repetida seguida
#          («situació situació»), «clica aquí», xifres romanes, hores de 24 h
#          o paraules senceres en majúscules que no siguin sigles conegudes.
#   Avisa: frases de més de 15 paraules, i parèntesis o punt i coma.
SIGLES = {"IVA", "EXE", "SHIFT", "FORMAT", "DEL", "AC", "CONFIG"}
ROMANS = re.compile(r'^M{0,3}(CM|CD|D?C{0,3})(XC|XL|L?X{0,3})(IX|IV|V?I{0,3})$')

def frases_de(bloc):
    """{clau: text} de window.TEXTOS, desfent les cometes escapades."""
    out = {}
    for grup, cos in re.findall(r'^  "([\w.]+)":\s*\{(.*?)\n  \}', bloc, re.S | re.M):
        for nom, val in re.findall(r"^\s{4}(\w+):\s*'((?:[^'\\]|\\.)*)'", cos, re.M):
            out[grup + "." + nom] = re.sub(r"\\(.)", r"\1", val)
    return out

avisos_lf, falles_lf = [], []
for clau, t in frases_de(textos[:tall]).items():
    net = re.sub(r"\{\w+\}", "X", t.replace("*", ""))
    for frase in re.split(r"(?<=[.!?])\s+", net):
        paraules = re.findall(r"[\w·'’√π]+", frase)
        if len(paraules) > 20:
            falles_lf.append(f"{clau}: frase de {len(paraules)} paraules")
        elif len(paraules) > 15:
            avisos_lf.append(f"{clau}: frase de {len(paraules)} paraules")
    repetida = re.search(r"\b(\w+)\s+\1\b", net, re.I)     # fora de l'f-string: Python 3.11
    if repetida:
        falles_lf.append(f"{clau}: paraula repetida («{repetida.group(0)}»)")
    if re.search(r"\bclica\b|\bclic\b", net, re.I):
        falles_lf.append(f"{clau}: «clica aquí» no diu on porta")
    if re.search(r"\b([01]?\d|2[0-3]):[0-5]\d\b", net):
        falles_lf.append(f"{clau}: hora en format de 24 h")
    for p in re.findall(r"\b[A-ZÀ-Ú]{2,}\b", net):
        if p in SIGLES:
            continue
        if ROMANS.match(p):
            falles_lf.append(f"{clau}: xifra romana «{p}»")
        elif len(p) >= 3:
            falles_lf.append(f"{clau}: paraula en majúscules «{p}»")
    if re.search(r"[;()]", net):
        avisos_lf.append(f"{clau}: parèntesis o punt i coma")
for f in falles_lf:
    comprova(False, "Lectura Fàcil · " + f)
print(f"  frases revisades: {len(frases_de(textos[:tall]))} · errors: {len(falles_lf)} · avisos: {len(avisos_lf)}")
for a in avisos_lf:
    print("    avís ·", a)

print("\nSUBTASQUES")
# Un mòdul partit en 1.1, 1.2… necessita la barra de fletxes i panells numerats
# de manera seguida des de l'1, perquè els enllaços ?task=1.3 apuntin on toca.
for m in re.findall(r'<section id="mod-(\w+)"[^>]*>(.*?)</section>', app, re.S):
    nom, cos = m
    subs = [int(x) for x in re.findall(r'class="subtasca"[^>]*data-sub="(\d+)"', cos)]
    if not subs:
        continue
    comprova(subs == list(range(1, len(subs) + 1)),
             f"mod-{nom}: les subtasques van {subs}, han d'anar 1, 2, 3…")
    comprova(len(set(subs)) == len(subs), f"mod-{nom}: hi ha subtasques repetides")
    for peca in ("sub-enrere", "sub-avant", "sub-rotul"):
        comprova(peca in cos, f"mod-{nom} té subtasques però li falta .{peca}")
    pestanya = re.search(r'data-tasca="(\d+)" data-mod="' + nom + '"', app)
    if pestanya:
        for n in subs:
            clau = pestanya.group(1) + "." + str(n) + ".nom"
            comprova(clau in definides, f"falta la frase {clau} a dades/textos.js")
    print(f"  mod-{nom}: {len(subs)} subtasques, numerades bé i amb nom a textos.js")
if not re.search(r'class="subtasca"', app):
    print("  cap mòdul en té")

print("\nPDF")
# Un PDF per fitxa i per destinatari, i un per targeta. Es generen amb
# generadors/gen_pdf.py. La llista surt de les fonts: una fitxa nova ja en demana el PDF.
esperats = []
for f in sorted(glob.glob(ruta('fitxes', '*.html'))):
    b = os.path.basename(f)[:-5]
    esperats += [f'{b}-alumnat.pdf', f'{b}-solucionari.pdf']
esperats += [f'targeta-{os.path.basename(f)[:-5]}.pdf' for f in sorted(glob.glob(ruta('targetes', '*.html')))]
falten = [p for p in esperats
          if not os.path.exists(ruta('pdf', p)) or os.path.getsize(ruta('pdf', p)) < 2000]

# Si és vell: l'empremta de la font (i dels estils) ha de ser la que va desar gen_pdf.py.
sys.path.insert(0, ruta('eines'))
from empremta import empremta   # noqa: E402  (només biblioteca estàndard)
try:
    empremtes = json.load(open(ruta('pdf', 'empremtes.json'), encoding='utf-8'))
except FileNotFoundError:
    empremtes = {}
def vell(pdf):
    e = empremtes.get(pdf)
    return not e or not os.path.exists(ruta(e['font'])) or e['empremta'] != empremta(e['font'])
vells = [p for p in esperats if p not in falten and vell(p)]
comprova(not vells, f"PDF d'abans de l'últim canvi de la seva fitxa o dels estils (passa generadors/gen_pdf.py): {vells}")
comprova(not falten, f"PDF que falten o buits: {falten}")

# El recompte de pàgines NO es fa aquí: WeasyPrint comprimeix els objectes del
# PDF i qualsevol intent de comptar-les llegint els bytes dona zero i deixa
# passar errors sense dir res. Qui ho comprova de debò és generadors/gen_pdf.py,
# que compara les pàgines generades amb els blocs .full de la fitxa i s'atura si
# no quadren.
print(f"  PDF presents: {len(esperats) - len(falten)}/{len(esperats)} · al dia: {len(esperats) - len(falten) - len(vells)}")

print("\nFULLS D'ESTIL")
# Una clau sense tancar no dona cap error visible: el navegador la tanca al final
# del fitxer i tot el que ve després queda dins d'aquell bloc. Així es va trencar
# app.css: un «@media (prefers-color-scheme:dark){» obert a dalt de tot feia que
# la caixa d'eines només tingués estils amb el mode fosc activat.
def claus_desaparellades(text):
    """Problemes de claus, amb la línia on són. Salta comentaris i cadenes."""
    linies, pila, errors = text.split('\n'), [], []
    i, n, linia = 0, len(text), 1
    while i < n:
        c = text[i]
        if text.startswith('/*', i):
            fi = text.find('*/', i + 2)
            if fi == -1:
                errors.append(f"comentari obert a la línia {linia} que no es tanca mai")
                break
            linia += text.count('\n', i, fi)
            i = fi + 2
            continue
        if c in '"\'':
            fi = i + 1
            while fi < n and text[fi] not in (c, '\n'):
                fi += 2 if text[fi] == '\\' else 1
            linia += text.count('\n', i, fi)
            i = fi + 1 if fi < n and text[fi] == c else fi
            continue
        if c == '\n':
            linia += 1
        elif c == '{':
            pila.append(linia)
        elif c == '}':
            if pila:
                pila.pop()
            else:
                errors.append(f"clau de tancament sobrant a la línia {linia}")
        i += 1
    errors += [f"clau oberta a la línia {l} que no es tanca mai: «{linies[l - 1].strip()[:50]}»"
               for l in pila]
    return errors

fulls = sorted(glob.glob(ruta('css', '*.css')))
for c in fulls:
    errors = claus_desaparellades(open(c, encoding='utf-8').read())
    comprova(not errors, f"{os.path.basename(c)}: " + "; ".join(errors))
    print(f"  {os.path.basename(c):12} claus {'ok' if not errors else 'ERROR · ' + errors[0]}")

# Una variable que no existeix tampoc avisa: la propietat es queda sense efecte.
# Així la barra de pestanyes s'havia quedat sense fons (--segment-fons). Les que
# porten valor de reserva, var(--x, …), no compten.
fonts = (fulls + glob.glob(ruta('js', '**', '*.js'), recursive=True)
         + glob.glob(ruta('*.html')) + glob.glob(ruta('fitxes', '*.html')))
textos = {f: open(f, encoding='utf-8').read() for f in fonts}
definides = {v for t in textos.values() for v in re.findall(r'(--[\w-]+)\s*:', t)}
sense_definir = {}
for f, t in textos.items():
    for v in re.findall(r'var\(\s*(--[\w-]+)\s*\)', t):
        if v not in definides:
            sense_definir.setdefault(v, set()).add(os.path.relpath(f, ARREL))
comprova(not sense_definir, "variables CSS que no estan definides enlloc: " +
         "; ".join(f"{v} a {', '.join(sorted(fs))}" for v, fs in sorted(sense_definir.items())))
print(f"  variables usades sense definir: {len(sense_definir)}")

print("\nCONTRAST (WCAG 2.2 AA)")
# Es calcula a partir de css/tokens.css, en mode clar i en mode fosc. Els colors
# amb transparència es componen sobre el fons on es fan servir de debò.
#   text normal ≥ 4,5:1   ·   xifres grans i elements gràfics ≥ 3:1
# Si canvies un color de la paleta de pantalla, aquest és l'avís que ho detecta.
def lineal(c):
    c /= 255
    return c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4

def lluminancia(r):
    return 0.2126 * lineal(r[0]) + 0.7152 * lineal(r[1]) + 0.0722 * lineal(r[2])

def contrast(a, b):
    la, lb = lluminancia(a), lluminancia(b)
    return (max(la, lb) + 0.05) / (min(la, lb) + 0.05)

def a_rgb(valor, sota=(255, 255, 255)):
    valor = valor.strip()
    m = re.fullmatch(r"#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})", valor)
    if m:
        return rgb(valor)
    m = re.fullmatch(r"rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*([\d.]+))?\s*\)", valor)
    if not m:
        raise ValueError(valor)
    alfa = float(m.group(4) or 1)
    return tuple(round(int(m.group(i + 1)) * alfa + sota[i] * (1 - alfa)) for i in range(3))

tokens = open(ruta('css', 'tokens.css'), encoding='utf-8').read()
clar = dict(re.findall(r"(--[\w-]+):\s*([^;]+);", tokens[:tokens.index("@media")]))
fosc = dict(clar, **dict(re.findall(r"(--[\w-]+):\s*([^;]+);", tokens[tokens.index("@media"):])))

PARELLES = [   # (primer pla, fons, mínim, on es fa servir)
    ("--etiqueta",   "--superficie", 4.5, "text principal"),
    ("--etiqueta-2", "--superficie", 4.5, "text secundari: ajudes, rètols"),
    ("--etiqueta-2", "--fons",       4.5, "text secundari sobre el fons de la pàgina"),
    ("--etiqueta-2", "--camp",       4.5, "avisos neutres i pastilles"),
    ("--etiqueta-3", "--superficie", 3.0, "traços dels eixos i xifres apagades (grans)"),
    ("#FFFFFF",      "--blau",       4.5, "lletra dels botons blaus"),
    ("--blau",       "--superficie", 3.0, "punts i línies blaves dels dibuixos"),
    ("--blau-text",  "--superficie", 4.5, "lletra blava: enllaços, marques"),
    ("--blau-text",  "--fons",       4.5, "enllaços sobre el fons de la pàgina"),
    ("--blau-text",  "--blau-suau",  4.5, "botons tenyits i etiqueta «Exemple»"),
    ("--blau-text",  "--camp",       4.5, "tecles d'operació de la calculadora"),
    ("--superficie", "--verd",       4.5, "rètol «Final» quan la tasca s'ha acabat"),
    ("--verd",       "--superficie", 4.5, "lletra verda dels dibuixos"),
    ("--taronja",    "--superficie", 4.5, "lletra taronja dels dibuixos"),
    ("--vermell",    "--superficie", 4.5, "xifres vermelles de la balança"),
    ("--etiqueta",   "--verd-suau",  4.5, "avisos de «Correcte»"),
    ("--etiqueta",   "--taronja-suau", 4.5, "avisos de «Incorrecte» i notes"),
]
for nom_mode, paleta in (("clar", clar), ("fosc", fosc)):
    sup = a_rgb(paleta["--superficie"])
    def valor(v, sota):
        return a_rgb(v if v.startswith("#") else paleta[v], sota)
    pitjor = None
    for pp, fons, minim, on in PARELLES:
        base = a_rgb(paleta[fons]) if fons in ("--fons", "--camp") else sup
        fons_rgb = valor(fons, sup)
        r = contrast(valor(pp, fons_rgb if fons in ("--fons", "--camp") else base), fons_rgb)
        comprova(r >= minim, f"contrast en mode {nom_mode}: {pp} sobre {fons} fa {r:.2f}:1 "
                             f"i en cal {minim}:1 ({on})")
        if pitjor is None or r / minim < pitjor[0] / pitjor[1]:
            pitjor = (r, minim, pp, fons)
    print(f"  mode {nom_mode}: {len(PARELLES)} parelles · la més justa, {pitjor[2]} sobre "
          f"{pitjor[3]}: {pitjor[0]:.2f}:1 (mínim {pitjor[1]}:1)")

print("\nDESPLEGAMENT")
# Encadenar CSS amb @import bloqueja el pintat: tokens.css s'enllaça des de l'HTML.
for c in sorted(glob.glob(ruta('css', '*.css'))):
    comprova('@import' not in open(c, encoding='utf-8').read(),
             f"{os.path.basename(c)} fa @import; enllaça tokens.css des de l'HTML")
print(f"  cap @import als fulls d'estil: {all('@import' not in open(c, encoding='utf-8').read() for c in glob.glob(ruta('css','*.css')))}")

# El navegador no renderitza Markdown: se'l baixa.
md = []
for f in glob.glob(ruta('*.html')):
    md += [(os.path.basename(f), u) for u in re.findall(r'href="([^"]+\.md)"', open(f, encoding='utf-8').read())]
comprova(not md, f"hi ha enllaços a Markdown des de les pàgines: {md}")
print(f"  enllaços a .md des de les pàgines: {len(md)}")

for necessari in ('_headers', 'robots.txt', '404.html', 'favicon.svg', '.gitignore'):
    comprova(os.path.exists(os.path.join(REPO, necessari)), f"falta {necessari} a l'arrel")
print("  fitxers de desplegament: tots presents")

print("\nANONIMAT")
# El material no ha d'anomenar mai el curs, el tipus d'aula ni el diagnòstic,
# ni parlar d'un alumne en singular. Es descriu alumnat amb dificultats de
# tipus cognitiu, i prou. Es mira tot el repositori, perquè tot es publica.
# L'excepció són els noms de carpeta 4eso/ i 1eso/: fan visible el curs a les
# adreces, i és una decisió presa. Per això «4eso» només passa dins d'una ruta,
# amb una barra al costat; en el text, continua prohibit.
CURS = [r"4t ESO", r"(?<![/\w])4eso(?![/\w])", r"4t d'ESO", r"4t A\b", r"\bde 4t\b"]
PROHIBITS = CURS + [r"\bSIEI\b", r"\bDIL\b", r"discapacitat intel",
                    r"\bl'alumne\b", r"\bun alumne\b", r"\baquest alumne\b"]
# L'altra excepció: la portada de l'arrel (index.html) sí que pot dir el curs de cada
# material. Ho va decidir el docent el 26/9/2026: allà no cal amagar-lo. Els altres
# termes (el diagnòstic, «l'alumne») hi continuen prohibits, i el curs, a tot arreu més.
PORTADA = os.path.join(REPO, 'index.html')
# I other-versions/ no es mira: són les dues versions que va fer una IA, per comparar-les
# amb aquest projecte (index.html?other-versions=1). El docent va decidir el 23/10/2026
# deixar-les tal com les va fer la IA, amb el curs i el diagnòstic que hi surten.
ALTRES_VERSIONS = os.path.join(REPO, 'other-versions') + os.sep
trobats = []
for f in (glob.glob(os.path.join(REPO, '**', '*.md'), recursive=True)
          + glob.glob(os.path.join(REPO, '**', '*.html'), recursive=True)
          + glob.glob(os.path.join(REPO, '**', '*.js'), recursive=True)
          + glob.glob(os.path.join(REPO, '**', '*.css'), recursive=True)):
    if os.path.abspath(f).startswith(ALTRES_VERSIONS):
        continue
    text = open(f, encoding='utf-8').read()
    for patro in PROHIBITS:
        if os.path.abspath(f) == os.path.abspath(PORTADA) and patro in CURS:
            continue
        for m in re.finditer(patro, text, re.I):
            trobats.append((os.path.relpath(f, REPO), m.group(0)))
comprova(not trobats, f"termes que trenquen l'anonimat: {trobats[:6]}")
print(f"  termes que trencarien l'anonimat: {len(trobats)}")

# Dignitat: el que llegeix l'alumnat no diu que és adaptat, ni al títol de la
# pestanya, que també és el títol del PDF. Com a 1eso/ (regla J). El
# solucionari és per a l'adult i pot parlar del mapa d'adaptació.
adaptat = []
for f in sorted(glob.glob(ruta('fitxes', '*.html')) + glob.glob(ruta('targetes', '*.html'))):
    text = re.sub(r'<!--.*?-->', '', open(f, encoding='utf-8').read(), flags=re.S)
    cap = text[:text.index('<body>')]
    alumnat = [b for b in re.findall(r'<div class="full[^"]*">.*?\n</div>', text, re.S)
               if 'class="full sol"' not in b]
    for tros in [cap] + alumnat:
        adaptat += [(os.path.basename(f), m.group(0))
                    for m in re.finditer(r'adapta(t|da|ts|des|ció|cions)\b', tros, re.I)]
for f in (ruta('caixa-eines.html'), ruta('dades', 'textos.js')):
    text = re.sub(r'<!--.*?-->|/\*.*?\*/', '', open(f, encoding='utf-8').read(), flags=re.S)
    adaptat += [(os.path.basename(f), m.group(0)) for m in re.finditer(r'adapta\w*', text, re.I)]
comprova(not adaptat, f"l'alumnat no ha de llegir «adaptat»: {adaptat[:6]}")
print(f"  «adaptat» on ho llegeix l'alumnat: {len(adaptat)}")

# El terme matemàtic és «enter», no «sencer», quan parla de nombres. És la decisió del
# docent en revisar l'examen de la UD1 (comu/docs/EXAMENS-DOCX.md), la mateixa regla I de
# 1eso/. Fins al 6/10/2026, la caixa, la fitxa i el repàs de la UD1 deien «sencers» i
# l'examen, «enters». «Metres sencers» o «la barra sencera» són català correcte i s'hi queden.
SENCER = re.compile(r'\b(nombres?|quantitats?|coses?|xifres?|dos)\s+sencer(s|a|es)?\b', re.I)
sencers = []
for f in (sorted(glob.glob(ruta('fitxes', '*.html')) + glob.glob(ruta('targetes', '*.html')))
          + [ruta('caixa-eines.html'), ruta('dades', 'textos.js')]):
    text = re.sub(r'<!--.*?-->|/\*.*?\*/', '', open(f, encoding='utf-8').read(), flags=re.S)
    sencers += [(os.path.basename(f), m.group(0)) for m in SENCER.finditer(text)]
comprova(not sencers, f"«sencer» parlant de nombres (el terme és «enter»): {sencers[:6]}")
print(f"  «sencer» parlant de nombres: {len(sencers)}")

print("\nDEPENDÈNCIES EXTERNES")
remots = []
for f in glob.glob(os.path.join(REPO, '**', '*.html'), recursive=True) + glob.glob(ruta('css', '*.css')):
    for u in re.findall(r'(?:src|href)="(https?://[^"]+)"', open(f, encoding='utf-8').read()):
        remots.append((os.path.relpath(f, REPO), u))
comprova(not remots, f"recursos remots: {remots}")
print(f"  recursos remots: {len(remots)}")

print("\nDADES")
dades = open(ruta('dades', 'unitats.js'), encoding='utf-8').read()
unitats = re.findall(r'fitxa: "(fitxes/[\w-]+\.html)"', dades)
repassos = re.findall(r'tancament: "(fitxes/[\w-]+\.html)"', dades)
targetes = re.findall(r'\{ nom: "([\w-]+)"', dades)
for u in unitats + repassos:
    comprova(os.path.exists(ruta(u)), f"dades/unitats.js apunta a {u}, que no existeix")
# Les tasques de cada unitat: unitat.html obre la caixa amb només aquestes pestanyes
# (caixa-eines.html?ud=N&tasques=…). Han d'existir, i han d'incloure les dels mòduls.
caixa_tasques = dict(re.findall(r'data-tasca="(\d+)" data-mod="(\w+)"', app))
mod_tasca = {m: t for t, m in caixa_tasques.items()}
for num_u, mods, tasq in re.findall(r'num: (\d+),.*?moduls: \[([^\]]*)\], tasques: \[([^\]]*)\]', dades, re.S):
    tasq = {t.strip() for t in tasq.split(',') if t.strip()}
    comprova(tasq <= set(caixa_tasques), f"dades/unitats.js: la unitat {num_u} té tasques que no són a la caixa: {sorted(tasq - set(caixa_tasques))}")
    falten = {mod_tasca.get(m) for m in re.findall(r'"(\w+)"', mods)} - tasq
    comprova(not falten, f"dades/unitats.js: a les tasques de la unitat {num_u} hi falten les dels seus mòduls: {sorted(falten)}")
comprova(len(re.findall(r'tasques: \[', dades)) == len(unitats), "dades/unitats.js: cada unitat ha de tenir el camp tasques")
comprova(os.path.exists(ruta('unitat.html')), "falta unitat.html, la pàgina de cada unitat")
quaderns = re.findall(r'quadern: "(quadern/[\w-]+\.html)"', dades)
for q in quaderns:
    comprova(os.path.exists(ruta(q)), f"dades/unitats.js apunta a {q}, que no existeix")
comprova(sorted(quaderns) == sorted(os.path.relpath(f, ARREL) for f in glob.glob(ruta('quadern', '*.html'))),
         "els quaderns declarats a dades/unitats.js no coincideixen amb els de quadern/")
for n in targetes:
    comprova(os.path.exists(ruta('targetes', n + '.html')), f"dades/unitats.js apunta a la targeta {n}, que no existeix")
al_disc = glob.glob(ruta('fitxes', '*.html'))
comprova(len(unitats) + len(repassos) == len(al_disc),
         "el nombre de fitxes declarades no coincideix amb el de fitxes al disc")
comprova(sorted(targetes) == sorted(os.path.basename(f)[:-5] for f in glob.glob(ruta('targetes', '*.html'))),
         "les targetes declarades no coincideixen amb les de targetes/")
print(f"  unitats: {len(unitats)} · fitxes de repàs: {len(repassos)} · fitxes al disc: {len(al_disc)}"
      f" · quaderns: {len(quaderns)} · targetes: {len(targetes)}")

def UNITATS_DE_LA_TARGETA(nom):
    m = re.search(r'nom:\s*"%s".*?unitats:\s*\[([^\]]*)\]' % re.escape(nom), dades)
    return [int(x) for x in re.findall(r'\d+', m[1])] if m else []


# --------------------------------------------------------------------------
print("\nNAVEGACIÓ")
# L'esquema és sempre curs → unitat → fitxa, quadern o caixa d'eines (5/11/2026, per encàrrec
# del docent). Tot el que és del tercer nivell torna a la pàgina de la seva unitat
# (unitat.html?ud=N), mai a una llista plana, i la unitat torna a la portada. Per això:
#   · cada fitxa (i cada quadern) té com a primer enllaç «← unitat N» (o «← la unitat», al
#     quadern), i la N és la unitat que la declara a dades/unitats.js;
#   · cada targeta de consulta torna a la unitat on neix i carrega comu/js/torna.js, que la fa
#     tornar a la unitat d'on ve (?ud=N);
#   · cap pàgina ni cap JS no enllaça fitxes.html ni quadern.html, que ja no existeixen.
# --------------------------------------------------------------------------
def _primer_enllac(text):
    m = re.search(r'<nav class="navega[^>]*>\s*<a ([^>]*)>([^<]*)</a>', text)
    return (m[1], m[2]) if m else ("", "")

_unitat_de = {}
for _bloc in re.findall(r'^  \{\n(.*?)^  \},?$', dades, re.S | re.M):
    _n = re.search(r'^    num:\s*(\d+)', _bloc, re.M)
    if not _n:
        continue
    for _f in re.findall(r'(?:fitxa|tancament|quadern):\s*"([^"]+)"', _bloc):
        _unitat_de[_f] = int(_n[1])
n_nav = 0
for _f, _n in sorted(_unitat_de.items()):
    if not os.path.exists(ruta(_f)):
        continue
    _attrs, _text = _primer_enllac(open(ruta(_f), encoding='utf-8').read())
    _text_bo = _text in (f"← unitat {_n}", "← la unitat")
    n_nav += 1
    comprova(f'href="../unitat.html?ud={_n}"' in _attrs and _text_bo,
             f"{_f}: el primer enllaç de dalt ha de tornar a la unitat {_n} (../unitat.html?ud={_n}), "
             f"i és «{_text}» ({_attrs})")
for _f in sorted(glob.glob(ruta('targetes', '*.html'))):
    _nom = os.path.basename(_f)[:-5]
    _t = open(_f, encoding='utf-8').read()
    _attrs, _text = _primer_enllac(_t)
    _units = UNITATS_DE_LA_TARGETA(_nom)
    n_nav += 1
    comprova(bool(_units) and 'data-unitat' in _attrs and f'href="../unitat.html?ud={_units[0]}"' in _attrs
             and _text == f"← unitat {_units[0]}",
             f"targetes/{_nom}.html: ha de tornar a la unitat {_units[:1]} (data-unitat, ../unitat.html?ud=N): "
             f"«{_text}» ({_attrs})")
    comprova('<script src="../../comu/js/torna.js"></script>' in _t,
             f"targetes/{_nom}.html: falta comu/js/torna.js, que la fa tornar a la unitat d'on ve")
_enllacos_morts = []
for _f in glob.glob(os.path.join(ARREL, '**', '*.html'), recursive=True) + glob.glob(ruta('js', '*.js')):
    if re.search(r"""(?:href\s*=|\.href\s*=)\s*["'](?:\.\./)?(?:fitxes|quadern)\.html""",
                 open(_f, encoding='utf-8').read()):
        _enllacos_morts.append(os.path.relpath(_f, REPO))
comprova(not _enllacos_morts, f"enllaços a fitxes.html o quadern.html, que ja no hi són: {_enllacos_morts}")
print(f"  pàgines que tornen a la seva unitat: {n_nav} · enllaços a pàgines planes: {len(_enllacos_morts)}")

print()
if falles:
    print(f"{len(falles)} PROBLEMES:")
    for f in falles:
        print("  ·", f)
    sys.exit(1)
print("Tot correcte.")

#!/usr/bin/env python3
"""
eines/prova_caixa.py · la caixa d'eines, provada de debò en un navegador
=========================================================================

Obre caixa-eines.html en Chromium i fa el que faria l'alumnat: toca, s'equivoca,
llegeix la pista, s'hi torna i acaba les cinc tasques tancades. Després llegeix
els cinc codis a verifica.html. Si alguna cosa no respon com diu la
documentació, ho diu i acaba amb error.

    python3 1eso/eines/prova_caixa.py

Necessita Playwright amb Chromium:
    pip install playwright && python3 -m playwright install chromium

QUÈ COMPROVA
  · Cap error de JavaScript i cap frase sense definir («[1.2.titol]»).
  · Cap nombre de més de 999, cap «×» i cap «x» de multiplicar a la pantalla.
  · La gramàtica que es fa sola: «1 fila d'1 quadret», «5 files d'11 quadrets»,
    «la taula de l'1», «l'arrel quadrada d'11».
  · Com es llegeixen els nombres: vint-i-u, cent u, dos-cents quaranta-tres…
  · Les dades dels mòduls: sumes sense portar-ne, multiplicacions de la
    targeta, i cap cas que no es pugui fer amb el material.
  · Les cinc tasques tancades de punta a punta: encert, encert amb pista i
    resposta ensenyada, el resum i el codi, i que verifica.html el llegeix.
  · La represa d'una tasca a mitges, els enllaços ?task=n i ?task=n.m, i que
    totes les claus del navegador comencen per «pi1-».

No substitueix auditoria.py (contrast i mides, en clar i en fosc): el
complementa. Les dues s'han de passar abans de lliurar.
"""
import os
import pathlib
import re
import sys

# Només si hi és: al Codespace, Playwright desa el Chromium a la seva carpeta
# de sempre, i forçar-ne una altra el faria petar.
if os.path.isdir("/opt/pw-browsers"):
    os.environ.setdefault("PLAYWRIGHT_BROWSERS_PATH", "/opt/pw-browsers")
try:
    from playwright.sync_api import sync_playwright
except ImportError:
    sys.exit("Cal Playwright: pip install playwright && python3 -m playwright install chromium")

ARREL = pathlib.Path(__file__).resolve().parent.parent
CAIXA = (ARREL / "caixa-eines.html").as_uri()
VERIFICA = (ARREL / "verifica.html").as_uri()

errors = []


def comprova(condicio, missatge):
    if not condicio:
        errors.append(missatge)
        print("  ✗", missatge)
    return condicio


def titol(t):
    print("\n" + t)


# ------------------------------------------------------------------ eines --
def obre(pg, url=CAIXA):
    pg.goto(url)
    pg.wait_for_timeout(250)


def modul(pg, mod, sub=1):
    """Obre la pestanya i hi va a la subtasca `sub` amb les fletxes."""
    pg.click(f'.segment[data-mod="{mod}"]')
    pg.wait_for_timeout(80)
    for _ in range(12):
        ara = pg.inner_text(f"#mod-{mod} .sub-rotul")
        n = int(re.match(r"\s*\d+\.(\d+)", ara).group(1))
        if n == sub:
            return
        pg.click(f"#mod-{mod} .sub-" + ("avant" if n < sub else "enrere"))
        pg.wait_for_timeout(80)


def text(pg, sel):
    return pg.inner_text(sel).replace("\u00a0", " ")


def toca_cella(pg, sel, f, c):
    """Toca el quadret de la fila f i la columna c de la taula de quadrets
    (viewBox 340, marge 36, quadret de 30: js/quadricula.js)."""
    caixa = pg.locator(sel).bounding_box()
    x = caixa["x"] + (36 + (c - 0.5) * 30) / 340 * caixa["width"]
    y = caixa["y"] + (36 + (f - 0.5) * 30) / 340 * caixa["height"]
    pg.mouse.click(x, y)
    pg.wait_for_timeout(60)


def final_de(pg, prefix):
    """El resum del final: {'passos': 5, 'primer': 3, …} i el codi."""
    fin = text(pg, f"#{prefix}-final")
    nums = dict(re.findall(r"(Passos|Correctes al primer intent|Correctes amb una pista|Amb la resposta ensenyada)\s*(\d+)", fin))
    codi = re.search(r"[0-9A-Z]{3}-[0-9A-Z]{3}-[0-9A-Z]{3}", fin)
    return nums, codi.group(0) if codi else None


def revisa_pantalla(pg, on):
    """Les regles del curs que es poden mirar al text que es veu."""
    visible = pg.evaluate("() => document.querySelector('.modul:not([hidden])').innerText")
    comprova(not re.search(r"\[[\w.]+\]", visible), f"{on}: frase sense definir: {re.findall(r'\[[\w.]+\]', visible)}")
    comprova("×" not in visible, f"{on}: surt «×»")
    comprova(not re.search(r"\d\s*[xX]\s*\d", visible), f"{on}: una «x» multiplica")
    grans = [int(n) for n in re.findall(r"\d+", visible) if int(n) > 999]
    comprova(not grans, f"{on}: nombres de més de 999: {grans}")
    # Els decimals de la unitat 5: fins a 9,99, amb dues xifres decimals com a molt.
    fora = [m.group(0) for m in re.finditer(r"(?<![\d,])(\d+),(\d+)(?![\d,])", visible)
            if int(m.group(1)) > 9 or len(m.group(2)) > 2]
    comprova(not fora, f"{on}: decimals de més de 9,99 o amb més de dues xifres: {fora}")


def llegeix_codi(pg, codi):
    obre(pg, VERIFICA)
    pg.fill("#codis", codi)
    pg.wait_for_timeout(100)
    return text(pg, "#resultats")


# ================================================================ proves ==
def main():
    with sync_playwright() as p:
        nav = p.chromium.launch()
        ctx = nav.new_context(viewport={"width": 1100, "height": 900})
        pg = ctx.new_page()
        consola = []
        pg.on("pageerror", lambda e: consola.append("error de pàgina: " + str(e)))
        pg.on("console", lambda m: consola.append(m.text) if m.type == "error" else None)
        codis = {}

        # ------------------------------------------------------------------
        titol("TOTES LES SUBTASQUES S'OBREN")
        obre(pg)
        subs = [("taules", 3), ("rect", 4), ("quadrat", 4), ("cdu", 2), ("ordre", 2),
                ("multiples", 4), ("repartir", 2), ("divisors", 2), ("primers", 2),
                ("fraccio", 2), ("equivalents", 2), ("compara", 2), ("sumes", 2), ("area", 2),
                ("fraccnombre", 2), ("multfrac", 2), ("percentatges", 2), ("dobletriple", 2),
                ("decimals", 3), ("arrodonir", 2), ("sumadec", 2), ("fracdec", 2)]
        for mod, n in subs:
            for sub in range(1, n + 1):
                modul(pg, mod, sub)
                pg.wait_for_timeout(120)
                revisa_pantalla(pg, f"{mod} {sub}")
        print(f"  {sum(n for _, n in subs)} subtasques, cap frase sense definir, cap nombre de més de 999 "
              f"i cap decimal de més de 9,99: {not errors}")

        # ------------------------------------------------------------------
        titol("DADES DELS MÒDULS")
        d = pg.evaluate("""() => ({
            parteix: CE.dades.rect.PARTEIX, per_fer: CE.dades.rect.PER_FER,
            gira: CE.dades.rect.GIRA, dificils: CE.dades.taules.DIFICILS, falta: CE.dades.taules.FALTA,
            ns: CE.dades.quadrat.NS, zero: CE.dades.cdu.AMB_ZERO, sense: CE.dades.cdu.SENSE_ZERO,
            expr: CE.dades.ordre.EXPR.map(e => Object.assign({ passos: CE.dades.ordre.passos(e),
                                                              escrit: CE.dades.ordre.escriu(e) }, e)) })""")

        def sense_portar(x, y):
            while x or y:
                if x % 10 + y % 10 > 9:
                    return False
                x, y = x // 10, y // 10
            return True

        for c in d["parteix"]:
            a, n = c["a"], c["n"]
            comprova(10 < n < 20 and a <= 10, f"1.4: {a} · {n} no es parteix en 10 + una xifra")
            comprova(sense_portar(a * 10, a * (n - 10)), f"1.4: {a * 10} + {a * (n - 10)} s'ha de portar")
        for a, b in d["per_fer"] + [[g["a"], g["b"]] for g in d["gira"]]:
            comprova(1 < a <= 10 and 1 < b <= 10, f"rectangles: {a} · {b} no és de la targeta")
        comprova(all(6 <= a <= 9 and 6 <= b <= 9 for a, b in d["dificils"]), "0.2: hi ha multiplicacions fàcils")
        comprova(all(2 <= c["a"] <= 9 and 2 <= c["b"] <= 9 and c["a"] != c["b"] for c in d["falta"]),
                 "0.3: hi ha multiplicacions que no són de la targeta, o amb els dos números iguals")
        comprova(sum(c["falta"] == "b" for c in d["falta"]) >= 3 and sum(c["falta"] == "a" for c in d["falta"]) >= 2,
                 "0.3: calen com a mínim tres casos amb el forat al segon número i dos al primer")
        comprova(2 not in d["ns"], "2.2: el 2 no hi pot ser (2² i 2 · 2 són el mateix dibuix)")
        comprova(all("0" in str(n) for n in d["zero"]), "3.2: AMB_ZERO té nombres sense zero")
        comprova(all(n <= 999 for n in d["zero"] + d["sense"]), "3.2: nombres de més de 999")
        for e in d["expr"]:
            p_ = e["passos"]
            if e["t"] in ("sm", "ms"):
                comprova(e["b"] <= 10 and e["c"] <= 10 and sense_portar(e["a"], e["b"] * e["c"]),
                         f"4: {e['escrit']} demana portar-ne o surt de la targeta")
            else:
                comprova(sense_portar(e["a"], e["b"]) and e["a"] + e["b"] <= 10 and e["c"] <= 10,
                         f"4: {e['escrit']} demana portar-ne o surt de la targeta")
            comprova(p_["r2"] <= 100, f"4: {e['escrit']} = {p_['r2']} és massa gran")
        print("  1.4 i 4 sense portar-ne; multiplicacions de la targeta; 3.2 amb zeros: "
              f"{not [x for x in errors if x[:3] in ('1.4', '4: ', '0.2', '2.2', '3.2', 'rec')]}")

        # ------------------------------------------------------------------
        titol("COM ES LLEGEIXEN ELS NOMBRES")
        noms = {0: "zero", 1: "u", 11: "onze", 16: "setze", 17: "disset", 18: "divuit", 19: "dinou",
                20: "vint", 21: "vint-i-u", 29: "vint-i-nou", 30: "trenta", 31: "trenta-u",
                45: "quaranta-cinc", 80: "vuitanta", 99: "noranta-nou", 100: "cent", 101: "cent u",
                110: "cent deu", 121: "cent vint-i-u", 200: "dos-cents", 243: "dos-cents quaranta-tres",
                305: "tres-cents cinc", 510: "cinc-cents deu", 999: "nou-cents noranta-nou"}
        for n, esperat in noms.items():
            fet = pg.evaluate(f"CE.dades.cdu.nomDe({n})")
            comprova(fet == esperat, f"nom del {n}: «{fet}» i hauria de ser «{esperat}»")
        tots = pg.evaluate("Array.from({length: 1000}, (_, i) => CE.dades.cdu.nomDe(i))")
        comprova(len(set(tots)) == 1000, "dos nombres es llegeixen igual")
        comprova(all(re.fullmatch(r"[a-z]+(-[a-z]+)*( [a-z]+(-i?-?[a-z]+)*)?", t) for t in tots),
                 "algun nom té espais o guions de més")
        print(f"  {len(noms)} nombres de mostra i els 1.000 de l'1 al 999, tots diferents")

        # ------------------------------------------------------------------
        titol("0.1 · LA TAULA")
        obre(pg)
        modul(pg, "taules", 1)
        comprova("7 · 8 = 56" in text(pg, "#tt-lectura"), "0.1 no s'obre amb 7 · 8 = 56")
        comprova("Busca la taula del 7." in text(pg, "#tt-clau"), "0.1: la clau no és la de la targeta")
        comprova(pg.is_hidden("#tt-sencera") and pg.get_attribute("#tt-veure", "aria-expanded") == "false"
                 and text(pg, "#tt-veure") == "Veure tota la taula", "0.1: la taula ha de començar plegada")
        pg.click("#tt-pastilles .pastilla >> nth=0")
        pg.click("#tt-per .pastilla >> nth=0")
        comprova("1 fila d'1 quadret." in text(pg, "#tt-lectura"), "0.1: «1 fila d'1 quadret.»")
        comprova("En total, 1 quadret." in text(pg, "#tt-lectura"), "0.1: «En total, 1 quadret.»")
        pg.click("#tt-veure")
        comprova(pg.is_visible("#tt-sencera") and pg.get_attribute("#tt-veure", "aria-expanded") == "true"
                 and text(pg, "#tt-veure") == "Amaga la taula", "0.1: el botó no obre la taula")
        comprova(text(pg, "#tt-nom") == "La taula de l'1", "0.1: «La taula de l'1»")
        pg.click("#tt-pastilles .pastilla >> nth=9")
        pg.click("#tt-llista .fila-taula >> nth=9")
        comprova("10 · 10 = 100" in text(pg, "#tt-lectura"), "0.1: 10 · 10 = 100")
        comprova(pg.get_attribute("#tt-per .pastilla >> nth=9", "aria-pressed") == "true",
                 "0.1: tocar una fila de la taula no marca el segon número")
        comprova(pg.is_hidden("#tt-marca"), "0.1: la marca «Exemple» es queda amb un altre cas")
        pg.click("#tt-veure")
        comprova(pg.is_hidden("#tt-sencera"), "0.1: el botó no plega la taula")
        print("  s'obre amb 7 · 8 i la taula plegada; «de l'1», «d'1 quadret»; la fila i la pastilla, lligades")

        # ------------------------------------------------------------------
        titol("0.2 · TROBA EL RESULTAT A LA TAULA")
        modul(pg, "taules", 2)

        def pregunta_02():
            a, b = map(int, re.findall(r"\d+", text(pg, "#tb-pregunta")))
            return a, b

        def taula(n):
            pg.click(f"#tb-pastilles .pastilla >> nth={n - 1}")
            pg.wait_for_timeout(40)

        def fila(n):
            pg.click(f"#tb-llista .fila-taula >> nth={n - 1}")
            pg.wait_for_timeout(40)

        # pas 1: taula dolenta, i després bé → correcte amb pista
        a, b = pregunta_02()
        comprova(text(pg, "#tb-avis") == "Tria una taula.", "0.2: l'avís del principi")
        comprova(pg.locator("#tb-seguent").is_disabled(), "0.2: «Següent pas» actiu abans de contestar")
        taula(2)
        comprova(text(pg, "#tb-avis") == "Ara toca una fila.", "0.2: l'avís després de triar la taula")
        fila(3)
        av = text(pg, "#tb-avis")
        comprova(av.startswith("Incorrecte.") and "Tria la taula del" in av, f"0.2: pista de la taula: «{av}»")
        taula(a); fila(b)
        comprova(text(pg, "#tb-avis").startswith("Correcte."), "0.2: correcte després de la pista")
        pg.click("#tb-seguent")
        # pas 2: bé a la primera
        a, b = pregunta_02(); taula(a); fila(b)
        comprova(text(pg, "#tb-avis") == f"Correcte. {a} · {b} = {a * b}.", "0.2: resposta correcta")
        pg.click("#tb-seguent")
        # pas 3: dos errors → la caixa ensenya la fila
        a, b = pregunta_02(); taula(a); fila(b % 10 + 1)
        comprova("Ara baixa per la taula" in text(pg, "#tb-avis"), "0.2: pista de la fila")
        fila((b + 1) % 10 + 1)
        av = text(pg, "#tb-avis")
        comprova(av.startswith("Incorrecte. Mira la fila marcada"), f"0.2: segon error: «{av}»")
        comprova(pg.locator("#tb-llista .fila-taula.bona").count() == 1, "0.2: no es marca la fila bona")
        pg.click("#tb-seguent")
        # pas 4: la fila girada
        a, b = pregunta_02(); taula(b); fila(a)
        av = text(pg, "#tb-avis")
        # Amb 7 · 7 la fila girada és la mateixa fila: la caixa no ha de dir que és girada.
        comprova(av.startswith("Correcte.") and (("És el mateix que" in av) == (a != b)),
                 f"0.2: la fila girada no compta: «{av}»")
        pg.click("#tb-seguent")
        # pas 5
        a, b = pregunta_02(); taula(a); fila(b)
        pg.click("#tb-seguent")
        nums, codi = final_de(pg, "tb")
        comprova(nums == {"Passos": "5", "Correctes al primer intent": "3", "Correctes amb una pista": "1",
                          "Amb la resposta ensenyada": "1"}, f"0.2: el resum no quadra: {nums}")
        comprova(bool(codi), "0.2: no surt el codi")
        codis["0.2"] = (codi, "Troba el resultat a la taula", (5, 3, 1, 1))
        print(f"  pista de la taula, pista de la fila, fila girada, fila ensenyada; codi {codi}")

        # ------------------------------------------------------------------
        titol("0.3 · EL NÚMERO QUE FALTA")
        obre(pg)
        modul(pg, "taules", 3)

        def pregunta_03():
            """(el número que es té, el que falta, el resultat, si falta el primer)"""
            t = text(pg, "#tf-expr")
            k, p_ = [int(x) for x in re.findall(r"\d+", t)]
            return k, p_ // k, p_, t.strip().startswith("…")

        def taula3(n):
            pg.click(f"#tf-pastilles .pastilla >> nth={n - 1}")
            pg.wait_for_timeout(40)

        def fila3(n):
            pg.click(f"#tf-llista .fila-taula >> nth={n - 1}")
            pg.wait_for_timeout(40)

        vist_primer = vist_segon = False
        # pas 1: la taula dolenta, i després bé → correcte amb pista
        k, x, p_, fp = pregunta_03()
        vist_primer |= fp; vist_segon |= not fp
        comprova(text(pg, "#tf-avis") == "Tria una taula.", "0.3: l'avís del principi")
        comprova("…" in text(pg, "#tf-expr"), "0.3: el forat no es veu")
        taula3(next(n for n in range(2, 11) if n not in (k, x)))
        comprova(text(pg, "#tf-avis") == f"Ara busca la fila on surt el {p_}.", "0.3: l'avís després de triar la taula")
        fila3(1)
        av = text(pg, "#tf-avis")
        comprova(av.startswith("Incorrecte.") and f"Tria la taula del {k}" in av, f"0.3: pista de la taula: «{av}»")
        taula3(k); fila3(x)
        av = text(pg, "#tf-avis")
        comprova(av.startswith("Correcte.") and f"El número que falta és el {x}." in av, f"0.3: correcte amb pista: «{av}»")
        comprova("…" not in text(pg, "#tf-expr") and str(x) in text(pg, "#tf-expr"), "0.3: el forat no s'omple")
        comprova(("És el mateix que" in av) == fp, "0.3: el girat només s'ha de dir quan falta el primer número")
        pg.click("#tf-seguent")
        # pas 2: bé a la primera
        k, x, p_, fp = pregunta_03(); vist_primer |= fp; vist_segon |= not fp
        taula3(k); fila3(x)
        comprova(text(pg, "#tf-avis").startswith("Correcte."), "0.3: resposta correcta")
        pg.click("#tf-seguent")
        # pas 3: dos errors → la caixa ensenya la fila
        k, x, p_, fp = pregunta_03(); vist_primer |= fp; vist_segon |= not fp
        taula3(k); fila3(x % 10 + 1)
        comprova(f"Baixa per la taula fins que trobis el {p_}." in text(pg, "#tf-avis"), "0.3: pista de la fila")
        fila3((x + 1) % 10 + 1)
        av = text(pg, "#tf-avis")
        comprova(av.startswith("Incorrecte. Mira la fila marcada") and f"el {x}." in av, f"0.3: segon error: «{av}»")
        comprova(pg.locator("#tf-llista .fila-taula.bona").count() == 1, "0.3: no es marca la fila bona")
        pg.click("#tf-seguent")
        # passos 4 i 5: bé
        for _ in range(2):
            k, x, p_, fp = pregunta_03(); vist_primer |= fp; vist_segon |= not fp
            taula3(k); fila3(x)
            pg.click("#tf-seguent")
        comprova(vist_primer and vist_segon, "0.3: han de sortir forats al primer i al segon número")
        nums, codi = final_de(pg, "tf")
        comprova(nums == {"Passos": "5", "Correctes al primer intent": "3", "Correctes amb una pista": "1",
                          "Amb la resposta ensenyada": "1"}, f"0.3: el resum no quadra: {nums}")
        comprova(bool(codi), "0.3: no surt el codi")
        codis["0.3"] = (codi, "El número que falta", (5, 3, 1, 1))
        print(f"  forat al primer i al segon número, pista de la taula i de la fila, ensenyat; codi {codi}")

        # ------------------------------------------------------------------
        titol("1.1 · FES UN RECTANGLE")
        obre(pg)
        modul(pg, "rect", 1)
        comprova("3 · 4 = 12" in text(pg, "#r1-lectura"), "1.1 no s'obre amb 3 · 4")
        toca_cella(pg, "#r1-svg", 5, 6)
        lect = text(pg, "#r1-lectura")
        comprova("5 files de 6 quadrets." in lect and "En total, 30 quadrets." in lect and "5 · 6 = 30" in lect,
                 f"1.1: tocar el quadret 5, 6: «{lect}»")
        pg.click("#r1-files [data-f=menys]")
        comprova("4 · 6 = 24" in text(pg, "#r1-lectura"), "1.1: el comptador de files")
        for _ in range(4):
            pg.click("#r1-files [data-f=menys]")
        comprova("0 · 6 = 0" in text(pg, "#r1-lectura"), "1.1: 0 files → 0 · 6 = 0")
        comprova(pg.locator("#r1-files [data-f=menys]").is_disabled(), "1.1: el − no s'apaga al 0")
        pg.click("#r1-buida")
        comprova(text(pg, "#r1-lectura") == "Toca un quadret de la quadrícula.", "1.1: buida-ho")
        pg.focus("#r1-svg"); pg.keyboard.press("ArrowRight"); pg.keyboard.press("ArrowDown")
        comprova("2 files de 2 quadrets." in text(pg, "#r1-lectura"), "1.1: les fletxes")
        print("  tocar, comptadors, zero, buida-ho i fletxes")

        # ------------------------------------------------------------------
        titol("1.2 · EL RECTANGLE D'UNA MULTIPLICACIÓ")
        modul(pg, "rect", 2)

        def pregunta_12():
            a, b = map(int, re.findall(r"\d+", text(pg, "#r2-pregunta")))
            return a, b

        a, b = pregunta_12(); toca_cella(pg, "#r2-svg", a, b)                      # bé
        comprova(text(pg, "#r2-avis").startswith("Correcte."), "1.2: rectangle bo")
        pg.click("#r2-seguent")
        a, b = pregunta_12(); toca_cella(pg, "#r2-svg", b, a)                      # girat
        comprova("rectangle girat" in text(pg, "#r2-avis") or a == b, "1.2: el girat no compta")
        pg.click("#r2-seguent")
        a, b = pregunta_12(); toca_cella(pg, "#r2-svg", 9, 9)                      # error → pista
        av = text(pg, "#r2-avis")
        comprova(av.startswith("Incorrecte. Has fet 9 files de 9 quadrets.") and "Compta" in av,
                 f"1.2: el primer error: «{av}»")
        comprova(pg.locator("#r2-svg .q-pista").count() == 2, "1.2: la pista no marca els dos números")
        toca_cella(pg, "#r2-svg", a, b)
        comprova(text(pg, "#r2-avis").startswith("Correcte."), "1.2: correcte amb pista")
        pg.click("#r2-seguent")
        a, b = pregunta_12(); toca_cella(pg, "#r2-svg", 10, 10); toca_cella(pg, "#r2-svg", 10, 9)
        av = text(pg, "#r2-avis")
        comprova(av.startswith("Incorrecte. Mira el rectangle"), f"1.2: el segon error: «{av}»")
        comprova(pg.locator("#r2-svg .q").count() == a * b, "1.2: no es dibuixa el rectangle bo")
        pg.click("#r2-seguent")
        a, b = pregunta_12()                                                          # amb el teclat
        pg.focus("#r2-svg"); pg.keyboard.press("Enter")
        for _ in range(a - 1):
            pg.keyboard.press("ArrowDown")
        for _ in range(b - 1):
            pg.keyboard.press("ArrowRight")
        pg.keyboard.press("Enter")
        comprova(text(pg, "#r2-avis").startswith("Correcte."), "1.2: amb el teclat")
        pg.click("#r2-seguent")
        nums, codi = final_de(pg, "r2")
        comprova(nums == {"Passos": "5", "Correctes al primer intent": "3", "Correctes amb una pista": "1",
                          "Amb la resposta ensenyada": "1"}, f"1.2: el resum no quadra: {nums}")
        codis["1.2"] = (codi, "El rectangle d'una multiplicació", (5, 3, 1, 1))
        print(f"  bo, girat, pista amb els números de la vora, ensenyat i amb el teclat; codi {codi}")

        # ------------------------------------------------------------------
        titol("1.3 · GIRA EL RECTANGLE")
        modul(pg, "rect", 3)
        comprova("3 · 4 = 4 · 3" not in text(pg, "#r3-lectura"), "1.3: la igualtat surt abans de girar")
        pg.click("#r3-gira"); pg.wait_for_timeout(900)
        lect = text(pg, "#r3-lectura")
        comprova("4 files de 3 quadrets." in lect and "Hi ha els mateixos quadrets." in lect
                 and "3 · 4 = 4 · 3" in lect, f"1.3: després de girar: «{lect}»")
        comprova(text(pg, "#r3-gira") == "Torna a girar-lo", "1.3: el botó no canvia")
        pg.click("#r3-pastilles .pastilla >> nth=1")
        comprova("2 files de 5 quadrets." in text(pg, "#r3-lectura"), "1.3: canviar de cas no torna a començar")
        print("  la igualtat només surt després de girar-lo")

        # ------------------------------------------------------------------
        titol("1.4 · PARTEIX EL RECTANGLE")
        modul(pg, "rect", 4)
        comprova("3 files de 12 quadrets." in text(pg, "#r4-lectura"), "1.4 no s'obre amb 3 · 12")
        pg.click("#r4-parteix"); pg.wait_for_timeout(700)
        lect = text(pg, "#r4-lectura")
        comprova("30 + 6 = 36" in lect and "3 · 12 = 36" in lect, f"1.4: partit: «{lect}»")
        pg.click("#r4-pastilles .pastilla >> nth=3")
        comprova("5 files d'11 quadrets." in text(pg, "#r4-lectura"), "1.4: «5 files d'11 quadrets»")
        print("  30 + 6 = 36; «d'11 quadrets»")

        # ------------------------------------------------------------------
        titol("2.1 · EL QUADRAT D'UN NOMBRE")
        modul(pg, "quadrat", 1)
        lect = text(pg, "#q1-lectura")
        comprova("3 · 3 = 9" in lect and "3² = 9" in lect and lect.index("3 · 3") < lect.index("3²"),
                 "2.1: primer 3 · 3 = 9 i després 3² = 9")
        pg.click("#q1-pastilles .pastilla >> nth=0")
        comprova("1 fila d'1 quadret." in text(pg, "#q1-lectura") and "1² = 1" in text(pg, "#q1-lectura"),
                 "2.1: el quadrat de l'1")
        print("  el símbol surt després del dibuix i de les paraules")

        # ------------------------------------------------------------------
        titol("2.2 · QUIN DIBUIX ÉS?")
        modul(pg, "quadrat", 2)
        tipus_vistos = set()
        for pas in range(5):
            q = text(pg, "#q2-pregunta")
            bo = "q" if "²" in q else "d"
            tipus_vistos.add(bo)
            comprova(pg.locator("#q2-opcions .peu-dibuix:visible").count() == 0,
                     "2.2: el rètol del dibuix es veu abans de tocar")
            if pas == 1:
                pg.click(f'#q2-opcions .opcio-dibuix[data-o="{"d" if bo == "q" else "q"}"]')
                av = text(pg, "#q2-avis")
                comprova(av.startswith("Incorrecte. Aquest dibuix és"), f"2.2: el primer error: «{av}»")
                comprova(pg.locator("#q2-opcions .opcio-dibuix.mal").is_disabled(),
                         "2.2: el dibuix dolent no s'apaga")
            pg.click(f'#q2-opcions .opcio-dibuix[data-o="{bo}"]')
            comprova(text(pg, "#q2-avis").startswith("Correcte."), f"2.2: pas {pas + 1}")
            comprova(pg.locator("#q2-opcions .peu-dibuix:visible").count() == 2,
                     "2.2: al final no es veuen les dues formes")
            pg.click("#q2-seguent")
        comprova(tipus_vistos == {"q", "d"}, "2.2: no hi ha preguntes dels dos tipus")
        nums, codi = final_de(pg, "q2")
        comprova(nums == {"Passos": "5", "Correctes al primer intent": "4", "Correctes amb una pista": "1",
                          "Amb la resposta ensenyada": "0"}, f"2.2: el resum no quadra: {nums}")
        codis["2.2"] = (codi, "Quin dibuix és?", (5, 4, 1, 0))
        print(f"  n² i n · 2 barrejats; el rètol surt en tocar; codi {codi}")

        # ------------------------------------------------------------------
        titol("2.3 · EL COSTAT DEL QUADRAT")
        modul(pg, "quadrat", 3)
        comprova("√16 = 4" in text(pg, "#q3-lectura"), "2.3 no s'obre amb 16")
        for _ in range(3):
            pg.click("#q3-quants [data-f=menys]")
        lect = text(pg, "#q3-lectura")
        comprova("Amb 13 quadrets no pots fer cap quadrat." in lect and "3 < √13 < 4" in lect
                 and "13 és entre 9 i 16." in lect, f"2.3: 13: «{lect}»")
        comprova(pg.locator("#q3-svg .q.b").count() == 4 and pg.locator("#q3-svg .q.falta").count() == 3,
                 "2.3: 13 → 4 quadrets de més i 3 llocs buits")
        for _ in range(2):
            pg.click("#q3-quants [data-f=menys]")
        comprova("L'arrel quadrada d'11 és entre 3 i 4." in text(pg, "#q3-lectura"), "2.3: «d'11»")
        print("  16 exacte; 13 entre 3 i 4, amb els que sobren i els que falten; «d'11»")

        # ------------------------------------------------------------------
        titol("3.1 · CENTENES, DESENES I UNITATS")
        modul(pg, "cdu", 1)
        comprova("dos-cents quaranta-tres" in text(pg, "#n1-nombre"), "3.1 no s'obre amb 243")
        for _ in range(2):
            pg.click("#n1-c [data-f=menys]")
        for _ in range(2):
            pg.click("#n1-d [data-f=menys]")
        for _ in range(2):
            pg.click("#n1-u [data-f=menys]")
        comprova("vint-i-u" in text(pg, "#n1-nombre")
                 and "0 centenes, 2 desenes i 1 unitat." in (pg.get_attribute("#n1-blocs", "aria-label") or ""),
                 "3.1: 21 → vint-i-u, «1 unitat»")
        comprova(pg.locator("#n1-blocs .zona-et:visible, #n1-blocs .zona-peu:visible").count() == 0,
                 "3.1: el dibuix torna a portar rètols o peus, que repeteixen els comptadors")
        for _ in range(12):                      # fins que el + s'apagui: ha de ser al 9
            if pg.locator("#n1-u [data-f=mes]").is_disabled():
                break
            pg.click("#n1-u [data-f=mes]")
        comprova(text(pg, "#n1-u output") == "9" and pg.locator("#n1-u [data-f=mes]").is_disabled(),
                 "3.1: el + de les unitats no s'apaga al 9")
        print("  243; 21 en singular; sense rètols repetits; no es pot passar de 9")

        # ------------------------------------------------------------------
        titol("3.2 · FES EL NOMBRE")
        modul(pg, "cdu", 2)

        def posa(c, dd, u):
            for k, v in (("c", c), ("d", dd), ("u", u)):
                ara = int(text(pg, f"#n2-{k} output"))
                boto = "mes" if v > ara else "menys"
                for _ in range(abs(v - ara)):
                    pg.click(f"#n2-{k} [data-f={boto}]")

        for pas in range(5):
            n = int(re.search(r"\d+", text(pg, "#n2-pregunta")).group(0))
            c, dd, u = n // 100, n // 10 % 10, n % 10
            if pas == 0:                                  # l'error del zero: 305 fet com a 35
                posa(0, c, u if dd == 0 else dd)
                pg.click("#n2-comprova")
                av = text(pg, "#n2-avis")
                comprova(av.startswith("Incorrecte. Has fet"), f"3.2: el primer error: «{av}»")
                comprova(pg.is_visible("#n2-taula"), "3.2: la pista no ensenya la taula")
            posa(c, dd, u)
            pg.click("#n2-comprova")
            comprova(text(pg, "#n2-avis").startswith("Correcte."), f"3.2: pas {pas + 1} amb {n}")
            pg.click("#n2-seguent")
        nums, codi = final_de(pg, "n2")
        comprova(nums == {"Passos": "5", "Correctes al primer intent": "4", "Correctes amb una pista": "1",
                          "Amb la resposta ensenyada": "0"}, f"3.2: el resum no quadra: {nums}")
        codis["3.2"] = (codi, "Fes el nombre", (5, 4, 1, 0))
        print(f"  el nombre no es veu mentre es fa; la pista és la taula; codi {codi}")

        # ------------------------------------------------------------------
        titol("4.1 · MIRA L'ORDRE")
        modul(pg, "ordre", 1)
        for i, esperat in enumerate(["2 + 3 · 4 = 14", "(2 + 3) · 4 = 20", "5 · 2 + 3 = 13", "4 · (1 + 2) = 12"]):
            pg.click(f"#o1-pastilles .pastilla >> nth={i}")
            comprova(esperat in text(pg, "#o1-lectura"), f"4.1: {esperat}")
        print("  les quatre expressions, amb el total que surt del dibuix")

        # ------------------------------------------------------------------
        titol("4.2 · QUÈ ES FA PRIMER?")
        modul(pg, "ordre", 2)
        amb_par = 0
        for pas in range(5):
            expr = text(pg, "#o2-expr")
            par = "(" in expr
            amb_par += par
            bo, dolent = ("suma", "mult") if par else ("mult", "suma")
            if pas == 2:
                pg.click(f'#o2-expr .signe[data-op="{dolent}"]')
                av = text(pg, "#o2-avis")
                comprova(av.startswith("Incorrecte.") and ("parèntesi" in av if par else "Busca el punt" in av),
                         f"4.2: la pista: «{av}»")
            pg.click(f'#o2-expr .signe[data-op="{bo}"]')
            comprova(text(pg, "#o2-avis").startswith("Correcte. Primer,"), f"4.2: pas {pas + 1}")
            comprova(pg.is_visible("#o2-svg"), "4.2: el dibuix no surt en contestar")
            pg.click("#o2-seguent")
        comprova(amb_par == 2, f"4.2: hi ha d'haver dos passos amb parèntesi, i n'hi ha {amb_par}")
        nums, codi = final_de(pg, "o2")
        comprova(nums == {"Passos": "5", "Correctes al primer intent": "4", "Correctes amb una pista": "1",
                          "Amb la resposta ensenyada": "0"}, f"4.2: el resum no quadra: {nums}")
        codis["4.2"] = (codi, "Què es fa primer?", (5, 4, 1, 0))
        print(f"  dos passos amb parèntesi; la pista depèn del tipus; codi {codi}")

        # ------------------------------------------------------------------
        titol("DADES DE LA UNITAT 2")
        d2 = pg.evaluate("""() => ({ mult: CE.dades.multiples.MULT, tres: CE.dades.multiples.TRES,
            rep: CE.dades.repartir.REPARTIMENTS, div: CE.dades.divisors.DIVIDIR,
            primers: CE.dades.primers.PRIMERS, senars: CE.dades.primers.SENARS })""")
        es_primer = lambda n: n > 1 and all(n % q for q in range(2, int(n ** 0.5) + 1))
        de_targeta = lambda n: any(n % a == 0 and 2 <= a <= 10 and 2 <= n // a <= 10 for a in range(2, 11))
        for n, k in d2["mult"]:
            comprova(n <= 10 * k + k, f"5.2: {n} i {k}: no es pot mirar a la targeta")
        comprova(sum(n % k == 0 for n, k in d2["mult"]) >= 3 and sum(n % k != 0 for n, k in d2["mult"]) >= 2,
                 "5.2: calen tres casos de sí i dos de no, com a mínim")
        for n in d2["tres"]:
            comprova(n <= 999 and 1 <= sum(map(int, str(n))) <= 30, f"5.4: {n}: la suma de les xifres ha de donar de l'1 al 30")
        comprova(sum(n % 3 == 0 for n in d2["tres"]) >= 3 and sum(n % 3 != 0 for n in d2["tres"]) >= 2, "5.4: calen sís i nos")
        for n, k in d2["rep"]:
            comprova(n <= 10 * k + k - 1 and n <= 60, f"6.2: {n} en files de {k}: no es pot mirar a la targeta")
        comprova(sum(n % k != 0 for n, k in d2["rep"]) >= 3 and sum(n % k == 0 for n, k in d2["rep"]) >= 2,
                 "6.2: calen tres casos amb residu i dos d'exactes")
        comprova(all(n <= 30 for n in d2["div"]), "7.2: nombres massa grans per marcar-los tots")
        comprova(all(es_primer(n) for n in d2["primers"]), "8.2: a la llista de primers n'hi ha un que no ho és")
        for n in d2["senars"]:
            comprova(n % 2 == 1 and not es_primer(n) and de_targeta(n),
                     f"8.2: {n} ha de ser senar, no primer, i sortir d'una multiplicació de la targeta")
        print(f"  {len(d2['mult'])} casos de múltiples, {len(d2['tres'])} del 3, {len(d2['rep'])} de repartir, "
              f"{len(d2['primers'])} primers i {len(d2['senars'])} senars compostos, tots de la targeta")

        def mou(pg, sel, fins):
            """Porta el comptador de `sel` fins al valor `fins`."""
            for _ in range(80):
                v = int(text(pg, sel + " .comptador-valor"))
                if v == fins:
                    return
                pg.click(sel + (' [data-f="mes"]' if v < fins else ' [data-f="menys"]'))

        def sino(pg, pref, si):
            pg.click(f'#{pref}-opcions .opcio-sino[data-v="{"si" if si else "no"}"]')

        def tasca_sino(pg, mod, sub, pref, bo, nom, un_error=2):
            """Una tasca tancada de Sí o No, sencera. `bo(pregunta)` diu la resposta bona.
            Al pas `un_error` s'equivoca un cop: ha de sortir la pista."""
            modul(pg, mod, sub)
            for pas in range(5):
                preg = text(pg, f"#{pref}-pregunta")
                resp = bo(preg)
                if pas == un_error:
                    sino(pg, pref, not resp)
                    av = text(pg, f"#{pref}-avis")
                    comprova(av.startswith("Incorrecte.") and "Pista" in av, f"{nom}: la pista del primer error: «{av}»")
                sino(pg, pref, resp)
                comprova(text(pg, f"#{pref}-avis").startswith("Correcte."), f"{nom}: pas {pas + 1}: «{preg}»")
                pg.click(f"#{pref}-seguent")
            nums, codi = final_de(pg, pref)
            comprova(nums == {"Passos": "5", "Correctes al primer intent": "4", "Correctes amb una pista": "1",
                              "Amb la resposta ensenyada": "0"}, f"{nom}: el resum no quadra: {nums}")
            return codi

        # ------------------------------------------------------------------
        titol("5.1 · LA GRAELLA DE 100")
        obre(pg)
        modul(pg, "multiples", 1)
        comprova("Tots acaben en 0, 2, 4, 6 o 8." in text(pg, "#m1-lectura"), "5.1: amb el 2, el truc de l'última xifra")
        comprova(pg.locator("#m1-svg text.fort").count() == 50, "5.1: amb el 2, hi ha d'haver 50 nombres pintats")
        pg.click("#m1-pastilles .pastilla >> nth=1")
        lec = text(pg, "#m1-lectura")
        comprova("No tots acaben en 3." in lec and "n'hi ha 33" in lec, f"5.1: amb el 3: «{lec}»")
        comprova(pg.locator("#m1-svg text.fort").count() == 33, "5.1: amb el 3, hi ha d'haver 33 nombres pintats")
        print("  el 2 pinta 50 nombres i diu el truc; el 3 en pinta 33 i diu la regla trencada")

        titol("5.2 · ÉS MÚLTIPLE?")
        def bo52(p):
            n, k = map(int, re.findall(r"\d+", p))
            return n % k == 0
        codis["5.2"] = (tasca_sino(pg, "multiples", 2, "m2", bo52, "5.2"), "És múltiple?", (5, 4, 1, 0))
        print(f"  cinc passos, un error amb pista; codi {codis['5.2'][0]}")

        titol("5.3 · ELS TRUCS")
        modul(pg, "multiples", 3)
        taula = text(pg, "#t3-trucs")
        comprova("1 + 2 + 6 = 9" in taula and "El 9 és a la taula del 3." in taula, f"5.3: el 126: «{taula}»")
        mou(pg, "#t3-u", 7)
        taula = text(pg, "#t3-trucs")
        comprova("1 + 2 + 7 = 10" in taula and "El 10 no és a la taula del 3." in taula, f"5.3: el 127: «{taula}»")
        mou(pg, "#t3-c", 0); mou(pg, "#t3-d", 2); mou(pg, "#t3-u", 9)
        comprova("2 + 9 = 11" in text(pg, "#t3-trucs") and "L'11 no és a la taula del 3." in text(pg, "#t3-trucs"),
                 f"5.3: el 29 suma 11, amb apòstrof: «{text(pg, '#t3-trucs')}»")
        mou(pg, "#t3-d", 1); mou(pg, "#t3-u", 0)
        comprova("L'1 no és a la taula del 3." in text(pg, "#t3-trucs"), "5.3: el 10 suma 1, amb apòstrof")
        mou(pg, "#t3-d", 0); mou(pg, "#t3-u", 7)
        comprova("Suma les xifres" not in text(pg, "#t3-trucs") and "El 7 no és a la taula del 3." in text(pg, "#t3-trucs"),
                 "5.3: amb una sola xifra no es suma res")
        print("  el 126 i el 127, amb la suma de les xifres; el 29 i el 10, amb apòstrof; el 7, sense suma")

        titol("5.4 · MÚLTIPLE DE 3?")
        bo54 = lambda p: int(re.findall(r"\d+", p)[0]) % 3 == 0
        codis["5.4"] = (tasca_sino(pg, "multiples", 4, "m4", bo54, "5.4"), "Múltiple de 3?", (5, 4, 1, 0))
        print(f"  cinc passos, un error amb pista; codi {codis['5.4'][0]}")

        titol("6.1 · REPARTEIX EN FILES")
        modul(pg, "repartir", 1)
        lec = text(pg, "#r6-lectura")
        comprova("37 = 5 · 7 + 2" in lec and "En sobren 2." in lec and "residu" in lec, f"6.1: 37 en files de 7: «{lec}»")
        mou(pg, "#r6-n", 35)
        lec = text(pg, "#r6-lectura")
        comprova("35 = 5 · 7" in lec and "exacta" in lec, f"6.1: 35 en files de 7: «{lec}»")
        mou(pg, "#r6-n", 36)
        comprova("En sobra 1." in text(pg, "#r6-lectura"), "6.1: amb un sol quadret de més, «En sobra 1.»")
        print("  37 = 5 · 7 + 2 amb el residu; 35, exacta; 36, «En sobra 1.»")

        titol("6.2 · SOBREN QUADRETS?")
        def bo62(p):
            n, k = map(int, re.findall(r"\d+", p))
            return n % k != 0
        codis["6.2"] = (tasca_sino(pg, "repartir", 2, "s6", bo62, "6.2"), "Sobren quadrets?", (5, 4, 1, 0))
        print(f"  cinc passos, un error amb pista; codi {codis['6.2'][0]}")

        titol("7.1 · ELS RECTANGLES D'UN NOMBRE")
        modul(pg, "divisors", 1)
        lec = text(pg, "#d7-lectura")
        comprova("Els divisors de 12 són 1, 2, 3, 4, 6 i 12." in lec and "3 rectangles" in lec, f"7.1: el 12: «{lec}»")
        mou(pg, "#d7-n", 7)
        comprova("El 7 només fa un rectangle, una fila: és primer." in text(pg, "#d7-lectura"), "7.1: el 7 és primer")
        mou(pg, "#d7-n", 1)
        comprova("L'1 només fa un quadret." in text(pg, "#d7-lectura"), "7.1: l'1")
        print("  el 12, 3 rectangles i 6 divisors; el 7, primer; l'1, a part")

        titol("7.2 · TROBA ELS DIVISORS")
        modul(pg, "divisors", 2)
        for pas in range(5):
            n = int(re.findall(r"\d+", text(pg, "#d8-pregunta"))[0])
            divs = [v for v in range(1, n + 1) if n % v == 0]
            if pas == 1:
                intrus = next(v for v in range(2, n) if n % v)
                for v in divs + [intrus]:
                    pg.click(f'#d8-pastilles .pastilla[data-v="{v}"]')
                pg.click("#d8-comprova")
                av = text(pg, "#d8-avis")
                comprova(av.startswith("Incorrecte.") and f"no és divisor de {n}" in av, f"7.2: l'intrús: «{av}»")
                pg.click(f'#d8-pastilles .pastilla[data-v="{intrus}"]')
            else:
                for v in divs:
                    pg.click(f'#d8-pastilles .pastilla[data-v="{v}"]')
            pg.click("#d8-comprova")
            comprova(text(pg, "#d8-avis").startswith("Correcte."), f"7.2: pas {pas + 1}, el {n}")
            comprova(pg.is_visible("#d8-svg"), "7.2: els rectangles no surten en encertar")
            pg.click("#d8-seguent")
        nums, codi = final_de(pg, "d8")
        comprova(nums == {"Passos": "5", "Correctes al primer intent": "4", "Correctes amb una pista": "1",
                          "Amb la resposta ensenyada": "0"}, f"7.2: el resum no quadra: {nums}")
        codis["7.2"] = (codi, "Troba els divisors", (5, 4, 1, 0))
        print(f"  cinc nombres, un intrús que la caixa assenyala; codi {codi}")

        titol("8.1 · EL GARBELL D'ERATÒSTENES")
        modul(pg, "primers", 1)
        comprova(pg.locator("#g8-svg .q-cercle").count() == 25 and "N'hi ha 25." in text(pg, "#g8-lectura"),
                 "8.1: acabat, hi ha d'haver 25 primers encerclats")
        pg.click("#g8-comenca")
        comprova(pg.locator("#g8-svg .q-cercle").count() == 0 and pg.locator("#g8-svg .q-ratlla").count() == 0,
                 "8.1: en tornar a començar, res ratllat ni encerclat")
        pg.click("#g8-avant"); pg.click("#g8-avant")
        comprova(pg.locator("#g8-svg .q-cercle").count() == 1 and pg.locator("#g8-svg .q-ratlla").count() == 50,
                 "8.1: al pas del 2, l'1 i els 49 múltiples del 2 ratllats")
        print("  acabat, 25 primers; tornar a començar ho buida; al pas del 2, 50 ratllats")

        titol("8.2 · ÉS PRIMER?")
        es_p = lambda p: es_primer(int(re.findall(r"\d+", p)[0]))
        senars = 0
        modul(pg, "primers", 2)
        codis["8.2"] = (tasca_sino(pg, "primers", 2, "p8", es_p, "8.2"), "És primer?", (5, 4, 1, 0))
        print(f"  cinc passos, un error amb pista; codi {codis['8.2'][0]}")

        # ------------------------------------------------------------------
        titol("DADES DE LA UNITAT 3 (FRACCIONS)")
        d4 = pg.evaluate("""() => ({ casos: CE.dades.fraccio.CASOS, eq: CE.dades.equivalents.PARELLES,
            cmp: CE.dades.compara.PARELLES, ops: CE.dades.sumes.OPERACIONS })""")
        comprova(all(0 < n < d <= 12 for n, d in d4["casos"]), "9.2: fraccions pròpies, amb denominadors fins al 12")
        eq = [a * d == b * c for a, b, c, d in d4["eq"]]
        comprova(sum(eq) >= 3 and eq.count(False) >= 2 and all(max(b, d) <= 12 for a, b, c, d in d4["eq"]),
                 "10.2: calen tres parelles equivalents i dues que no, amb denominadors fins al 12")
        comprova(all(a * d != b * c for a, b, c, d in d4["cmp"]), "11.2: no hi pot haver cap parella igual")
        comprova(all(a == c and b != d for a, b, c, d in d4["cmp"][:4]), "11.2: les quatre primeres, amb el mateix numerador")
        comprova(all(d <= 12 and (not r or b <= a) for a, b, d, r in d4["ops"]), "12.2: denominadors fins al 12, i cap resta negativa")
        print(f"  {len(d4['casos'])} fraccions, {len(d4['eq'])} parelles d'equivalents, {len(d4['cmp'])} per comparar i {len(d4['ops'])} operacions")

        def frac_de(pg, sel):
            """Les fraccions dels rètols d'un dibuix: [(3, 4), (6, 8)]."""
            textos = pg.eval_on_selector_all(sel + " text", "els => els.map(e => e.textContent)")
            return [tuple(map(int, t.split("/"))) for t in textos if "/" in t]

        def tria_nom(pg, pref, nom):
            pg.click(f'#{pref}-opcions .opcio-frac:has(.frac[aria-label="{nom}"])')

        def tasca_frac(pg, mod, pref, bona, dolenta, nom_tasca):
            """Una tasca tancada de triar una fracció. `bona(pg)` i `dolenta(pg)` diuen quin nom tocar."""
            modul(pg, mod, 2)
            for pas in range(5):
                if pas == 2:
                    tria_nom(pg, pref, dolenta(pg))
                    av = text(pg, f"#{pref}-avis")
                    comprova(av.startswith("Incorrecte.") and "Pista" in av, f"{nom_tasca}: la pista del primer error: «{av}»")
                tria_nom(pg, pref, bona(pg))
                comprova(text(pg, f"#{pref}-avis").startswith("Correcte."), f"{nom_tasca}: pas {pas + 1}")
                pg.click(f"#{pref}-seguent")
            nums, codi = final_de(pg, pref)
            comprova(nums == {"Passos": "5", "Correctes al primer intent": "4", "Correctes amb una pista": "1",
                              "Amb la resposta ensenyada": "0"}, f"{nom_tasca}: el resum no quadra: {nums}")
            return codi

        nom_fr = lambda pg, n, d: pg.evaluate(f"CE.q.nomFraccio({n}, {d})")
        noms_opcions = lambda pg, pref: pg.eval_on_selector_all(f"#{pref}-opcions .frac", "els => els.map(e => e.getAttribute('aria-label'))")

        titol("9.1 · FES LA FRACCIÓ")
        obre(pg); modul(pg, "fraccio", 1)
        lec = text(pg, "#fa-lectura")
        comprova("Es llegeix: quatre novens." in lec and "pròpia" in lec, f"9.1: el 4/9: «{lec}»")
        mou(pg, "#fa-n", 9)
        comprova("És una unitat" in text(pg, "#fa-lectura"), "9.1: 9/9 és una unitat")
        mou(pg, "#fa-n", 12)
        comprova("impròpia" in text(pg, "#fa-lectura") and pg.locator("#fa-svg .q-vora").count() == 2, "9.1: 12/9, impròpia, amb dos rectangles")
        mou(pg, "#fa-n", 1); mou(pg, "#fa-d", 2)
        comprova("Es llegeix: un mig." in text(pg, "#fa-lectura"), "9.1: 1/2 es llegeix «un mig»")
        print("  4/9 quatre novens i pròpia; 9/9 unitat; 12/9 impròpia amb dos rectangles; 1/2 un mig")

        titol("9.2 · QUINA FRACCIÓ ÉS?")
        def n_d_92(pg):
            aria = pg.get_attribute("#fb-svg", "aria-label")
            d, n = map(int, re.findall(r"\d+", aria))
            return n, d
        bona92 = lambda pg: nom_fr(pg, *n_d_92(pg))
        dolenta92 = lambda pg: next(x for x in noms_opcions(pg, "fb") if x != bona92(pg))
        codis["9.2"] = (tasca_frac(pg, "fraccio", "fb", bona92, dolenta92, "9.2"), "Quina fracció és?", (5, 4, 1, 0))
        print(f"  cinc passos, un error amb pista; codi {codis['9.2'][0]}")

        titol("10.1 · PARTEIX ELS TROSSOS")
        modul(pg, "equivalents", 1)
        lec = text(pg, "#ea-lectura")
        comprova("són equivalents" in lec and "2 · 4 = 8 i 3 · 4 = 12" in lec, f"10.1: 2/3 = 8/12: «{lec}»")
        mou(pg, "#ea-d", 5)
        comprova(int(text(pg, "#ea-k .comptador-valor")) <= 2, "10.1: amb 5 trossos, cap denominador de més de 12")
        print("  2/3 = 8/12 amb l'amplificació; amb 5 trossos, el comptador no passa de 12")

        titol("10.2 · SÓN EQUIVALENTS?")
        def bo102(p_):
            (a, b), (c, d) = frac_de(pg, "#eb-svg")
            return a * d == b * c
        codis["10.2"] = (tasca_sino(pg, "equivalents", 2, "eb", bo102, "10.2"), "Són equivalents?", (5, 4, 1, 0))
        print(f"  cinc passos, un error amb pista; codi {codis['10.2'][0]}")

        titol("11.1 · COMPARA DUES FRACCIONS")
        modul(pg, "compara", 1)
        lec = text(pg, "#ca-lectura")
        comprova("és més gran que" in lec and "Tenen el mateix numerador" in lec, f"11.1: 1/3 i 1/5: «{lec}»")
        print("  1/3 més gran que 1/5, amb la regla trencada")

        titol("11.2 · QUINA ÉS MÉS GRAN?")
        def gran112(pg):
            (a, b), (c, d) = frac_de(pg, "#cb-svg")
            return nom_fr(pg, a, b) if a * d > c * b else nom_fr(pg, c, d)
        petita112 = lambda pg: next(x for x in noms_opcions(pg, "cb") if x != gran112(pg))
        codis["11.2"] = (tasca_frac(pg, "compara", "cb", gran112, petita112, "11.2"), "Quina és més gran?", (5, 4, 1, 0))
        print(f"  cinc passos, un error amb pista; codi {codis['11.2'][0]}")

        titol("12.1 · SUMA I RESTA")
        modul(pg, "sumes", 1)
        comprova("Se sumen els trossos pintats: 3 + 2 = 5." in text(pg, "#sa-lectura"), "12.1: 3/8 + 2/8")
        pg.click("#sa-op .pastilla >> nth=1")
        comprova("Es treuen 2 trossos dels 3: 3 − 2 = 1." in text(pg, "#sa-lectura"), "12.1: la resta")
        print("  3/8 + 2/8 = 5/8; 3/8 − 2/8 = 1/8")

        titol("12.2 · QUANT ÉS?")
        def op122(pg):
            t = text(pg, "#sb-pregunta")
            a, d, b, _ = map(int, re.findall(r"\d+", t))
            return a, b, d, "−" in t
        bona122 = lambda pg: (lambda a, b, d, r: nom_fr(pg, a - b if r else a + b, d))(*op122(pg))
        dolenta122 = lambda pg: next(x for x in noms_opcions(pg, "sb") if x != bona122(pg))
        codis["12.2"] = (tasca_frac(pg, "sumes", "sb", bona122, dolenta122, "12.2"), "Quant és?", (5, 4, 1, 0))
        print(f"  cinc passos, un error amb pista; codi {codis['12.2'][0]}")

        titol("13.1 · COMPTA L'ÀREA")
        modul(pg, "area", 1)
        lec = text(pg, "#aa-lectura")
        comprova("Hi ha 14 quadrets sencers." in lec and "Àrea: 15 quadrets" in lec, f"13.1: la casa: «{lec}»")
        pg.click("#aa-figures .pastilla >> nth=2")
        lec = text(pg, "#aa-lectura")
        comprova("Hi ha 4 quadrets sencers." in lec and "8 mitjos fan 4 quadrets" in lec and "Àrea: 8 quadrets" in lec, f"13.1: el rombe: «{lec}»")
        print("  la casa: 14 sencers i 2 mitjos, 15 quadrets; el rombe: 4 i 8 mitjos, 8 quadrets")

        titol("13.2 · QUINA ÀREA TÉ?")
        def area_de(pg):
            s_ = pg.locator("#ab-svg rect.q").count(); m_ = pg.locator("#ab-svg polygon.q").count()
            a = s_ + m_ / 2
            return f"{int(a) if a == int(a) else a} quadrets"
        modul(pg, "area", 2)
        for pas in range(5):
            bona = area_de(pg)
            if pas == 2:
                pg.click(f'#ab-opcions .opcio-area:not(:text-is("{bona}")) >> nth=0')
                av = text(pg, "#ab-avis")
                comprova(av.startswith("Incorrecte.") and "Pista" in av, f"13.2: la pista del primer error: «{av}»")
            pg.click(f'#ab-opcions .opcio-area:text-is("{bona}")')
            comprova(text(pg, "#ab-avis").startswith("Correcte."), f"13.2: pas {pas + 1}")
            pg.click("#ab-seguent")
        nums, codi = final_de(pg, "ab")
        comprova(nums == {"Passos": "5", "Correctes al primer intent": "4", "Correctes amb una pista": "1",
                          "Amb la resposta ensenyada": "0"}, f"13.2: el resum no quadra: {nums}")
        codis["13.2"] = (codi, "Quina àrea té?", (5, 4, 1, 0))
        print(f"  cinc passos, un error amb pista; codi {codi}")


        # ------------------------------------------------------------------
        titol("UNITAT 4 · LES QUATRE TASQUES TANCADES")
        # Aquestes proves no hi eren: la tasca 15 escrivia dins de la taula de la tasca 0
        # (tt- i tf- repetits) i ningú no ho va veure (29/9/2026). Es contesten tocant les
        # opcions per ordre fins que surt «Correcte.»: el resum ha de sumar 5 i el codi,
        # llegir-se a verifica.html amb els mateixos recomptes.
        def tasca_tocant(pg, mod, pref, nom):
            modul(pg, mod, 2)
            for pas in range(5):
                for intent in range(3):
                    lliures = pg.locator(f"#{pref}-opcions button:not([disabled])")
                    if not lliures.count() or pg.is_enabled(f"#{pref}-seguent"):
                        break
                    lliures.nth(0).click()
                    av = text(pg, f"#{pref}-avis")
                    if intent == 0 and av.startswith("Incorrecte."):
                        comprova("Pista" in av, f"{nom}: el primer error no porta pista: «{av}»")
                comprova(pg.is_enabled(f"#{pref}-seguent"), f"{nom}: el pas {pas + 1} no s'acaba")
                pg.click(f"#{pref}-seguent")
            nums, codi = final_de(pg, pref)
            n = [int(nums.get(k, -9)) for k in ("Passos", "Correctes al primer intent",
                                                  "Correctes amb una pista", "Amb la resposta ensenyada")]
            comprova(n[0] == 5 and sum(n[1:]) == 5, f"{nom}: el resum no quadra: {nums}")
            comprova(bool(codi), f"{nom}: no surt el codi")
            return codi, tuple(n)

        obre(pg)
        for mod, pref, id_, nom in [("fraccnombre", "fq", "14.2", "Quant és?"), ("multfrac", "mg", "15.2", "Quin tros és?"),
                                    ("percentatges", "pq", "16.2", "Quin percentatge és?"),
                                    ("dobletriple", "dq", "17.2", "Quantes vegades hi cap?")]:
            codi, n = tasca_tocant(pg, mod, pref, id_)
            codis[id_] = (codi, nom, n)
            print(f"  {id_}: {n[0]} passos ({n[1]} al primer intent, {n[2]} amb pista, {n[3]} ensenyats); codi {codi}")
        modul(pg, "multfrac", 1)
        comprova(pg.locator("#mf-svg rect").count() > 0 and "1/2 · 1/4 = 1/8" in text(pg, "#mf-lectura"),
                 "15.1: el tros de tros no es dibuixa")
        print("  15.1: el tros de tros es dibuixa al seu lloc (1/2 · 1/4 = 1/8)")

        # ------------------------------------------------------------------
        titol("DADES DE LA UNITAT 5 (DECIMALS I ARREL)")
        def dec(c, x=None):
            """Com CE.q.dec: 243 → «2,43»; amb x = 1 o 2, amb aquelles xifres decimals."""
            u, r = divmod(c, 100)
            if x == 2:
                return f"{u},{r:02d}"
            if x == 1:
                return f"{u},{round(r / 10)}"
            if r == 0:
                return str(u)
            return f"{u},{r // 10}" if r % 10 == 0 else f"{u},{r:02d}"
        def centesimes(t):
            """«2,43» → 243; «3» → 300."""
            u, _, r = t.strip().partition(",")
            return int(u) * 100 + (int(r.ljust(2, "0")) if r else 0)

        d5 = pg.evaluate("""() => {
            const D = CE.dades;
            return { zero: D.decimals.ZERO_MIG, altres: D.decimals.ALTRES, trenc: D.decimals.TRENCADES,
                     control: D.decimals.CONTROL,
                     op18: D.decimals.ZERO_MIG.concat(D.decimals.ALTRES).map(c => D.decimals.opcionsDe(c)),
                     amunt: D.arrodonir.AMUNT, avall: D.arrodonir.AVALL,
                     op19: D.arrodonir.AMUNT.concat(D.arrodonir.AVALL).map(c => D.arrodonir.opcionsDe(c)),
                     ops: D.sumadec.OPS, casos20: D.sumadec.CASOS2, op20: D.sumadec.CASOS2.map(c => D.sumadec.opcionsDe(c)),
                     fr: D.fracdec.FRACCIONS, casos21: D.fracdec.CASOS2, op21: D.fracdec.CASOS2.map(f => D.fracdec.opcionsDe(f)),
                     ns24: D.quadrat.NS24, op24: D.quadrat.NS24.map(n => D.quadrat.opcionsDe24(n)),
                     noms: [243, 304, 340, 75, 1, 10, 100, 121, 222, 931, 0, 999, 5].map(c => [c, D.decimals.nomDecimal(c)]) };
        }""")
        comprova(all(0 < c <= 999 for c in d5["zero"] + d5["altres"]), "18.2: decimals fora de 0,01 a 9,99")
        comprova(all(c // 10 % 10 == 0 and c % 10 for c in d5["zero"]), "18.2: ZERO_MIG ha de tenir un zero a les dècimes")
        comprova(all(len({o[1] for o in ops}) == 3 for ops in d5["op18"]), "18.2: dues opcions iguals")
        ndec = lambda c: len(dec(c).partition(",")[2])
        comprova(all(g > p_ and ndec(g) < ndec(p_) for g, p_ in d5["trenc"]), "18.3: a les trencades, el gran ha de tenir menys xifres")
        comprova(all(g > p_ and ndec(g) > ndec(p_) for g, p_ in d5["control"]), "18.3: a les altres, el gran ha de tenir més xifres")
        esperats = {243: "dues unitats i quaranta-tres centèsimes", 304: "tres unitats i quatre centèsimes",
                    340: "tres unitats i quatre dècimes", 75: "setanta-cinc centèsimes", 1: "una centèsima",
                    10: "una dècima", 100: "una unitat", 121: "una unitat i vint-i-una centèsimes",
                    222: "dues unitats i vint-i-dues centèsimes", 931: "nou unitats i trenta-una centèsimes",
                    0: "zero", 999: "nou unitats i noranta-nou centèsimes", 5: "cinc centèsimes"}
        for c, nom_ in d5["noms"]:
            comprova(nom_ == esperats[c], f"nom del decimal {dec(c)}: «{nom_}» i hauria de ser «{esperats[c]}»")
        comprova(all(c % 10 >= 5 for c in d5["amunt"]) and all(0 < c % 10 < 5 for c in d5["avall"]),
                 "19.2: els casos d'amunt i d'avall no quadren")
        comprova(all(len({o[1] for o in ops}) == 3 for ops in d5["op19"]), "19.2: dues opcions iguals")
        comprova(all(c < 900 for c in d5["amunt"] + d5["avall"]), "19.2: arrodonit passaria de 9,99")
        for a, b, r in d5["ops"] + d5["casos20"]:
            xa, xb = [(c // 100, c // 10 % 10, c % 10) for c in (a, b)]
            if r:
                comprova(all(p_ >= q for p_, q in zip(xa, xb)), f"20: {dec(a)} − {dec(b)} demana portar-ne")
            else:
                comprova(all(p_ + q <= 9 for p_, q in zip(xa, xb)), f"20: {dec(a)} + {dec(b)} demana portar-ne")
        for (a, b, r), ops in zip(d5["casos20"], d5["op20"]):
            comprova(len({o[1] for o in ops}) == 3 and ops[0][1] == dec(a - b if r else a + b),
                     f"20.2: {dec(a)} i {dec(b)}: les opcions no quadren ({ops})")
        comprova(all(d in (2, 4, 5, 10) and 0 < n < d for n, d in d5["fr"] + d5["casos21"]),
                 "21: les fraccions han de fer quadrets sencers de 100, amb els denominadors 2, 4, 5 i 10")
        comprova(all(len({o[1] for o in ops}) == 3 for ops in d5["op21"]), "21.2: dues opcions iguals")
        comprova(all(1 < n <= 100 and int(n ** 0.5) ** 2 != n for n in d5["ns24"]), "2.4: nombres que són quadrats o passen de 100")
        comprova(all(len({(o[1], o[2]) for o in ops}) == 3 for ops in d5["op24"]), "2.4: dues opcions iguals")
        print(f"  {len(d5['zero']) + len(d5['altres'])} decimals per llegir, {len(d5['trenc']) + len(d5['control'])} parelles per comparar, "
              f"{len(d5['amunt']) + len(d5['avall'])} per arrodonir, {len(d5['casos20'])} operacions sense portar-ne, "
              f"{len(d5['casos21'])} fraccions i {len(d5['ns24'])} arrels; {len(esperats)} noms de decimals")

        titol("18.1 · FES EL DECIMAL")
        obre(pg); modul(pg, "decimals", 1)
        lec = text(pg, "#xa-lectura")
        comprova("2,43" in lec and "Es llegeix: dues unitats i quaranta-tres centèsimes." in lec, f"18.1: el 2,43: «{lec}»")
        comprova(pg.is_visible("#xa-marca"), "18.1: s'obre sense la marca «Exemple»")
        mou(pg, "#xa-d", 0)
        lec = text(pg, "#xa-lectura")
        comprova("2,03" in lec and "dues unitats i tres centèsimes" in lec, f"18.1: el 2,03: «{lec}»")
        comprova(not pg.is_visible("#xa-marca"), "18.1: la marca «Exemple» amb un altre cas")
        print("  2,43 dues unitats i quaranta-tres centèsimes; 2,03, amb el zero que manté el lloc")

        def tasca_dec(pg, mod, sub, pref, bona, nom, sel="button"):
            """Una tasca tancada de triar. `bona(pg)` diu el text de l'opció bona."""
            modul(pg, mod, sub)
            for pas in range(5):
                b = bona(pg)
                if pas == 2:
                    pg.click(f'#{pref}-opcions {sel}:not(:text-is("{b}")) >> nth=0')
                    av = text(pg, f"#{pref}-avis")
                    comprova(av.startswith("Incorrecte.") and "Pista" in av, f"{nom}: la pista del primer error: «{av}»")
                pg.click(f'#{pref}-opcions {sel}:text-is("{b}")')
                comprova(text(pg, f"#{pref}-avis").startswith("Correcte."), f"{nom}: pas {pas + 1}: la bona era {b}")
                pg.click(f"#{pref}-seguent")
            nums, codi = final_de(pg, pref)
            comprova(nums == {"Passos": "5", "Correctes al primer intent": "4", "Correctes amb una pista": "1",
                              "Amb la resposta ensenyada": "0"}, f"{nom}: el resum no quadra: {nums}")
            return codi

        titol("18.2 · QUIN DECIMAL ÉS?")
        def bona182(pg):
            q, col, qs = [int(x) for x in re.findall(r": (\d+)", pg.get_attribute("#xb-blocs", "aria-label"))]
            return dec(q * 100 + col * 10 + qs)
        codis["18.2"] = (tasca_dec(pg, "decimals", 2, "xb", bona182, "18.2"), "Quin decimal és?", (5, 4, 1, 0))
        print(f"  cinc passos, un error amb pista; codi {codis['18.2'][0]}")

        titol("18.3 · QUIN ÉS MÉS GRAN?")
        def bona183(pg):
            ts = pg.eval_on_selector_all("#xc-opcions button", "bs => bs.map(b => b.textContent)")
            return max(ts, key=centesimes)
        modul(pg, "decimals", 3)
        comprova(pg.is_hidden("#xc-dibuix"), "18.3: els blocs es veuen abans de contestar")
        codis["18.3"] = (tasca_dec(pg, "decimals", 3, "xc", bona183, "18.3"), "Quin és més gran?", (5, 4, 1, 0))
        print(f"  cinc passos, un error amb pista; els blocs, només després de contestar; codi {codis['18.3'][0]}")

        titol("19.1 · EL DECIMAL A LA RECTA")
        modul(pg, "arrodonir", 1)
        lec = text(pg, "#ra-lectura")
        comprova("més a prop de 3,5" in lec and "Arrodonit a les dècimes: 3,5." in lec and "Truncat a les dècimes: 3,4." in lec,
                 f"19.1: el 3,47: «{lec}»")
        mou(pg, "#ra-c", 5)
        comprova("a la ratlla del mig" in text(pg, "#ra-lectura"), "19.1: el 3,45 és a la ratlla del mig")
        mou(pg, "#ra-c", 2)
        comprova("més a prop de 3,4" in text(pg, "#ra-lectura"), "19.1: el 3,42 va avall")
        mou(pg, "#ra-u", 0); mou(pg, "#ra-d", 9); mou(pg, "#ra-c", 6)
        comprova("Arrodonit a les dècimes: 1,0." in text(pg, "#ra-lectura"), f"19.1: el 0,96 arrodonit és 1,0: «{text(pg, '#ra-lectura')}»")
        comprova(pg.locator("#ra-svg circle.q-punt").count() == 1, "19.1: a la recta hi falta el punt")
        print("  3,47 → 3,5 i 3,4; 3,45 a la ratlla del mig; 3,42 avall; 0,96 → 1,0")

        titol("19.2 · ARRODONEIX")
        def bona192(pg):
            c = centesimes(re.search(r"(\d+,\d+)", text(pg, "#rb-pregunta")).group(1))
            return dec(c - c % 10 + (10 if c % 10 >= 5 else 0), 1)
        codis["19.2"] = (tasca_dec(pg, "arrodonir", 2, "rb", bona192, "19.2"), "Arrodoneix", (5, 4, 1, 0))
        print(f"  cinc passos, un error amb pista; codi {codis['19.2'][0]}")

        titol("20.1 · SUMA I RESTA")
        modul(pg, "sumadec", 1)
        lec = text(pg, "#sc-lectura")
        comprova("2,5 + 1,35 = 3,85" in lec and "2,5 és el mateix que 2,50" in lec, f"20.1: 2,5 + 1,35: «{lec}»")
        comprova(pg.locator("#sc-blocs rect.nou").count() > 0, "20.1: el segon sumand no es distingeix")
        pg.click("#sc-ops .pastilla >> nth=3")
        lec = text(pg, "#sc-lectura")
        comprova("5,85 − 2,3 = 3,55" in lec and pg.locator("#sc-blocs line.q-ratlla").count() > 0, f"20.1: la resta: «{lec}»")
        print("  2,5 + 1,35 = 3,85, amb 2,50; 5,85 − 2,3 = 3,55, amb el que es treu ratllat")

        titol("20.2 · QUANT ÉS?")
        def bona202(pg):
            t = text(pg, "#sd-pregunta")
            a, b = [centesimes(x) for x in re.findall(r"\d+(?:,\d+)?", t)]
            return dec(a - b if "−" in t else a + b)
        codis["20.2"] = (tasca_dec(pg, "sumadec", 2, "sd", bona202, "20.2"), "Quant és?", (5, 4, 1, 0))
        print(f"  cinc passos, un error amb pista; codi {codis['20.2'][0]}")

        titol("21.1 · PINTA LA FRACCIÓ")
        modul(pg, "fracdec", 1)
        comprova(pg.locator("#fc-svg rect.q:not(.falta)").count() == 25 and "= 0,25" in text(pg, "#fc-lectura")
                 and "2 columnes i 5 quadrets" in text(pg, "#fc-lectura"), f"21.1: 1/4: «{text(pg, '#fc-lectura')}»")
        pg.click("#fc-pastilles .pastilla >> nth=2")
        comprova(pg.locator("#fc-svg rect.q:not(.falta)").count() == 75 and "= 0,75" in text(pg, "#fc-lectura"), "21.1: 3/4")
        print("  1/4: 25 quadrets, 2 columnes i 5 quadrets, 0,25; 3/4: 75 quadrets, 0,75")

        titol("21.2 · DE FRACCIÓ A DECIMAL")
        def bona212(pg):
            n, d = map(int, re.findall(r"\d+", text(pg, "#fd-pregunta")))
            return dec(100 // d * n)
        modul(pg, "fracdec", 2)
        comprova(pg.get_attribute("#fd-svg", "hidden") is not None, "21.2: el quadrat pintat es veu abans de contestar")
        codis["21.2"] = (tasca_dec(pg, "fracdec", 2, "fd", bona212, "21.2"), "De fracció a decimal", (5, 4, 1, 0))
        print(f"  cinc passos, un error amb pista; codi {codis['21.2'][0]}")

        titol("2.4 · ENTRE QUINS DOS NOMBRES?")
        def bona24(pg):
            n = int(re.search(r"√(\d+)", text(pg, "#q4-pregunta")).group(1))
            k = int(n ** 0.5)
            return f"{k} i {k + 1}"
        codis["2.4"] = (tasca_dec(pg, "quadrat", 4, "q4", bona24, "2.4"), "Entre quins dos nombres?", (5, 4, 1, 0))
        print(f"  cinc passos, un error amb pista; codi {codis['2.4'][0]}")

        # ------------------------------------------------------------------
        titol("CODIS A verifica.html")
        for id_, (codi, nom, (pas, be, pista, most)) in codis.items():
            res = llegeix_codi(pg, codi or "")
            comprova("Vàlid" in res and "No vàlid" not in res, f"{id_}: el codi {codi} no és vàlid")
            comprova(f"{id_} · {nom}" in res, f"{id_}: verifica.html no diu el nom de la tasca")
            comprova(f"Passos: {pas}" in res and f"Correctes al primer intent: {be}" in res
                     and f"Correctes amb una pista: {pista}" in res and f"Amb la resposta ensenyada: {most}" in res,
                     f"{id_}: verifica.html no llegeix els recomptes: {res!r}")
        res = llegeix_codi(pg, "AAA-AAA-AAA")
        comprova("No vàlid" in res, "verifica.html accepta un codi inventat")
        print(f"  {len(codis)} codis llegits, amb el nom i els recomptes; un codi inventat no passa")

        # ------------------------------------------------------------------
        titol("REPRESA, ENLLAÇOS I MEMÒRIA")
        pg.evaluate("localStorage.clear()")
        obre(pg)
        modul(pg, "rect", 2)
        a, b = map(int, re.findall(r"\d+", text(pg, "#r2-pregunta")))
        toca_cella(pg, "#r2-svg", a, b)
        pg.click("#r2-seguent")
        obre(pg)
        modul(pg, "rect", 2)
        comprova(pg.is_visible("#r2-represa") and "pas 2 de 5" in text(pg, "#r2-represa"),
                 "1.2: no es proposa continuar la tasca a mitges")
        pg.click("#r2-represa .btn >> nth=0")
        comprova("Pas 2 de 5" in text(pg, "#r2-recorregut"), "1.2: continuar no porta al pas 2")
        claus = pg.evaluate("Object.keys(localStorage)")
        comprova(claus and all(k.startswith("pi1-") for k in claus), f"claus del navegador sense «pi1-»: {claus}")

        obre(pg, CAIXA + "?task=1.3")
        visibles = pg.evaluate("[...document.querySelectorAll('.segment')].filter(b => !b.hidden).map(b => b.dataset.mod)")
        comprova(visibles == ["taules", "rect"], f"?task=1.3: pestanyes {visibles}")
        comprova(text(pg, "#mod-rect .sub-rotul").startswith("1.3"), "?task=1.3 no obre la 1.3")
        comprova(pg.is_hidden(".tornar"), "?task=1.3: l'enllaç a l'inici es veu")
        pg.click('.segment[data-mod="taules"]')
        comprova(text(pg, "#mod-taules .sub-rotul").startswith("0.1"), "?task=1.3: les Taules no s'obren per la 0.1")
        comprova(not pg.is_visible("#mod-taules .sub-avant"), "?task=1.3: a les Taules es veuen les fletxes")
        pg.click('.segment[data-mod="rect"]')
        comprova(not pg.is_visible("#mod-rect .sub-avant") and not pg.is_visible("#mod-rect .sub-enrere"),
                 "?task=1.3: es veuen les fletxes per passar a un altre exercici")
        obre(pg, CAIXA + "?task=3")
        comprova(text(pg, "#mod-cdu .sub-rotul").startswith("3.1"), "?task=3 no obre la 3.1")
        comprova(pg.is_visible("#mod-cdu .sub-avant"), "?task=3: amb l'enllaç a tota l'eina, les fletxes hi han de ser")
        obre(pg, CAIXA + "?task=0.2")
        comprova(text(pg, "#mod-taules .sub-rotul").startswith("0.2"), "?task=0.2 no obre la 0.2")
        obre(pg, CAIXA + "?task=18.3")
        comprova(text(pg, "#mod-decimals .sub-rotul").startswith("18.3") and not pg.is_visible("#mod-decimals .sub-avant"),
                 "?task=18.3 no obre la 18.3, o s'hi veuen les fletxes")
        print("  represa al pas 2; claus pi1-; ?task=1.3 sense fletxes, ?task=3 amb fletxes, ?task=0.2")

        # ------------------------------------------------------------------
        titol("CONSOLA")
        comprova(not consola, f"errors a la consola: {consola}")
        print(f"  errors: {len(consola)}")
        nav.close()

    print()
    if errors:
        print(f"{len(errors)} proves han fallat.")
        sys.exit(1)
    print("Tot correcte.")


if __name__ == "__main__":
    main()

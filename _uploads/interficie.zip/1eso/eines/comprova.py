#!/usr/bin/env python3
"""Comprovacions del material de 1eso/. Es passa abans de publicar res.

    python3 1eso/eines/comprova.py      (des de l'arrel del repositori)

No necessita res més que Python 3.8 o posterior. Verifica les regles que és
fàcil trencar sense adonar-se'n:

  · el paper és en blanc i negre, l'HTML tanca bé i les pàgines van seguides;
  · a les pàgines de l'alumnat es multiplica amb «·», cap nombre passa de 999,
    les frases segueixen les regles de Lectura Fàcil que es poden comprovar
    soles, i cap igualtat escrita no està malament, calculada
    sencera amb l'ordre de les operacions (el que és ratllat no es comprova);
  · el text manuscrit només porta caràcters que la lletra Caveat sap dibuixar;
  · la caixa d'eines: cada pestanya té la seva secció i el seu mòdul, les
    tasques es numeren sense repetir-se i amb el 0 el primer, cada frase que es
    demana existeix a dades/textos.js i té la seva explicació, les frases passen
    les regles de Lectura Fàcil que es poden comprovar soles, i a la pantalla
    també es multiplica amb «·», cap nombre passa de 999 i res no diu «adaptat»;
    la memòria del navegador comença per «pi1-» i la sal del codi no és la de
    l'altra caixa;
  · cada PDF és el que sortiria ara de la seva font (empremtes.json);
  · els fulls d'estil tanquen les claus i no fan servir variables inexistents,
    i els colors de la pantalla tenen el contrast que demana la WCAG 2.2 AA;
  · cap enllaç queda penjat, cap fitxer depèn d'internet, cap text no anomena
    el curs, el tipus d'aula, un diagnòstic ni cap alumne concret, i les dades
    de dades/unitats.js quadren amb el que hi ha al disc.

Falla: el que s'ha d'arreglar abans de publicar. Avisa: el que cal mirar.
"""
import glob, json, os, re, struct, sys
from fractions import Fraction
from html.parser import HTMLParser

ARREL = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))   # 1eso/
REPO = os.path.dirname(ARREL)                                          # l'arrel del repositori
sys.path.insert(0, os.path.join(ARREL, 'eines'))
import paper  # noqa: E402  (només biblioteca estàndard)

falles, avisos = [], []


def comprova(condicio, missatge):
    if not condicio:
        falles.append(missatge)
    return condicio


def avisa(condicio, missatge):
    if not condicio:
        avisos.append(missatge)
    return condicio


def ruta(*p):
    return os.path.join(ARREL, *p)


def rel(f):
    return os.path.relpath(f, ARREL)


def llegeix(f):
    with open(f, encoding='utf-8') as h:
        return h.read()


FITXES = sorted(glob.glob(ruta('fitxes', '*.html')))
TARGETES = sorted(glob.glob(ruta('targetes', '*.html')))
PAPER = FITXES + TARGETES

# --------------------------------------------------------------------------
# Eines
# --------------------------------------------------------------------------

BUIDES = {'area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'source',
          'track', 'wbr', 'path', 'circle', 'rect', 'line', 'use', 'stop', 'polygon',
          'polyline', 'ellipse'}


class Estructura(HTMLParser):
    """Comprova que cada etiqueta que s'obre es tanqui, i en l'ordre bo."""
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.pila, self.err = [], []

    def handle_starttag(self, t, a):
        if t not in BUIDES:
            self.pila.append(t)

    def handle_startendtag(self, t, a):
        pass

    def handle_endtag(self, t):
        if t in BUIDES:
            return
        if self.pila and self.pila[-1] == t:
            self.pila.pop()
        else:
            self.err.append(t)


# El text que es veu, partit en trossos: un per element de bloc. Cada tros
# recorda les classes de tots els elements que el contenen.
BLOC = {'p', 'div', 'li', 'td', 'th', 'tr', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'br', 'table',
        'section', 'label', 'ul', 'ol', 'dt', 'dd', 'caption', 'figcaption', 'svg', 'text'}
AMAGAT = {'script', 'style', 'title', 'head'}
BUIDES_HTML = {'area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta',
               'source', 'track', 'wbr'}
PER_A_L_ADULT = {'sol', 'previ', 'pag'}   # solucionari, rètol del graó físic i peu


class Visible(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.pila, self.trossos, self.actual = [], [], []

    def _classes(self):
        return frozenset(c for _, cs in self.pila for c in cs)

    def _tanca(self):
        if self.actual:
            self.trossos.append(self.actual)
            self.actual = []

    def handle_starttag(self, t, a):
        if t in BLOC:
            self._tanca()
        if t not in BUIDES_HTML:
            self.pila.append((t, frozenset((dict(a).get('class') or '').split())))

    def handle_startendtag(self, t, a):
        if t in BLOC:
            self._tanca()

    def handle_endtag(self, t):
        if t in BLOC:
            self._tanca()
        for i in range(len(self.pila) - 1, -1, -1):
            if self.pila[i][0] == t:
                del self.pila[i:]
                break

    def handle_data(self, d):
        if not any(t in AMAGAT for t, _ in self.pila):
            self.actual.append((d, self._classes()))

    def close(self):
        super().close()
        self._tanca()


# Una fracció del paper, escrita com a fracció, amb el numerador damunt del denominador:
# <span class="fr" ...><span ...>3</span><span ...>4</span></span>. Per llegir-la i per
# calcular-la es torna «3/4»; si no, seria «34», i «1/2 = 2/4» es llegiria «12 = 24».
FRACCIO_PAPER = re.compile(r'<span class="fr"[^>]*>\s*<span[^>]*>(\d+)</span>\s*<span[^>]*>(\d+)</span>\s*</span>')
def amb_fraccions(s):
    return FRACCIO_PAPER.sub(r'\1/\2', s)


def trossos(fitxer):
    """[[(text, classes), ...], ...]: el text visible, un tros per bloc."""
    v = Visible()
    v.feed(amb_fraccions(llegeix(fitxer)))
    v.close()
    return v.trossos


def frases_alumnat(fitxer, sense=frozenset()):
    """El text que llegeix l'alumnat, un element per bloc, sense el de l'adult."""
    fora = PER_A_L_ADULT | set(sense)
    out = []
    for tros in trossos(fitxer):
        text = ' '.join(''.join(t for t, c in tros if not (c & fora)).split())
        if text:
            out.append(text)
    return out


def tot_el_text(fitxer):
    """Tot el text visible, també el de l'adult, en una sola cadena."""
    return ' '.join(' '.join(''.join(t for t, _ in tros).split()) for tros in trossos(fitxer))


class TextCalcul(HTMLParser):
    """El text tal com es llegeix un càlcul. Les cel·les d'una mateixa fila de taula
    van seguides: a la targeta, «7 · 8 = 56» són cinc cel·les. Però cada paràgraf,
    cada fila i cada rètol d'un dibuix és un tros a part (¶): un buit per escriure
    no pot enganxar un «=» al número del paràgraf de sota.
    El que és ratllat (.ratllat) no hi és: és una igualtat falsa a posta, com
    l'error típic que descriu un solucionari («3² = 6»). Tampoc el que va dins de
    .revisa: les igualtats que l'alumnat ha de revisar, i que poden ser falses a
    posta («Marca les multiplicacions mal fetes»). El solucionari hi diu les bones,
    i aquelles sí que es comproven."""
    SUAUS = {'td', 'th'}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts, self.pila = [], []

    def _vora(self, t):
        self.parts.append(' ' if t in self.SUAUS else (' ¶ ' if t in BLOC else ''))

    def handle_starttag(self, t, a):
        self._vora(t)
        if t not in BUIDES_HTML:
            classes = (dict(a).get('class') or '').split()
            self.pila.append((t, t in AMAGAT or 'ratllat' in classes or 'revisa' in classes))

    def handle_startendtag(self, t, a):
        self._vora(t)

    def handle_endtag(self, t):
        self._vora(t)
        for i in range(len(self.pila) - 1, -1, -1):
            if self.pila[i][0] == t:
                del self.pila[i:]
                break

    def handle_data(self, d):
        if not any(fora for _, fora in self.pila):
            self.parts.append(d)


def text_de_calcul(fitxer):
    e = TextCalcul()
    e.feed(amb_fraccions(llegeix(fitxer)))
    e.close()
    return ' '.join(''.join(e.parts).split())


def rgb(h):
    h = h.lstrip('#')
    h = ''.join(c * 2 for c in h) if len(h) == 3 else h
    return int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)


NOMS_DE_COLOR = (r'red|green|blue|yellow|orange|purple|pink|brown|cyan|magenta|lime|navy|'
                 r'teal|olive|maroon|violet|indigo|gold|coral|salmon|crimson|tomato|orchid|'
                 r'turquoise|aqua|fuchsia')


def cromatics(text):
    """Colors que no són grisos, en qualsevol de les maneres d'escriure'ls."""
    text = re.sub(r'/\*.*?\*/|<!--.*?-->', '', text, flags=re.S)
    trobats = {h for h in re.findall(r'(?<![&\w])#[0-9A-Fa-f]{3}(?:[0-9A-Fa-f]{3})?\b', text)
               if len(set(rgb(h))) > 1}
    trobats |= {m.group(0) for m in re.finditer(r'rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)', text)
                if len({m.group(1), m.group(2), m.group(3)}) > 1}
    trobats |= {m.group(0) for m in re.finditer(r'hsla?\(\s*[\d.]+\w*\s*,\s*([\d.]+)%', text)
                if float(m.group(1)) > 0}
    trobats |= {m.group(0) for m in re.finditer(
        r'(?:color|fill|stroke|background(?:-color)?)\s*[:=]\s*["\']?(?:' + NOMS_DE_COLOR + r')\b',
        text, re.I)}
    return sorted(trobats)


def caracters_de_la_lletra(cami):
    """Codis Unicode que una lletra TrueType sap dibuixar (taula cmap, formats 4 i 12).

    Es llegeix a mà per no dependre de fontTools. Dona el mateix que
    fontTools.getBestCmap() amb Caveat (753 caràcters) i amb DejaVu Sans.
    """
    with open(cami, 'rb') as f:
        d = f.read()
    n_taules = struct.unpack('>H', d[4:6])[0]
    taules = {}
    for i in range(n_taules):
        etiqueta, _, desp, _ = struct.unpack('>4sIII', d[12 + 16 * i: 28 + 16 * i])
        taules[etiqueta] = desp
    base = taules[b'cmap']
    n = struct.unpack('>H', d[base + 2:base + 4])[0]
    codis = set()
    for i in range(n):
        plataforma, _, desp = struct.unpack('>HHI', d[base + 4 + 8 * i: base + 12 + 8 * i])
        if plataforma not in (0, 3):
            continue
        s = base + desp
        fmt = struct.unpack('>H', d[s:s + 2])[0]
        if fmt == 4:
            seg2 = struct.unpack('>H', d[s + 6:s + 8])[0]
            seg = seg2 // 2
            finals = struct.unpack(f'>{seg}H', d[s + 14: s + 14 + seg2])
            inicis = struct.unpack(f'>{seg}H', d[s + 16 + seg2: s + 16 + 2 * seg2])
            deltes = struct.unpack(f'>{seg}h', d[s + 16 + 2 * seg2: s + 16 + 3 * seg2])
            pos_ro = s + 16 + 3 * seg2
            ros = struct.unpack(f'>{seg}H', d[pos_ro: pos_ro + seg2])
            for k in range(seg):
                for c in range(inicis[k], finals[k] + 1):
                    if c == 0xFFFF:
                        continue
                    if ros[k] == 0:
                        glif = (c + deltes[k]) & 0xFFFF
                    else:
                        adr = pos_ro + 2 * k + ros[k] + 2 * (c - inicis[k])
                        glif = struct.unpack('>H', d[adr:adr + 2])[0]
                        if glif:
                            glif = (glif + deltes[k]) & 0xFFFF
                    if glif:
                        codis.add(c)
        elif fmt == 12:
            n_grups = struct.unpack('>I', d[s + 12:s + 16])[0]
            for g in range(n_grups):
                ini, fi, glif0 = struct.unpack('>III', d[s + 16 + 12 * g: s + 28 + 12 * g])
                for c in range(ini, fi + 1):
                    if glif0 + (c - ini):
                        codis.add(c)
    return codis


# --------------------------------------------------------------------------
# Les igualtats escrites, calculades de debò.
# Un tros de càlcul és una tira de números, signes (· + − -), parèntesis, ² i √,
# amb algun «=». Dins d'un tros, dos números seguits sense signe entremig són dues
# operacions diferents (les files d'una taula, les cel·les d'una fila), i s'hi
# talla. Cada banda es calcula amb l'ordre de les operacions: el parèntesi, el
# quadrat i l'arrel, la multiplicació, i la suma i la resta al final. Totes les
# bandes han de donar el mateix. Una banda buida és un buit per omplir: no es
# comprova. Una banda que no es pot llegir (una arrel que no és exacta, per
# exemple) fa que la igualtat es deixi estar, perquè no se'n pot dir res.
# --------------------------------------------------------------------------
# Un tros també pot començar per un signe: amb un buit al davant, «… · 4 = 20» es
# llegeix «· 4 = 20», que no es pot calcular, i no «4 = 20», que seria fals.
# Els decimals (unitat 5) s'escriuen amb coma i sense espais: «2,5 + 1,35 = 3,85». Una
# coma seguida d'un espai és la d'una frase («3, 4 i 5») i talla el tros, com abans.
TROS_CALCUL = re.compile(r'[\d(√·+−\-/](?:[\d\s·+−\-()²√=/]|,(?=\d))*[\d)²]')
PECES_CALCUL = re.compile(r'\d+(?:,\d+)?|[·+−\-()²√=/]')


def es_nombre(p):
    """«12» o «2,43»: un nombre, natural o decimal."""
    return bool(p) and bool(re.fullmatch(r'\d+(?:,\d+)?', p))


def valor_de(peces):
    """Calcula una llista de peces. Retorna un enter, o None si no es pot llegir."""
    pos = [0]

    def mira():
        return peces[pos[0]] if pos[0] < len(peces) else None

    def pren():
        pos[0] += 1
        return peces[pos[0] - 1]

    def primari():
        p = mira()
        if p is None:
            raise ValueError
        if p == '(':
            pren()
            v = suma()
            if mira() != ')':
                raise ValueError
            pren()
            return v
        if p == '√':
            pren()
            v = potencia()
            arrel = int(round(v ** 0.5)) if v >= 0 else -1
            if arrel * arrel != v:
                raise ValueError
            return arrel
        if es_nombre(p):
            pren()
            # Un decimal es calcula exacte, com les fraccions: 0,25 = 1/4 i 3,4 = 3,40.
            return int(p) if p.isdecimal() else Fraction(p.replace(',', '.'))
        raise ValueError

    def potencia():
        v = primari()
        while mira() == '²':
            pren()
            v = v * v
        return v

    def producte():
        # La barra de les fraccions va com la multiplicació, i es calcula exacta:
        # 1/2 = 2/4, i no 0,5 = 0,5 amb decimals que no quadren.
        v = potencia()
        while mira() in ('·', '/'):
            if pren() == '·':
                v = v * potencia()
            else:
                w = potencia()
                if w == 0:
                    raise ValueError
                v = Fraction(v) / w
        return v

    def suma():
        v = producte()
        while mira() in ('+', '−', '-'):
            op = pren()
            w = producte()
            v = v + w if op == '+' else v - w
        return v

    try:
        v = suma()
        return v if pos[0] == len(peces) else None
    except (ValueError, IndexError):
        return None


def igualtats(text):
    """Les igualtats del text que es poden comprovar: (com està escrita, valors)."""
    for tros in TROS_CALCUL.findall(text):
        if '=' not in tros:
            continue
        peces = PECES_CALCUL.findall(tros)
        trams, ara = [], []
        for p in peces:
            obre = es_nombre(p) or p in ('(', '√')
            tanca = bool(ara) and (es_nombre(ara[-1]) or ara[-1] in (')', '²'))
            if obre and tanca:
                trams.append(ara)
                ara = []
            ara.append(p)
        trams.append(ara)
        for tram in trams:
            if '=' not in tram:
                continue
            bandes, banda = [], []
            for p in tram:
                if p == '=':
                    bandes.append(banda)
                    banda = []
                else:
                    banda.append(p)
            bandes.append(banda)
            plenes = [b for b in bandes if b]
            if len(plenes) < 2:
                continue
            valors = [valor_de(b) for b in plenes]
            if any(v is None for v in valors):
                continue
            escrit = " = ".join(" ".join(b) for b in plenes)
            for a, b in (("( ", "("), (" )", ")"), (" ²", "²"), ("√ ", "√")):
                escrit = escrit.replace(a, b)
            yield escrit, valors


# --------------------------------------------------------------------------
# Cap examen dins del repositori. Es publica tot (comu/docs/DESPLEGAMENT.md), i un
# DOCX d'examen o de solucionari es podria obrir des del web abans de l'examen. Els
# DOCX surten a docx/, que el .gitignore deixa fora; no es pugen mai.
print("EXÀMENS")
fora_de_docx = sorted(os.path.relpath(os.path.join(d, f), ARREL)
                      for d, _, fs in os.walk(ARREL) for f in fs
                      if f.lower().endswith(".docx") and os.path.relpath(d, ARREL).split(os.sep)[0] != "docx")
for f in fora_de_docx:
    comprova(False, f"{f} és dins del repositori i es publica al web: treu-lo (vegeu el README, «L'examen»)")
print(f"  DOCX dins del repositori: {len(fora_de_docx)}")
print()

# --------------------------------------------------------------------------
print("FITXES I TARGETES")
# --------------------------------------------------------------------------
css_fitxa = llegeix(ruta('css', 'fitxa.css'))
comprova(not cromatics(css_fitxa), f"css/fitxa.css conté color: {cromatics(css_fitxa)}")
print(f"  css/fitxa.css                cap color: {not cromatics(css_fitxa)}")
if not FITXES:
    print("  encara no hi ha cap fitxa a fitxes/")

for f in PAPER:
    nom = rel(f)
    s = llegeix(f)
    e = Estructura()
    e.feed(s)
    estructura = not e.err and not e.pila
    color = cromatics(s)
    cap, alumnat, sol = paper.blocs(s)
    comprova(estructura, f"{nom}: HTML mal tancat ({e.err[:3] or e.pila[-3:]})")
    comprova(not color, f"{nom}: hi ha color ({color})")
    comprova('../css/tokens.css' in cap and '../css/fitxa.css' in cap and '<style' not in s,
             f"{nom}: ha d'enllaçar ../css/tokens.css i ../css/fitxa.css, i no pot dur <style>")
    comprova(len(re.findall(r'<div class="full[^"]*">', s)) == len(alumnat) + len(sol),
             f"{nom}: algun bloc .full no acaba amb un </div> a principi de línia")
    if f in FITXES:
        pags = [int(n) for n in re.findall(r'· pàgina (\d+)</div>', s)]
        comprova(pags == list(range(1, len(pags) + 1)), f"{nom}: numeració de pàgines {pags}")
        comprova(s.count('class="previ"') == 1, f"{nom}: falta el rètol del graó físic (.previ)")
        comprova(s.count('Què hi veus?') == 1, f"{nom}: falta la pregunta d'obertura")
        comprova(s.count('class="full vida"') == 1, f"{nom}: falta la pàgina «A la vida de cada dia»")
        comprova(bool(sol), f"{nom}: falta el solucionari (.full.sol)")
        detall = f"{len(pags)} pàg."
    else:
        cares = [int(n) for n in re.findall(r'· cara (\d+)</div>', s)]
        comprova(cares == list(range(1, len(alumnat) + 1)), f"{nom}: numeració de cares {cares}")
        detall = f"{len(cares)} cares"
    print(f"  {nom:28} {detall} · html {'ok' if estructura else 'ERROR'} · "
          f"color {'cap' if not color else color}")

# --------------------------------------------------------------------------
print("\nPÀGINES DE L'ALUMNAT")
# Regles del material (docs/CRITERIS-DISSENY.md) que es poden comprovar soles.
# --------------------------------------------------------------------------
SIGLES = {"PDF"}
ROMANS = re.compile(r'^M{0,3}(CM|CD|D?C{0,3})(XC|XL|L?X{0,3})(IX|IV|V?I{0,3})$')
# Les decisions de llenguatge de l'examen revisat pel docent (comu/docs/EXAMENS-DOCX.md, §5).
LLENGUATGE = [(r'\bEncercla\b', "«Encercla»: el verb és «Marca»"),
              # Només quan parla de nombres: «nombres sencers», «coses senceres» (la taula de la
              # regla I). Un «quadret sencer», al costat d'un mig, és català correcte i és el
              # vocabulari de l'àrea de la unitat 3 (el comptava com un error fins al 29/9/2026).
              (r'\b(nombres?|quantitats?|coses?|xifres?)\s+sencer(s|a|es)?\b', "«sencer»: el terme és «enter»"),
              (r'\bquant fa\b', "«quant fa»: fes servir el verb literal («quant és», «quant mesura»)"),
              (r'\bho \w+ries\b', "«ho …ries»: sense pronoms febles"),
              (r'\bnomés fas\b', "«només fas»: deixa de ser veritat si s'hi afegeixen apartats")]
NOMBRE = re.compile(r'(?<![\d.,])\d{1,3}(?:\.\d{3})+(?![\d,])|(?<![\d.,])\d+')
# Els decimals de la unitat 5: fins a 9,99, amb dues xifres decimals com a molt (decisió del
# docent del 29/9/2026). És el mateix límit de sempre: 9,99 són 999 centèsimes, els blocs de
# la unitat 1 amb el quadrat de 100 com a unitat. Les mil·lèsimes (0,125) en demanarien 1.000.
DECIMAL = re.compile(r'(?<![\d.,])(\d+),(\d+)(?![\d,])')


def decimal_fora(t):
    """Els decimals d'un text que passen de 9,99 o tenen més de dues xifres decimals."""
    return [m.group(0) for m in DECIMAL.finditer(t) if int(m.group(1)) > 9 or len(m.group(2)) > 2]

n_frases = n_operacions = 0
for f in PAPER:
    nom = rel(f)
    s = llegeix(f)
    sense_comentaris = re.sub(r'<!--.*?-->', '', s, flags=re.S)

    # Dignitat: cap pàgina de l'alumnat no diu que és adaptada, ni al títol.
    comprova(not re.search(r'adapta(t|da|ts|des|ció|cions)\b', sense_comentaris, re.I),
             f"{nom}: diu «adaptat» en algun lloc que es veu")

    # Per multiplicar, el punt de l'ESO. «×» només pot sortir dins de
    # .simbol-primaria, que és on la targeta de les taules fa el pont.
    for tros in trossos(f):
        for t, c in tros:
            if '×' in t and 'simbol-primaria' not in c:
                falles.append(f"{nom}: «×» fora de .simbol-primaria: «{' '.join(t.split())[:40]}»")
    for frase in frases_alumnat(f, sense={'simbol-primaria'}):
        m = re.search(r'\d\s*[xX]\s*\d', frase)
        comprova(not m, f"{nom}: multiplicació amb la lletra x: «{m.group(0) if m else ''}»")

    for frase in frases_alumnat(f):
        n_frases += 1
        for m in NOMBRE.finditer(frase):
            # L'única excepció: «1 km = 1.000 m» (decisió del docent del 26/9/2026, unitat 3). El
            # 1.000 hi pot sortir només dins d'aquesta equivalència; el 1.000.000 dels km², mai.
            if m.group(0) == "1.000" and re.search(r"1\s*km\s*=\s*1\.000\s*m\b", frase):
                continue
            comprova(int(m.group(0).replace('.', '')) <= 999,
                     f"{nom}: el nombre {m.group(0)} passa de 999: «{frase[:50]}»")
        for d in decimal_fora(frase):
            comprova(False, f"{nom}: el decimal {d} passa de 9,99 o té més de dues xifres decimals: «{frase[:50]}»")
        for tall in re.split(r'(?<=[.!?])\s+', frase):
            paraules = re.findall(r"[\w·'’]+", tall)
            comprova(len(paraules) <= 20, f"{nom}: frase de {len(paraules)} paraules: «{tall[:50]}…»")
            avisa(len(paraules) <= 15, f"{nom}: frase de {len(paraules)} paraules: «{tall[:50]}…»")
        rep = re.search(r'\b([^\W\d]+)\s+\1\b', frase, re.I)
        comprova(not rep, f"{nom}: paraula repetida («{rep.group(0) if rep else ''}»)")
        comprova(not re.search(r'\bclica\b|\bclic\b', frase, re.I), f"{nom}: «clica aquí» no diu on porta")
        comprova(not re.search(r'\b([01]?\d|2[0-3]):[0-5]\d\b', frase), f"{nom}: hora en format de 24 h")
        for p in re.findall(r'\b[A-ZÀ-Ú]{2,}\b', frase):
            if p in SIGLES:
                continue
            comprova(not ROMANS.match(p), f"{nom}: xifres romanes («{p}»)")
            comprova(len(p) < 3 or ROMANS.match(p), f"{nom}: paraula en majúscules («{p}»)")
        for patro, explicacio in LLENGUATGE:
            avisa(not re.search(patro, frase, re.I), f"{nom}: {explicacio}")

    # Cap operació escrita pot estar malament: ni a l'alumnat ni al solucionari.
    # Es calcula cada igualtat sencera, amb l'ordre de les operacions: «2 + 3 · 4 = 14»,
    # «(2 + 3) · 4 = 20», «3² = 3 · 3 = 9», «√16 = 4».
    text = tot_el_text(f)
    for escrit, valors in igualtats(text_de_calcul(f)):
        n_operacions += 1
        comprova(len(set(valors)) == 1,
                 f"{nom}: {escrit} està malament (cada banda dona {', '.join(map(str, valors))})")

    # La targeta de les taules ha de tenir les cent, ni una més ni una menys.
    if os.path.basename(f) == 'taules.html':
        parelles = sorted((int(a), int(b)) for a, b in re.findall(r'(\d+)\s*·\s*(\d+)\s*=\s*\d+', text))
        esperades = sorted((a, b) for a in range(1, 11) for b in range(1, 11))
        comprova(parelles == esperades, f"{nom}: no hi ha exactament les cent multiplicacions de l'1 al 10")
print(f"  {len(PAPER)} fitxers · {n_frases} frases de l'alumnat · {n_operacions} operacions comprovades")

# --------------------------------------------------------------------------
print("\nLLETRA MANUSCRITA")
# Sense la lletra al repositori, el PDF surt amb el model resolt en lletra
# d'impremta i no avisa ningú. I Caveat no té tots els caràcters.
# --------------------------------------------------------------------------
tokens = llegeix(ruta('css', 'tokens.css'))
cara_lletra = re.search(r'@font-face\s*\{[^}]*font-family:\s*"Caveat"[^}]*url\("([^"]+)"', tokens)
comprova(bool(cara_lletra), "css/tokens.css no declara la lletra Caveat amb @font-face")
fitxer_lletra = os.path.normpath(os.path.join(ruta('css'), cara_lletra.group(1))) if cara_lletra else ''
comprova(os.path.exists(fitxer_lletra), f"no hi ha el fitxer de la lletra: {rel(fitxer_lletra) if fitxer_lletra else '?'}")
comprova(os.path.exists(ruta('fonts', 'OFL.txt')), "falta fonts/OFL.txt: la llicència de Caveat ha d'anar amb la lletra")
comprova(re.search(r'--manuscrita:\s*"Caveat"', tokens) is not None,
         "--manuscrita ha de començar per \"Caveat\"")
if os.path.exists(fitxer_lletra):
    te = caracters_de_la_lletra(fitxer_lletra)
    n_ms = 0
    for f in PAPER:
        for tros in trossos(f):
            for t, c in tros:
                if c & {'ms', 'et-resolt'}:
                    n_ms += len(t.strip())
                    falten = sorted({ch for ch in t if not ch.isspace() and ord(ch) not in te})
                    comprova(not falten, f"{rel(f)}: text manuscrit amb caràcters que Caveat no té: "
                                         f"{' '.join(falten)} (a «{t.strip()[:30]}»)")
    print(f"  {rel(fitxer_lletra)}: {len(te)} caràcters · {n_ms} caràcters manuscrits comprovats")

# --------------------------------------------------------------------------
print("\nCAIXA D'EINES")
# La mateixa arquitectura que la caixa de 4eso/ (docs/ARQUITECTURA.md). Els
# números de tasca surten als enllaços que el docent envia (caixa-eines?task=n):
# un número ja enviat no es canvia mai.
# --------------------------------------------------------------------------
CAIXA = ruta('caixa-eines.html')
TEXTOS_JS = ruta('dades', 'textos.js')
if not os.path.exists(CAIXA):
    print("  encara no n'hi ha")
else:
    app = llegeix(CAIXA)
    e = Estructura(); e.feed(app)
    comprova(not e.err and not e.pila, "caixa-eines.html: HTML mal tancat")

    pestanyes = sorted(set(re.findall(r'data-mod="(\w+)"', app)))
    seccions = sorted(set(re.findall(r'<section id="mod-(\w+)"', app)))
    fitxers_mod = sorted(glob.glob(ruta('js', 'moduls', '*.js')))
    registrats = sorted({m.group(1) for x in fitxers_mod
                         for m in [re.search(r'CE\.registra\("(\w+)"', llegeix(x))] if m})
    # Els mòduls es carreguen quan s'obren: cada pestanya diu el seu fitxer a data-src (30/9/2026).
    carregats = re.findall(r'data-src="js/moduls/([\w-]+)\.js"', app)
    # Un mòdul que fa servir una funció d'un altre (CE.botonsSiNo és de multiples.js) l'ha
    # de dir a data-cal, perquè es carregui abans: si no, surt sense botons.
    defineix = {n: re.search(r'CE\.registra\("(\w+)"', llegeix(x))[1]
                for x in fitxers_mod for n in re.findall(r'CE\.(\w+) = ', llegeix(x)) if n != 'dades'}
    cals = dict(re.findall(r'data-mod="(\w+)"[^>]*?data-cal="([^"]*)"', app))
    for x in fitxers_mod:
        codi = llegeix(x)
        propi = re.search(r'CE\.registra\("(\w+)"', codi)[1]
        cal = {defineix[n] for n in re.findall(r'CE\.(\w+)\(', codi) if n in defineix and defineix[n] != propi}
        comprova(cal <= set(cals.get(propi, '').split()),
                 f"caixa-eines.html: la pestanya {propi} fa servir {sorted(cal)} i no ho diu a data-cal")
    for mod, src in re.findall(r'data-mod="(\w+)" data-src="([^"]+)"', app):
        comprova(os.path.exists(ruta(src)) and f'CE.registra("{mod}"' in llegeix(ruta(src)),
                 f"caixa-eines.html: la pestanya {mod} diu data-src=\"{src}\", que no registra «{mod}»")
    comprova(pestanyes == seccions == registrats,
             f"identificadors descompassats: pestanyes {pestanyes} · seccions {seccions} · registrats {registrats}")
    comprova(sorted(carregats) == sorted(os.path.basename(x)[:-3] for x in fitxers_mod),
             "hi ha mòduls a js/moduls que no es carreguen, o a l'inrevés")
    ordre_bo = ['dades/textos.js', 'js/nucli.js', 'js/codi.js', 'js/tasca.js', 'js/quadricula.js']
    posicions = [app.find(f'src="{x}"') for x in ordre_bo]
    comprova(all(x >= 0 for x in posicions) and posicions == sorted(posicions),
             "els scripts base van en aquest ordre: " + ", ".join(ordre_bo))
    darrer = app.rfind('src="js/app.js"')
    comprova(darrer > max(posicions), "js/app.js s'ha de carregar després dels scripts base")
    comprova(not re.search(r'<script src="js/moduls/', app),
             "caixa-eines.html: els mòduls no es carreguen d'entrada, sinó quan s'obren (data-src)")
    comprova('href="../favicon.svg"' in app, "caixa-eines.html: la icona és ../favicon.svg")
    # Cada identificador, una sola vegada. Amb dos iguals, $("#x") troba el primer i un
    # mòdul dibuixa dins d'un altre: la tasca 15 escrivia a la taula de la tasca 0,
    # perquè totes dues feien servir tt- i tf- (trobat el 29/9/2026).
    ids = re.findall(r'\bid="([^"]+)"', app)
    repetits = sorted({i for i in ids if ids.count(i) > 1})
    comprova(not repetits, f"caixa-eines.html: identificadors repetits {repetits}: cada eina ha de tenir el seu prefix")
    pestanyes_html = re.findall(r'<button[^>]*class="segment"[^>]*>', app)
    numeros = [(re.search(r'data-tasca="([^"]*)"', b) or [None, None])[1] for b in pestanyes_html]
    mods = [(re.search(r'data-mod="(\w+)"', b) or [None, '?'])[1] for b in pestanyes_html]
    comprova(bool(numeros) and all(n is not None and re.fullmatch(r'0|[1-9]\d*', n) for n in numeros)
             and len(set(numeros)) == len(numeros) and numeros[0] == "0",
             f"data-tasca de les pestanyes: {numeros} (un número a cada una, sense repetir, i el 0 el primer)")
    comprova(mods[:1] == ['taules'], "la tasca 0 ha de ser la de les taules: és la que surt sempre")
    print(f"  mòduls: {len(registrats)} · marcatge, registre i scripts coincideixen: "
          f"{pestanyes == seccions == registrats}")
    print("  tasques: " + " · ".join(f"{n} {m}" for n, m in zip(numeros, mods)))

    # ----------------------------------------------------------------------
    print("\nFRASES")
    # Les frases viuen a dades/textos.js. Si una clau no existeix, a la pantalla
    # surt «[1.2.titol]»: s'ha de veure aquí i no a classe.
    # ----------------------------------------------------------------------
    textos_js = llegeix(TEXTOS_JS)

    def claus_de(bloc):
        out = set()
        for grup, cos in re.findall(r'^  "([\w.]+)":\s*\{(.*?)\n  \}', bloc, re.S | re.M):
            for nom in re.findall(r'^\s{4}(\w+):', cos, re.M):
                out.add(grup + "." + nom)
        return out

    def frases_de(bloc):
        out = {}
        for grup, cos in re.findall(r'^  "([\w.]+)":\s*\{(.*?)\n  \}', bloc, re.S | re.M):
            for nom, val in re.findall(r"^\s{4}(\w+):\s*'((?:[^'\\]|\\.)*)'", cos, re.M):
                out[grup + "." + nom] = re.sub(r"\\(.)", r"\1", val)
        return out

    tall = textos_js.index("window.TEXTOS_GUIA")
    definides_t = claus_de(textos_js[:tall])
    guiades = claus_de(textos_js[tall:])
    grups = sorted({c.rsplit(".", 1)[0] for c in definides_t}, key=len, reverse=True)
    g = "(?:" + "|".join(re.escape(x) for x in grups) + ")"
    usades = set(re.findall(r'data-text="(' + g + r'\.\w+)"', app))
    prefixos = set()
    for f in sorted(glob.glob(ruta('js', '**', '*.js'), recursive=True)):
        codi = llegeix(f)
        usades |= set(re.findall(r'"(' + g + r'\.[A-Za-z_]\w*)"(?!\s*\+)', codi))
        prefixos |= set(re.findall(r'"(' + g + r')\.\w*"\s*\+', codi))
        # claus muntades amb una variable: txt("3.1.et_" + k)
        prefixos |= {m for m in re.findall(r'"(' + g + r'\.\w+_)"\s*\+', codi)}
    comprova(not (usades - definides_t), f"frases que es demanen i no existeixen: {sorted(usades - definides_t)}")
    comprova(not (definides_t - guiades), f"frases sense explicació a TEXTOS_GUIA: {sorted(definides_t - guiades)}")
    comprova(not (guiades - definides_t), f"explicacions de frases que no existeixen: {sorted(guiades - definides_t)}")
    orfes = sorted(c for c in definides_t - usades
                   if not c.endswith(".nom")
                   and c.rsplit(".", 1)[0] not in prefixos
                   and not any(c.startswith(pf) for pf in prefixos))
    avisa(not orfes, f"frases que no fa servir ningú: {orfes}")
    print(f"  frases definides: {len(definides_t)} · totes les que es demanen existeixen: "
          f"{not (usades - definides_t)} · sense fer servir: {orfes if orfes else 'cap'}")

    # ----------------------------------------------------------------------
    print("\nLECTURA FÀCIL")
    # Les regles de la norma UNE 153101:2018 EX que es poden comprovar soles.
    #   Falla: una frase de més de 20 paraules, una paraula repetida seguida,
    #          «clica», xifres romanes, hores de 24 h o paraules en majúscules.
    #   Avisa: frases de més de 15 paraules, i parèntesis o punt i coma.
    # ----------------------------------------------------------------------
    n_lf = 0
    for clau, t in frases_de(textos_js[:tall]).items():
        n_lf += 1
        net = re.sub(r"\{\w+\}", "X", t.replace("*", ""))
        for frase in re.split(r"(?<=[.!?])\s+", net):
            paraules = re.findall(r"[\w·'’√]+", frase)
            comprova(len(paraules) <= 20, f"Lectura Fàcil · {clau}: frase de {len(paraules)} paraules")
            avisa(len(paraules) <= 15 or len(paraules) > 20, f"Lectura Fàcil · {clau}: frase de {len(paraules)} paraules")
        rep = re.search(r"\b(\w+)\s+\1\b", net, re.I)
        comprova(not rep, f"Lectura Fàcil · {clau}: paraula repetida («{rep.group(0) if rep else ''}»)")
        comprova(not re.search(r"\bclica\b|\bclic\b", net, re.I), f"Lectura Fàcil · {clau}: «clica» no diu on porta")
        comprova(not re.search(r"\b([01]?\d|2[0-3]):[0-5]\d\b", net), f"Lectura Fàcil · {clau}: hora de 24 h")
        for pm in re.findall(r"\b[A-ZÀ-Ú]{2,}\b", net):
            if pm in SIGLES:
                continue
            comprova(not ROMANS.match(pm), f"Lectura Fàcil · {clau}: xifra romana «{pm}»")
            comprova(ROMANS.match(pm) or len(pm) < 3, f"Lectura Fàcil · {clau}: paraula en majúscules «{pm}»")
        avisa(not re.search(r"[;()]", net), f"Lectura Fàcil · {clau}: parèntesis o punt i coma")
    print(f"  frases revisades: {n_lf}")

    # ----------------------------------------------------------------------
    print("\nSUBTASQUES")
    # Cada mòdul és 1.1, 1.2… amb la barra de fletxes, els panells numerats de
    # l'1 endavant i el nom a dades/textos.js: així ?task=1.3 va on toca.
    # ----------------------------------------------------------------------
    for nom, cos in re.findall(r'<section id="mod-(\w+)"[^>]*>(.*?)</section>', app, re.S):
        subs = [int(x) for x in re.findall(r'class="subtasca"[^>]*data-sub="(\d+)"', cos)]
        if not subs:
            continue
        comprova(subs == list(range(1, len(subs) + 1)), f"mod-{nom}: les subtasques van {subs}, han d'anar 1, 2, 3…")
        for peca in ("sub-enrere", "sub-avant", "sub-rotul"):
            comprova(peca in cos, f"mod-{nom} té subtasques però li falta .{peca}")
        pestanya = re.search(r'data-tasca="(\d+)" data-mod="' + nom + '"', app)
        if pestanya:
            for n in subs:
                comprova(f"{pestanya.group(1)}.{n}.nom" in definides_t,
                         f"falta la frase {pestanya.group(1)}.{n}.nom a dades/textos.js")
        print(f"  mod-{nom}: {len(subs)} subtasques")

    # ----------------------------------------------------------------------
    print("\nLA PANTALLA")
    # Les regles del curs valen igual a la pantalla que al paper
    # (docs/CRITERIS-DISSENY.md). Aquí es miren a les frases i al marcatge; el
    # text que surt de debò el mira eines/prova_caixa.py.
    # ----------------------------------------------------------------------
    frases_t = frases_de(textos_js[:tall])
    vist = "\n".join(frases_t.values()) + "\n" + re.sub(r"<[^>]+>", " ", app)
    comprova("×" not in vist, "a la caixa no hi ha d'haver «×»: es multiplica amb «·»")
    comprova(not re.search(r"\d\s*[xX]\s*\d", vist), "a la caixa una «x» multiplica")
    grans = sorted({int(n) for n in re.findall(r"(?<![\d.,])\d+(?![\d,])", "\n".join(frases_t.values())) if int(n) > 999})
    comprova(not grans, f"frases de la caixa amb nombres de més de 999: {grans}")
    dec_fora = sorted({d for t in frases_t.values() for d in decimal_fora(t)})
    comprova(not dec_fora, f"frases de la caixa amb decimals de més de 9,99 o amb més de dues xifres: {dec_fora}")
    for clau, t in frases_t.items():
        for patro, per_que in LLENGUATGE:
            avisa(not re.search(patro, t), f"{clau}: {per_que}")
    for f in [CAIXA, TEXTOS_JS]:
        comprova(not re.search(r"adapta", llegeix(f), re.I), f"{rel(f)}: l'alumnat no ha de llegir «adaptat»")
    js_tot = {f: llegeix(f) for f in glob.glob(ruta('js', '**', '*.js'), recursive=True)}
    claus_mem = [(rel(f), k) for f, t in js_tot.items()
                 for k in re.findall(r'(?:CLAU\s*=|clau\s*=\s*cfg\s*=>)\s*"([^"]+)"', t)]
    comprova(claus_mem and all(k.startswith("pi1-") for _, k in claus_mem),
             f"les claus de la memòria del navegador han de començar per «pi1-»: {claus_mem}")
    sal = re.search(r'const SAL = "([^"]+)"', js_tot.get(ruta('js', 'codi.js'), ''))
    sal_altra = re.search(r'const SAL = "([^"]+)"', llegeix(os.path.join(REPO, '4eso', 'js', 'codi.js'))) \
        if os.path.exists(os.path.join(REPO, '4eso', 'js', 'codi.js')) else None
    comprova(bool(sal) and (not sal_altra or sal.group(1) != sal_altra.group(1)),
             "js/codi.js ha de tenir una SAL pròpia, diferent de la de l'altra caixa")
    print(f"  cap «×» ni «x» de multiplicar · cap nombre de més de 999 · claus del navegador: "
          f"{', '.join(sorted({k for _, k in claus_mem}))} · sal pròpia: {bool(sal)}")

# --------------------------------------------------------------------------
print("\nPDF")
# Cada PDF ha de ser el que sortiria ara de la seva font. gen_pdf.py desa
# l'empremta de la font i de tot el que en decideix l'aspecte.
# --------------------------------------------------------------------------
esperats = {}
for f in FITXES:
    n = os.path.basename(f)[:-5]
    esperats[f"{n}-alumnat.pdf"] = rel(f)
    esperats[f"{n}-solucionari.pdf"] = rel(f)
for f in TARGETES:
    esperats[f"targeta-{os.path.basename(f)[:-5]}.pdf"] = rel(f)
try:
    empremtes = json.loads(llegeix(ruta('pdf', 'empremtes.json')))
except FileNotFoundError:
    empremtes = {}
    comprova(not esperats, "falta pdf/empremtes.json: passa generadors/gen_pdf.py")
al_dia = 0
for pdf, font in sorted(esperats.items()):
    if not comprova(os.path.exists(ruta('pdf', pdf)), f"falta pdf/{pdf}: passa generadors/gen_pdf.py"):
        continue
    e = empremtes.get(pdf, {})
    if comprova(e.get('empremta') == paper.empremta(font),
                f"pdf/{pdf} és d'abans de l'últim canvi de {font} o dels estils: passa generadors/gen_pdf.py"):
        al_dia += 1
for pdf in sorted(set(empremtes) - set(esperats)):
    avisa(False, f"pdf/empremtes.json parla de {pdf}, que ja no té font")
for pdf in sorted(os.path.basename(p) for p in glob.glob(ruta('pdf', '*.pdf'))):
    avisa(pdf in esperats, f"pdf/{pdf} no surt de cap fitxa ni targeta")
print(f"  PDF al dia: {al_dia}/{len(esperats)}")

# --------------------------------------------------------------------------
print("\nFULLS D'ESTIL")
# Una clau sense tancar no dona cap error visible: el navegador la tanca al final
# del fitxer i tot el que ve després queda dins d'aquell bloc.
# --------------------------------------------------------------------------
def claus_desaparellades(text):
    """Problemes de claus, amb la línia on són. Salta comentaris i cadenes."""
    linies, pila, errors = text.split('\n'), [], []
    i, n, linia = 0, len(text), 1
    while i < n:
        c = text[i]
        if text.startswith('/*', i):
            fi = text.find('*/', i + 2)
            if fi == -1:
                errors.append(f"comentari obert a la línia {linia} que no es tanca mai")
                break
            linia += text.count('\n', i, fi)
            i = fi + 2
            continue
        if c in '"\'':
            fi = i + 1
            while fi < n and text[fi] not in (c, '\n'):
                fi += 2 if text[fi] == '\\' else 1
            linia += text.count('\n', i, fi)
            i = fi + 1 if fi < n and text[fi] == c else fi
            continue
        if c == '\n':
            linia += 1
        elif c == '{':
            pila.append(linia)
        elif c == '}':
            if pila:
                pila.pop()
            else:
                errors.append(f"clau de tancament sobrant a la línia {linia}")
        i += 1
    errors += [f"clau oberta a la línia {l} que no es tanca mai: «{linies[l - 1].strip()[:50]}»"
               for l in pila]
    return errors


fulls = sorted(glob.glob(ruta('css', '*.css')))
for c in fulls:
    text = llegeix(c)
    errors = claus_desaparellades(text)
    comprova(not errors, f"{rel(c)}: " + "; ".join(errors))
    comprova('@import' not in text, f"{rel(c)} fa @import: enllaça els fulls des de l'HTML")
    print(f"  {rel(c):16} claus {'ok' if not errors else 'ERROR · ' + errors[0]}")

# Una variable que no existeix tampoc avisa: la propietat es queda sense efecte.
# Les que porten valor de reserva, var(--x, …), no compten.
fonts_css = (fulls + glob.glob(ruta('**', '*.html'), recursive=True) +
             glob.glob(ruta('js', '**', '*.js'), recursive=True))
textos = {f: llegeix(f) for f in fonts_css}
definides = {v for t in textos.values() for v in re.findall(r'(--[\w-]+)\s*:', t)}
sense_definir = {}
for f, t in textos.items():
    for v in re.findall(r'var\(\s*(--[\w-]+)\s*\)', t):
        if v not in definides:
            sense_definir.setdefault(v, set()).add(rel(f))
comprova(not sense_definir, "variables CSS que no estan definides enlloc: " +
         "; ".join(f"{v} a {', '.join(sorted(fs))}" for v, fs in sorted(sense_definir.items())))
print(f"  variables usades sense definir: {len(sense_definir)}")

# --------------------------------------------------------------------------
print("\nCONTRAST (WCAG 2.2 AA)")
# La paleta de pantalla de index.html, en mode clar i en mode fosc. Els colors
# amb transparència es componen sobre el fons on es fan servir de debò.
#   text normal ≥ 4,5:1   ·   elements gràfics ≥ 3:1
# --------------------------------------------------------------------------
def lineal(c):
    c /= 255
    return c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4


def lluminancia(r):
    return 0.2126 * lineal(r[0]) + 0.7152 * lineal(r[1]) + 0.0722 * lineal(r[2])


def contrast(a, b):
    la, lb = lluminancia(a), lluminancia(b)
    return (max(la, lb) + 0.05) / (min(la, lb) + 0.05)


def a_rgb(valor, sota=(255, 255, 255)):
    valor = valor.strip()
    if re.fullmatch(r"#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})", valor):
        return rgb(valor)
    m = re.fullmatch(r"rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*([\d.]+))?\s*\)", valor)
    if not m:
        raise ValueError(valor)
    alfa = float(m.group(4) or 1)
    return tuple(round(int(m.group(i + 1)) * alfa + sota[i] * (1 - alfa)) for i in range(3))


clar = dict(re.findall(r"(--[\w-]+):\s*([^;]+);", tokens[:tokens.index("@media")]))
fosc = dict(clar, **dict(re.findall(r"(--[\w-]+):\s*([^;]+);", tokens[tokens.index("@media"):])))
PARELLES = [   # (primer pla, fons, mínim, on es fa servir a index.html)
    ("--etiqueta",   "--superficie",   4.5, "text de les targetes"),
    ("--etiqueta-2", "--superficie",   4.5, "text secundari de les targetes"),
    ("--etiqueta-2", "--fons",         4.5, "subtítol, entradeta i peu"),
    ("--etiqueta-2", "--camp",         4.5, "etiquetes grises"),
    ("#FFFFFF",      "--blau",         4.5, "lletra dels botons dels PDF"),
    ("--blau-text",  "--superficie",   4.5, "enllaços dins de les targetes"),
    ("--blau-text",  "--fons",         4.5, "enllaços sobre el fons"),
    ("--blau-text",  "--blau-suau",    4.5, "número de la unitat"),
    ("--etiqueta",   "--verd-suau",    4.5, "etiqueta verda"),
    ("--etiqueta",   "--taronja-suau", 4.5, "nota taronja"),
    # la caixa d'eines (css/app.css)
    ("--etiqueta",   "--camp",         4.5, "caixa: pastilles i botons grisos"),
    ("--etiqueta",   "--segment",      4.5, "caixa: pestanyes"),
    ("--etiqueta-2", "--segment",      4.5, "caixa: pestanya no triada"),
    ("--superficie", "--verd",         4.5, "caixa: «Final» quan s'ha acabat"),
    ("--blau",       "--superficie",   3.0, "caixa: traç dels quadrets"),
    ("--taronja",    "--superficie",   3.0, "caixa: traç de la segona part i dels errors"),
    ("--etiqueta-3", "--superficie",   3.0, "caixa: traç discontinu dels llocs buits"),
]
# Els fons opacs de pàgina: el text transparent es compon sobre ells, i no sobre
# el blanc de la targeta, com fa el navegador.
OPACS = ("--fons", "--camp", "--segment")
for nom_mode, paleta in (("clar", clar), ("fosc", fosc)):
    sup = a_rgb(paleta["--superficie"])
    pitjor = None
    for pp, fons, minim, on in PARELLES:
        base = a_rgb(paleta[fons]) if fons in OPACS else sup
        fons_rgb = a_rgb(paleta[fons], sup) if not fons.startswith('#') else rgb(fons)
        pp_rgb = rgb(pp) if pp.startswith('#') else a_rgb(paleta[pp], fons_rgb if fons in OPACS else base)
        r = contrast(pp_rgb, fons_rgb)
        comprova(r >= minim, f"contrast en mode {nom_mode}: {pp} sobre {fons} fa {r:.2f}:1 "
                             f"i en cal {minim}:1 ({on})")
        if pitjor is None or r / minim < pitjor[0] / pitjor[1]:
            pitjor = (r, minim, pp, fons)
    print(f"  mode {nom_mode}: {len(PARELLES)} parelles · la més justa, {pitjor[2]} sobre "
          f"{pitjor[3]}: {pitjor[0]:.2f}:1 (mínim {pitjor[1]}:1)")

# --------------------------------------------------------------------------
print("\nENLLAÇOS")
# Tot va amb rutes relatives: així funciona igual publicat que des d'un llapis
# de memòria. Una ruta que comença per «/» apuntaria a l'arrel del lloc, fora
# de 1eso/. I el navegador no mostra Markdown: el baixa.
# --------------------------------------------------------------------------
n_enllacos = 0
for f in glob.glob(ruta('**', '*.html'), recursive=True) + fulls:
    text = re.sub(r'<!--.*?-->|/\*.*?\*/', '', llegeix(f), flags=re.S)
    destins = re.findall(r'(?:href|src)="([^"]+)"', text) + re.findall(r'url\(\s*["\']?([^"\')]+)', text)
    for d in destins:
        if re.match(r'(https?:|mailto:|data:|javascript:|#)', d):
            continue
        n_enllacos += 1
        net = d.split('#')[0].split('?')[0]
        comprova(not net.startswith('/'), f"{rel(f)}: ruta absoluta «{d}»: fes-la relativa")
        comprova(os.path.exists(os.path.normpath(os.path.join(os.path.dirname(f), net))),
                 f"{rel(f)}: l'enllaç «{d}» no porta enlloc")
        comprova(not net.endswith('.md') or f.endswith('.css'), f"{rel(f)}: enllaç a Markdown «{d}»")
print(f"  enllaços relatius comprovats: {n_enllacos}")

# --------------------------------------------------------------------------
print("\nDESPLEGAMENT")
# Els fitxers de publicació són a l'arrel del repositori i no són de 1eso/.
# Si en falta cap, no és feina d'aquesta carpeta, però cal saber-ho.
# --------------------------------------------------------------------------
for necessari in ('_headers', 'robots.txt', '404.html', 'favicon.svg', '.gitignore'):
    avisa(os.path.exists(os.path.join(REPO, necessari)), f"falta {necessari} a l'arrel del repositori")
print(f"  fitxers de desplegament a l'arrel: "
      f"{sum(os.path.exists(os.path.join(REPO, n)) for n in ('_headers', 'robots.txt', '404.html', 'favicon.svg', '.gitignore'))}/5")

# --------------------------------------------------------------------------
print("\nANONIMAT")
# Cap fitxer de 1eso/ no anomena el curs, el tipus d'aula ni cap diagnòstic, ni
# parla d'un alumne o d'una alumna en concret. Es descriu alumnat amb
# dificultats de tipus cognitiu, i prou. L'única excepció és el nom de la
# carpeta, que surt a les adreces: «1eso» passa dins d'una ruta, amb una barra
# al costat. Hi ha també els termes que vigila el test de 4eso/, que mira tot
# el repositori.
# --------------------------------------------------------------------------
PROHIBITS = [
    r"\b1r\s+ESO\b", r"\b1r\s+d'ESO\b", r"(?<![/\w])1eso(?![/\w])", r"\bprimer\s+d'ESO\b", r"\bde 1r\b",
    r"4t ESO", r"(?<![/\w])4eso(?![/\w])", r"4t d'ESO", r"4t A\b", r"\bde 4t\b",
    r"\bSIEI\b", r"\bUSEE\b", r"\bDIL\b", r"\bTEA\b", r"discapacitat", r"autis", r"trastorn", r"s[íi]ndrome",
    r"\bl'alumne\b", r"\bun alumne\b", r"\baquest alumne\b",
    r"\bl'alumna\b", r"\buna alumna\b", r"\baquesta alumna\b",
    r"\bdos alumnes\b", r"\bdues alumnes\b",
]
# El docent va decidir el 5/11/2026 que l'etiqueta del curs («1r ESO») surti a la pàgina del curs,
# a la de cada unitat i a la caixa d'eines. Només en aquestes tres pàgines, i només aquesta forma.
PAGINES_AMB_CURS = {os.path.abspath(ruta(x)) for x in ('index.html', 'unitat.html', 'caixa-eines.html')}
trobats = []
for f in sorted(glob.glob(ruta('**', '*.*'), recursive=True)):
    if os.path.splitext(f)[1] not in ('.md', '.html', '.js', '.css', '.json', '.txt') or f.endswith('OFL.txt'):
        continue
    text = llegeix(f)
    for patro in PROHIBITS:
        if os.path.abspath(f) in PAGINES_AMB_CURS and patro == r"\b1r\s+ESO\b":
            continue
        for m in re.finditer(patro, text, re.I):
            trobats.append((rel(f), m.group(0)))
comprova(not trobats, f"termes que trenquen l'anonimat: {trobats[:6]}")
print(f"  termes que trencarien l'anonimat: {len(trobats)}")

# --------------------------------------------------------------------------
print("\nDEPENDÈNCIES EXTERNES")
# Ni CDN ni lletres de Google: el filtre del centre no ho pot trencar, i
# funciona sense xarxa.
# --------------------------------------------------------------------------
remots = []
for f in glob.glob(ruta('**', '*.html'), recursive=True) + fulls:
    text = llegeix(f)
    remots += [(rel(f), u) for u in re.findall(r'(?:src|href)="(https?://[^"]+)"', text)]
    remots += [(rel(f), u) for u in re.findall(r'url\(\s*["\']?(https?://[^"\')]+)', text)]
comprova(not remots, f"recursos remots: {remots}")
print(f"  recursos remots: {len(remots)}")

# --------------------------------------------------------------------------
print("\nGENERADORS")
# Les fitxes i les targetes surten dels scripts de generadors/fitxes/ (menys la targeta de
# les taules, que es va fer a mà). Cada HTML diu de quin script surt, perquè ningú no
# l'editi a mà: el canvi es perdria la pròxima vegada que es generés (30/9/2026).
# Els generadors ja no fan servir exec(): les peces comunes són mòduls.
FETS_A_MA = {'targetes/taules.html'}
sense_capcalera = []
for f in sorted(FITXES) + sorted(TARGETES):
    if rel(f) in FETS_A_MA:
        continue
    m = re.search(r'<!-- Generat per 1eso/(generadors/fitxes/[\w.]+\.py)\.', llegeix(f)[:400])
    if not m or not os.path.exists(ruta(m[1])):
        sense_capcalera.append(rel(f))
comprova(not sense_capcalera, f"HTML sense la capçalera «Generat per …» o amb un generador que no existeix: {sense_capcalera}")
amb_exec = [rel(g) for g in glob.glob(ruta('generadors', 'fitxes', '*.py'))
            if re.search(r'^\s*exec\(', llegeix(g), re.M)]
comprova(not amb_exec, f"generadors que tornen a fer servir exec(): {amb_exec}")
print(f"  HTML amb el seu generador: {len(FITXES) + len(TARGETES) - len(FETS_A_MA) - len(sense_capcalera)}"
      f" · fets a mà: {len(FETS_A_MA)} · exec(): {len(amb_exec)}")

# --------------------------------------------------------------------------
print("\nDADES")
# dades/unitats.js és el que llegeixen la portada i unitat.html. Ha de quadrar amb el disc.
# --------------------------------------------------------------------------
dades = llegeix(ruta('dades', 'unitats.js'))
# Una clau repetida dins d'un objecte no dona cap error al navegador: es queda amb l'última.
# A la unitat 4 hi havia «fitxes: [...]» i, més avall, «fitxes: []», i la pàgina de la unitat no en
# veia cap (28/9/2026). Cada objecte comença amb «  {» i els seus camps van a quatre espais.
for bloc in re.findall(r'^  \{\n(.*?)^  \},?$', dades, re.S | re.M):
    camps = re.findall(r'^    (\w+):', bloc, re.M)
    repetits = sorted({c for c in camps if camps.count(c) > 1})
    ident = (re.search(r'^    (?:num|id):\s*("?[\w-]+"?)', bloc, re.M) or [None, '?'])[1]
    comprova(not repetits, f"dades/unitats.js: l'objecte {ident} té camps repetits {repetits}: "
                           f"el navegador es queda amb l'últim")
nums = [int(n) for n in re.findall(r'\bnum:\s*(\d+)', dades)]
comprova(nums == list(range(1, len(nums) + 1)), f"dades/unitats.js: les unitats no van seguides ({nums})")
fitxes_dades = re.findall(r'fitxa:\s*"([^"]+)"', dades)
for u in fitxes_dades:
    comprova(os.path.exists(ruta(u)), f"dades/unitats.js apunta a {u}, que no existeix")
for f in FITXES:
    comprova(rel(f) in fitxes_dades, f"{rel(f)} no surt a dades/unitats.js")
fitxers_t = re.findall(r'fitxer:\s*"([^"]+)"', dades)
pdfs_t = re.findall(r'pdf:\s*"([^"]+)"', dades)
for u in fitxers_t + pdfs_t:
    comprova(os.path.exists(ruta(u)), f"dades/unitats.js apunta a {u}, que no existeix")
for f in TARGETES:
    comprova(rel(f) in fitxers_t, f"{rel(f)} no surt a dades/unitats.js")
# Les tasques de la caixa que diu cada unitat han d'existir a caixa-eines.html.
tasques_dades = {int(n) for grup in re.findall(r'tasques:\s*\[([^\]]*)\]', dades)
                 for n in re.findall(r'\d+', grup)}
if tasques_dades:
    a_la_caixa = {int(n) for n in re.findall(r'data-tasca="(\d+)"', llegeix(ruta('caixa-eines.html')))} \
        if os.path.exists(ruta('caixa-eines.html')) else set()
    comprova(tasques_dades <= a_la_caixa, f"dades/unitats.js cita tasques que la caixa no té: "
                                          f"{sorted(tasques_dades - a_la_caixa)}")
print(f"  unitats: {len(nums)} · amb fitxa: {len(fitxes_dades)} · targetes: {len(fitxers_t)} · "
      f"tasques de la caixa citades: {len(tasques_dades)}")

def UNITATS_DE_LA_TARGETA(nom):
    m = re.search(r'id:\s*"%s",.*?\bunitat:\s*(\d+)' % re.escape(nom), dades, re.S)
    return [int(m[1])] if m else []


# --------------------------------------------------------------------------
print("\nNAVEGACIÓ")
# L'esquema és sempre curs → unitat → fitxa, quadern o caixa d'eines (5/11/2026, per encàrrec
# del docent). Tot el que és del tercer nivell torna a la pàgina de la seva unitat
# (unitat.html?ud=N), mai a una llista plana, i la unitat torna a la portada. Per això:
#   · cada fitxa (i cada quadern) té com a primer enllaç «← unitat N» (o «← la unitat», al
#     quadern), i la N és la unitat que la declara a dades/unitats.js;
#   · cada targeta de consulta torna a la unitat on neix i carrega comu/js/torna.js, que la fa
#     tornar a la unitat d'on ve (?ud=N);
#   · cap pàgina ni cap JS no enllaça fitxes.html ni quadern.html, que ja no existeixen.
# --------------------------------------------------------------------------
def _primer_enllac(text):
    m = re.search(r'<nav class="navega[^>]*>\s*<a ([^>]*)>([^<]*)</a>', text)
    return (m[1], m[2]) if m else ("", "")

_unitat_de = {}
for _bloc in re.findall(r'^  \{\n(.*?)^  \},?$', dades, re.S | re.M):
    _n = re.search(r'^    num:\s*(\d+)', _bloc, re.M)
    if not _n:
        continue
    for _f in re.findall(r'(?:fitxa|tancament|quadern):\s*"([^"]+)"', _bloc):
        _unitat_de[_f] = int(_n[1])
n_nav = 0
for _f, _n in sorted(_unitat_de.items()):
    if not os.path.exists(ruta(_f)):
        continue
    _attrs, _text = _primer_enllac(open(ruta(_f), encoding='utf-8').read())
    _text_bo = _text in (f"← unitat {_n}", "← la unitat")
    n_nav += 1
    comprova(f'href="../unitat.html?ud={_n}"' in _attrs and _text_bo,
             f"{_f}: el primer enllaç de dalt ha de tornar a la unitat {_n} (../unitat.html?ud={_n}), "
             f"i és «{_text}» ({_attrs})")
for _f in sorted(glob.glob(ruta('targetes', '*.html'))):
    _nom = os.path.basename(_f)[:-5]
    _t = open(_f, encoding='utf-8').read()
    _attrs, _text = _primer_enllac(_t)
    _units = UNITATS_DE_LA_TARGETA(_nom)
    n_nav += 1
    comprova(bool(_units) and 'data-unitat' in _attrs and f'href="../unitat.html?ud={_units[0]}"' in _attrs
             and _text == f"← unitat {_units[0]}",
             f"targetes/{_nom}.html: ha de tornar a la unitat {_units[:1]} (data-unitat, ../unitat.html?ud=N): "
             f"«{_text}» ({_attrs})")
    comprova('<script src="../../comu/js/torna.js"></script>' in _t,
             f"targetes/{_nom}.html: falta comu/js/torna.js, que la fa tornar a la unitat d'on ve")
_enllacos_morts = []
for _f in glob.glob(os.path.join(ARREL, '**', '*.html'), recursive=True) + glob.glob(ruta('js', '*.js')):
    if re.search(r"""(?:href\s*=|\.href\s*=)\s*["'](?:\.\./)?(?:fitxes|quadern)\.html""",
                 open(_f, encoding='utf-8').read()):
        _enllacos_morts.append(os.path.relpath(_f, REPO))
comprova(not _enllacos_morts, f"enllaços a fitxes.html o quadern.html, que ja no hi són: {_enllacos_morts}")
print(f"  pàgines que tornen a la seva unitat: {n_nav} · enllaços a pàgines planes: {len(_enllacos_morts)}")

# El camí mínim, l'estat, la regla trencada, la fita i el rol (grup 3, 30/9/2026).
# El camí mínim són les pàgines de l'alumnat que són el nucli de cada fitxa: han
# d'existir, i la unitat sencera no pot passar de dues pàgines per sessió del grup,
# perquè només la meitat de les hores són a l'aula de suport.
ESTATS = {"per revisar", "revisada", "provada a l'aula"}
n_minim = 0
for bloc in re.findall(r'^  \{\n(.*?)^  \},?$', dades, re.S | re.M):
    num = re.search(r'^    num:\s*(\d+)', bloc, re.M)
    if not num:
        continue                                   # una targeta
    num = int(num[1])
    comprova(re.search(r'^    fita:\s*"[^"]+"', bloc, re.M), f"dades/unitats.js: la unitat {num} no té fita")
    comprova(re.search(r'^    rol:\s*"[^"]+"', bloc, re.M), f"dades/unitats.js: la unitat {num} no diu el rol a l'aula ordinària")
    sessions = int(re.search(r'^    sessions:\s*"(\d+)', bloc, re.M)[1])
    total = 0
    for f_obj in re.findall(r'\{ fitxa:.*?\}', bloc, re.S):
        cami = re.search(r'fitxa:\s*"([^"]+)"', f_obj)[1]
        estat = (re.search(r'estat:\s*"([^"]+)"', f_obj) or [None, None])[1]
        comprova(estat in ESTATS, f"dades/unitats.js: {cami} té l'estat «{estat}» (val: {sorted(ESTATS)})")
        minim = [int(x) for x in re.findall(r'\d+', (re.search(r'minim:\s*\[([^\]]*)\]', f_obj) or [None, ''])[1])]
        comprova(minim, f"dades/unitats.js: {cami} no diu el camí mínim")
        if os.path.exists(ruta(cami)):
            html = llegeix(ruta(cami))
            pags = len([b for b in re.findall(r'<div class="full[^"]*">.*?\n</div>', html, re.S)
                        if 'class="full sol"' not in b[:30]])
            comprova(all(1 <= x <= pags for x in minim) and minim == sorted(set(minim)),
                     f"dades/unitats.js: el camí mínim de {cami} ({minim}) no són pàgines de la fitxa (en té {pags})")
        if not cami.endswith('-repas.html'):
            comprova('trencada:' in f_obj, f"dades/unitats.js: {cami} no diu on és la regla trencada")
        total += len(minim)
    comprova(total <= 2 * sessions, f"dades/unitats.js: el camí mínim de la unitat {num} fa {total} pàgines "
                                    f"per a {sessions} sessions (el màxim són {2 * sessions})")
    n_minim += total
print(f"  camí mínim: {n_minim} pàgines de l'alumnat, i cap unitat no passa de 2 per sessió")

# Els enllaços per a l'alumnat de la portada (index.html, «Per al professorat»).
# Fins al 29/9/2026 s'aturaven a la unitat 3, i ningú no ho veia: les tasques 14
# a 28 no hi eren. Ara, sota «Unitat N» hi ha d'haver totes les tasques que
# dades/unitats.js dona a la unitat N (menys la 0, que va a «Sempre»), i cada
# enllaç ha de començar amb el nom de la pestanya de la caixa.
portada = llegeix(ruta('index.html'))
pestanyes = dict(re.findall(r'data-tasca="(\d+)"[^>]*>([^<]+)</button>', llegeix(ruta('caixa-eines.html'))))
blocs_portada = re.split(r'<p class="enllacos-unitat">', portada)[1:]
enllacos = {}                                     # «Sempre» o el número de la unitat → {tasca}
for b in blocs_portada:
    rotol = b[:b.index('</p>')]
    clau = 'Sempre' if rotol.startswith('Sempre') else int((re.match(r'Unitat (\d+)', rotol) or [0, 0])[1])
    llista = b[:b.index('</ul>')] if '</ul>' in b else b
    for tasca, sub, nom in re.findall(r'href="caixa-eines\.html\?task=(\d+)(?:\.(\d+))?"><code>[^<]*</code></a>\s*([^<]+)</li>', llista):
        enllacos.setdefault(clau, set()).add(int(tasca))
        esperat = pestanyes.get(tasca, '?')
        comprova(nom.strip().startswith(esperat),
                 f"index.html: l'enllaç ?task={tasca}{'.' + sub if sub else ''} diu «{nom.strip()}», "
                 f"i la pestanya de la caixa es diu «{esperat}»")
comprova(enllacos.get('Sempre') == {0}, "index.html: a «Sempre» hi ha d'haver la tasca 0, i prou")
for bloc in re.findall(r'^  \{\n(.*?)^  \},?$', dades, re.S | re.M):
    num = re.search(r'^    num:\s*(\d+)', bloc, re.M)
    grup = re.search(r'^    tasques:\s*\[([^\]]*)\]', bloc, re.M)
    if not num:
        continue
    volgudes = {int(n) for n in re.findall(r'\d+', grup[1])} - {0} if grup else set()
    hi_son = enllacos.get(int(num[1]), set())
    comprova(volgudes <= hi_son, f"index.html: als enllaços de la unitat {num[1]} hi falten les tasques "
                                 f"{sorted(volgudes - hi_son)}")
    comprova(hi_son <= volgudes, f"index.html: als enllaços de la unitat {num[1]} hi ha tasques que "
                                 f"dades/unitats.js no li dona: {sorted(hi_son - volgudes)}")
print(f"  enllaços per a l'alumnat a la portada: {sum(len(v) for v in enllacos.values())}, "
      f"en {len(enllacos)} grups")

# --------------------------------------------------------------------------
print()
if avisos:
    print(f"{len(avisos)} AVISOS (no aturen res, però cal mirar-los):")
    for a in avisos:
        print("  ·", a)
    print()
if falles:
    print(f"{len(falles)} PROBLEMES:")
    for f in falles:
        print("  ·", f)
    sys.exit(1)
print("Tot correcte.")

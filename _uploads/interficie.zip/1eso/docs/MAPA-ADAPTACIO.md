# Mapa d'adaptació

Com es passa de la programació del grup al material d'aquesta carpeta. Les regles concretes
del paper són a [`CRITERIS-DISSENY.md`](CRITERIS-DISSENY.md); aquí hi ha el perquè i el pla.

Material per a alumnat amb dificultats de tipus cognitiu, sobretot de memòria i de raonament
lògic. No hi consta res més, ni ha de constar-hi: el repositori es publica.

---

## 1. El punt de partida

Es descriu com a regles del material, no com a retrat de ningú.

| Què | El material ho resol així |
|---|---|
| **Nombres** | Es llegeixen i s'escriuen bé fins al 999. Cap nombre de l'alumnat no en passa |
| **Càlcul** | Sumes i restes sense portar-ne. Si un càlcul en necessita, es canvien les dades |
| **Taules de multiplicar** | Sempre al davant, a la targeta. Una taula apresa es pot perdre en pocs dies |
| **Lectura** | Frases simples, amb una sola consigna cadascuna |
| **Memòria** | Res no es demana de memòria: el que cal recordar és a les targetes de consulta, que s'acumulen |
| **Raonament lògic** | La regla trencada es desmunta amb el dibuix o el material, mai amb un argument |
| **Símbol de multiplicar** | Coneixen «3 × 4» de primària. El grup fa servir «3 · 4», i el material també |

---

## 2. Les dues aules

La meitat de les hores de matemàtiques són a l'aula de suport i l'altra meitat a l'aula
ordinària.

| | Aula de suport | Aula ordinària |
|---|---|---|
| Qui | Dos professionals de suport | El docent de matemàtiques, amb codocència quan n'hi ha |
| Què s'hi fa | El graó físic, la part de concepte de la fitxa i la consolidació | Els exercicis de la fitxa, al mateix temps que el grup, amb un rol propi dins del grup (apartat 4 bis) |
| Calculadora | Sí, però només per comprovar | No, perquè no hi hagi greuge |
| Targeta de les taules | Sí | Sí: la programació ja la preveu per a tothom |

**L'aula de suport va per davant.** La idea es toca amb material abans que arribi a l'aula
ordinària. Com que la memòria és fràgil, també hi va per darrere: cada sessió comença mirant la
targeta de l'última vegada.

---

## 3. El model de tot el curs: la quadrícula

Un sol dibuix per a tot el curs, i la recta numèrica com a segon (per a l'ordre, els múltiples
com a salts, els decimals i l'arrodoniment). Amb el material que hi ha a l'aula: miniblocs,
quadrícules i geoplà.

| Unitat | Què és la quadrícula | Material |
|---|---|---|
| 1 | Multiplicar és fer un rectangle de quadrets. El quadrat d'un nombre és un quadrat de quadrets | Miniblocs |
| 2 | Els divisors d'un nombre surten dels rectangles que es poden fer amb aquells quadrets. Un primer només en fa un | Miniblocs |
| 3 | L'àrea és comptar quadrets. Mig quadret és 1/2 | Quadrícula |
| 4 | Una fracció d'un nombre és repartir quadrets en grups iguals. Un percentatge és quants quadrets de cada 100 | Miniblocs i quadrícula de 100 |
| 5 | A la quadrícula de 100, una columna és 0,1 i un quadret és 0,01. L'arrel és el costat del quadrat | Quadrícula de 100 i miniblocs |
| 6 | Polígons al geoplà. El perímetre és comptar costats de quadret | Geoplà |
| 7 | Patrons de quadrets: quants en té la figura següent | Miniblocs |

La programació del grup ja fa servir aquest objecte: mapes quadriculats a la unitat 3,
rectangles de 10 per 10 a la 4, quadrats de cartolina a la 5 i geoplans a la 6.

---

## 4. Unitat per unitat

Una unitat per situació d'aprenentatge del grup, amb els mateixos números i títols. El nucli de
cada una és una **proposta**: es valida amb el docent abans d'escriure la fitxa. Les dades són
a [`../dades/unitats.js`](../dades/unitats.js), que és el que llegeix la portada.

| Unitat | Dates del grup | Sessions | Criteris de la SA (referència) | Estat |
|---|---|---|---|---|
| 1 · Nombres naturals | des del 9 de setembre | 13 i un examen | 1.3, 2.1, 8.1 | Feta: targeta de les taules, caixa d'eines, quatre fitxes, els PDF i l'examen |
| 2 · Divisibilitat | 3–19 de novembre | 11 | 1.4, 3.2, 4.2, 5.2 | Feta: caixa (tasques 5 a 8), cinc fitxes, els PDF i l'examen |
| 3 · Com és de gran Gaza? | 23 de novembre – 18 de desembre | 15 | 1.2, 5.2, 6.1, 9.1 | Feta: caixa (tasques 9 a 13), targeta de les fraccions, set fitxes, els PDF i l'examen |
| 4 · És gran l'ou del kiwi? | 12–28 de gener | 11 | 1.3, 2.1, 5.1, 6.1 | Feta: caixa (tasques 14 a 17), cinc fitxes, els PDF i l'examen |
| 5 · Decimals i arrel quadrada | 1–15 de març | 7 i un examen | 5.1, 7.1, 8.1 | Feta: pla validat, caixa (tasques 18 a 21 i la 2.4), targeta «Decimals i arrels», les sis fitxes i l'examen fets |
| 6 · Sentit espacial | 5 d'abril – 10 de maig | 16 | 1.1, 3.1, 5.1, 6.1, 7.1, 9.1 | Feta: pla validat, caixa (tasques 22 a 25), targeta «Formes», les sis fitxes i l'examen fets |
| 7 · Patrons i llenguatge algebraic | 19 de maig – 1 de juny | 6 | 2.1, 3.1, 4.1, 5.1, 7.2 | Feta: pla validat, caixa (tasques 26 a 28), targeta «Patrons i símbols», les cinc fitxes i l'examen fets |

Els codis dels criteris són els de les SA del departament, i quadren, codi i text, amb la llista
oficial que porta la plantilla del Departament d'Educació. L'avaluació d'aquest alumnat es fa
amb els criteris propis del PI.

Les SA del grup són ambicioses (conjectures, algorismes, fraccions amb multiplicació i divisió,
decimals periòdics). De cada una només s'agafa el nucli. La resta no es rebaixa: no hi és.

### 4 bis. El camí mínim, la fita, el rol i l'estat (30/9/2026)

Quatre idees que venen de `4eso/`. Són a [`../dades/unitats.js`](../dades/unitats.js) i surten a
la pàgina de cada unitat, al «detall per al docent» plegat. Es van proposar i fixar el 30/9/2026: el docent va
encarregar tancar-les i fer una revisió de totes les fitxes dels dos cursos (vegeu el final
d'aquest apartat).

**El camí mínim.** Hi ha unitats amb molta feina: la 5 té 33 pàgines per a 7 sessions, i la 7, 25
per a 6. Com que només la meitat de les hores són a l'aula de suport, cada fitxa diu quines pàgines
són el nucli (el camp `minim`) i la resta és ampliació. El criteri: la pàgina 1 (el
concepte i «Què hi veus?») i la primera pàgina d'exercicis de cada fitxa; «A la vida de cada dia»
de la primera fitxa de la unitat; i, al repàs, «Una de cada» i «Què he après?» (a la unitat 7,
també «El meu curs»). Les regles trencades queden a l'ampliació perquè compten per als nivells alts
(regla G). **Cap unitat no passa de dues pàgines per sessió del grup**, i `eines/comprova.py` ho mira.
Dues excepcions al criteri: a la primera fitxa de la unitat 1 també hi entra la pàgina 6 (el
quadrat d'un nombre, que porta a l'arrel), i a la primera de la unitat 3, la pàgina 3 (l'àrea del
rectangle) en lloc de la 2 (les unitats de mesura).

| Unitat | Pàgines | Camí mínim | Sessions del grup |
|---|---|---|---|
| 1 | 27 | 10 | 13 |
| 2 | 30 | 11 | 11 |
| 3 | 37 | 15 | 15 |
| 4 | 24 | 11 | 11 |
| 5 | 33 | 13 | 7 |
| 6 | 30 | 13 | 16 |
| 7 | 25 | 12 | 6 |

**La fita.** El nivell d'assoliment realista de cada unitat (NA, AS, AN, AE), com a `4eso/`.
Fixada: AS a les unitats 1 a 4 (amb AN possible als rectangles de la 1 i a l'àrea de la 3); NA o
AS a la 5 (és on el material se separa més del grup, sense calculadora) i a la 7 (el símbol és el
salt més gran del curs); AS a la 6, amb AN possible a les formes, que són el canal més visual. **Es revisa al desembre**, en acabar la unitat 3, amb la
revisió del PI, i es torna a ajustar al final de cada trimestre.

**El rol a l'aula ordinària.** S'hi adapta el rol dins del grup, no la tasca: qui fa els rectangles
amb els miniblocs, qui compta els quadrets als mapes, qui construeix al geoplà. Un per unitat, i
cada un lligat a una activitat concreta del grup (el GeoGebra de les caixes, els mapes de Gaza, el
kiwi, les Fotomàtiques, el mapa del curs).

**L'estat de cada fitxa.** «Per revisar» (feta, el docent encara no l'ha mirada), «revisada» o
«provada a l'aula». Totes són «revisada»: les de les unitats 5, 6 i 7, fetes el 29/9/2026, es van
revisar el 30/9/2026. **«Provada a l'aula» la posa el docent**, a mà a `dades/unitats.js`, quan una
fitxa s'ha fet servir.

**La revisió del 30/9/2026.** Es van llegir totes les fitxes i targetes de `1eso/` i de `4eso/`,
amb els comptes comprovats un per un. Els errors trobats i arreglats a `1eso/`:

- Unitat 4, fitxa 1, exercici 4 a): deia «en un terç» i el compte era 1/4 de 20. Ara, «una quarta
  part». El solucionari del 4 donava 6 · 4 = 24 en lloc del resultat (1 · 4 = 4).
- Unitat 4, fitxa 4, exercici 3: els dos ous feien 6 cm, i un ou de kiwi en fa uns 12. Ara hi ha
  xifres aproximades reals, i la pregunta és si el kiwi és el doble de gran perquè l'ou ho és.
- Unitat 6, fitxa 1: «Les 1 en punt» és «La una en punt».
- Solucionaris: el repàs de la unitat 3 numerava les fitxes com quan n'hi havia quatre (ara n'hi ha
  sis abans del repàs); a la fitxa 1 de la unitat 3, «4b», «5f» i «5h» per a files sense lletra; a
  l'arrel, els nombres de l'exercici 3 no són de la llista de la 2.4; a la unitat 1, «els exercicis
  8 i 1»; a la 14.2, «una altra confusió propera» en lloc de «girar el numerador i el denominador».
- Anonimat: el repàs de la unitat 7 deia «abans de 2n», i ara «abans del curs que ve».

A `4eso/`: la barra enganyosa de la U6 fa el doble d'alt, no «molt més del doble»; dues frases
deien «Ell» per parlar del rol als productes (U6 i U7); dues concordances («En falten 1», «em
faltarien 1 €»); i el «Per avaluar» dels repassos citava una frase que no surt a cap apartat. Ara
diu la lletra de l'apartat i l'exercici de la regla trencada.

---

## 5. La unitat 1, activitat per activitat

**El pla de la caixa d'eines el va validar el docent el 23 de setembre de 2026: cinc eines.**
Taules, rectangles, quadrats, nombres i ordre de les operacions. La fitxa n'agafa, de moment,
els rectangles i els quadrats (vegeu les decisions, al final de l'apartat).

Les catorze activitats del grup, i què en fa aquest material. «Fitxa» vol dir que hi ha d'anar
quan s'escrigui; la caixa ja hi és.

| Activitat del grup | Què hi fa el grup | Què en fa aquest material | On |
|---|---|---|---|
| 1_1 i 1_3 · Taules de multiplicar | Completar les taules, triar les més difícils de recordar, el número que falta (7 · … = 56) | Les taules no es recorden: es busquen a la targeta. Triar les més difícils de recordar no hi és, perquè res no es demana de memòria. El número que falta es busca a la fila de la targeta | Targeta · caixa 0.1, 0.2 i 0.3 · fitxa 4 |
| 1_4 · Propietats de la multiplicació | Commutativa, el zero, multiplicar per 10 i per 100, distributiva (7 · 101 = 700 + 7) | Commutativa: el rectangle girat. El zero: 0 files, cap quadret. Distributiva: partir pel 10, 3 · 12 = 30 + 6. Per 10 sí; per 100, no: passa de 999 | Caixa 1.1, 1.3 i 1.4 · fitxa 1 |
| 1_5 i 1_15 · Repàs | Els mateixos continguts, i marcar les multiplicacions mal fetes | Els mateixos casos. Marcar les multiplicacions mal fetes, amb la targeta al davant, i una operació de cada tipus de la unitat | Fitxa 4 |
| 1_6 i l'examen de la unitat | Exàmens | Un examen DOCX amb el motor comú, amb la targeta al davant | Per fer |
| 1_7 · El nom d'un nombre | La taula de posicions fins als bilions, escriure el nombre en lletres, la regla del guionet (D-U-C) | Fins al 999: quadrats de 100, columnes de 10 i quadrets solts, la taula de les xifres i el nom en lletres. La regla D-U-C es veu en cada nom | Caixa 3.1 i 3.2 · fitxa 2 |
| 1_8 · Les formes de les potències | Les últimes xifres de les potències de 2 i de 3, i el patró que fan | Fora: les potències passen de 999 | — |
| 1_9 · Potències | Base i exponent, «elevat a», «al quadrat», l'error 3² = 6, les potències de 10 | Només el quadrat: 3² és un quadrat de 3 per 3. L'error 3² = 6 es desmunta amb el dibuix. 10 · 10 = 100 surt als blocs | Caixa 2.1, 2.2 i 3.1 · fitxa 1 |
| 1_11 · Propietats de les potències | El producte de potències de la mateixa base, la potència d'una potència | Fora | — |
| 1_13 · Arrels quadrades | Les exactes, i les no exactes entre dos nombres (√13 és entre 3 i 4) | L'arrel és el costat del quadrat: √16 = 4. Amb 13 quadrets no es fa cap quadrat, i √13 és entre 3 i 4 | Caixa 2.3 · fitxa 1 |
| 1_14 · Jerarquia de les operacions | L'ordre, amb parèntesis, potències, restes i divisions | Sumes i multiplicacions, amb parèntesi i sense. La resta, fora | Caixa 4.1 i 4.2 · fitxa 3 |
| 1_16 · Què he après? | Una autoavaluació de tots els continguts | Una graella semblant, amb tres columnes i les frases en accions que es veuen, amb un exemple a cada una | Fitxa 4 |

**Les fitxes de la unitat 1**, en l'ordre del grup. Una unitat pot tenir més d'una fitxa: així
cada una acompanya el que fa el grup aquells dies, i s'imprimeix a part.

| Fitxa | Què porta | Activitats del grup | Estat |
|---|---|---|---|
| 1 · `ud1.html` | Rectangles de quadrets: llegir-los, pintar-los, girar-los i partir-los; el quadrat d'un nombre; l'arrel com a costat | 1_4, 1_9, 1_13 | Feta |
| 2 · `ud1-nombres.html` | Centenes, desenes i unitats fins al 999, el nom dels nombres i el zero | 1_7 | Feta |
| 3 · `ud1-ordre.html` | L'ordre de les operacions: sumes i multiplicacions, amb parèntesi i sense | 1_14 | Feta |
| 4 · `ud1-repas.html` | Repàs: el número que falta i les multiplicacions mal fetes, amb la targeta; una operació de cada; «Què he après?» | 1_1, 1_3, 1_5, 1_15, 1_16 | Feta |
| Examen · `generadors/examens/ud1.js` | En DOCX, amb el motor comú, amb la targeta al davant: deu exercicis, en l'ordre de l'examen del grup | 1_6 i examen | Fet |

**Queda fora, i per què.** No es rebaixa: no hi és.

- Els nombres de més de 999: els milers, els milions i els bilions de la taula de posicions, i
  multiplicar per 100 i per 1.000 (regla D).
- La propietat associativa: amb un rectangle no es veu, perquè és pla. Caldria una capsa de
  cubs. Si es vol, es pot tocar amb miniblocs a l'aula de suport.
- Les potències que no són quadrats, les seves últimes xifres i les seves propietats.
- A l'ordre de les operacions: les potències, les restes i les divisions.

**Decisions del docent:**

- 23 de setembre de 2026: la caixa d'eines, amb cinc eines.
- 24 de setembre de 2026: la subtasca 0.3, el número que falta. Es fa amb la targeta: la taula
  del número que ja es té, i baixar fins que surt el resultat.
- 24 de setembre de 2026: la fitxa, de moment només amb rectangles i quadrats, per veure com
  queda. Els nombres (centenes, desenes i unitats) i l'ordre de les operacions, de moment, només
  a la caixa.
- 24 de setembre de 2026: la fitxa agrada. L'únic canvi, la lletra manuscrita dels exemples
  resolts, un 30% més gran. Val per a totes les fitxes (regla 4).
- 24 de setembre de 2026: la segona fitxa, centenes, desenes i unitats, per a l'activitat 1_7 del
  grup. Una unitat pot tenir més d'una fitxa.
- 24 de setembre de 2026: la tercera fitxa, l'ordre de les operacions, per a l'activitat 1_14 del
  grup.
- 24 de setembre de 2026: la quarta fitxa, el repàs i «Què he après?», per a les activitats 1_1,
  1_3, 1_5, 1_15 i 1_16 del grup.
- 25 de setembre de 2026: l'examen, en DOCX. Els exercicis 7 i 8 de l'examen del grup
  (propietats de les potències i potències de 10) queden fora.
- 24 de setembre de 2026, després d'una revisió externa: a la 0.1, tota la taula plegada darrere
  d'un botó; a la 3.1, fora les repeticions; `verifica.html`, sense l'evolució dels codis, de
  moment.

---

## 6. La unitat 2, activitat per activitat

**El pla el va validar el docent el 25 de setembre de 2026.** El nucli: els divisors de 12 surten
dels rectangles que es poden fer amb 12 quadrets (1 per 12, 2 per 6 i 3 per 4), i un primer només
en fa un, una fila. Repartir és posar els quadrets en files iguals: si s'omplen, la divisió és
exacta; si no, sobren quadrets, i això és el residu.

Les caixes i les boles del GeoGebra del grup ja són el rectangle (12 caixes de 5 boles són 12
files de 5), i la graella de 100 dels múltiples ja és una quadrícula: el model del curs hi encaixa
sense forçar-lo.

| Activitat del grup | Què hi fa el grup | Què en fa aquest material | On |
|---|---|---|---|
| 2_1 · Múltiples | Llistes de múltiples, pintar-los a la graella de 100 i dir quina forma fan, i reconèixer la graella d'un nombre | Els múltiples són la taula de la targeta. A la graella de 100, els del 2, el 5 i el 10 fan columnes; els del 3 i el 9, diagonals. Els múltiples de 19 i de 600, fora | Caixa 5.1 i 5.2 · fitxa 1 |
| 2_3 · Criteris de divisibilitat | Dividir amb calculadora per veure si surten decimals, i els criteris del 2, 3, 5, 6, 9 i 10 | Sense calculadora. El 2, el 5 i el 10, per l'última xifra, i el 3, sumant les xifres. El 6 i el 9, fora | Caixa 5.3 i 5.4 · fitxa 1 |
| 2_2 · Divisió entera | Caixes i boles al GeoGebra: caixes plenes, divisió exacta, el residu i la igualtat 40 = 6 · 6 + 4 | Files de quadrets: si s'omplen, és exacta; si no, en sobren. La mateixa igualtat, 37 = 5 · 7 + 2 | Caixa 6.1 i 6.2 · fitxa 2 |
| 2_5 · Pràctica de divisors | Repartir caramels i dir si 9 és divisor de 60 i de 63 | El mateix, amb files de quadrets | Caixa 6.2 · fitxa 2 |
| 2_4 · Divisors | Les multiplicacions que donen un nombre (20 = 1 · 20 = 2 · 10 = 4 · 5), les llistes de divisors, i múltiples i divisors d'un mateix nombre | Els rectangles d'un nombre: cada rectangle són dos divisors | Caixa 7.1 i 7.2 · fitxa 3 |
| 2_7 · Eratòstenes, primers i compostos | El garbell fins al 100, primer i compost, el camí de primers i els divisors d'un primer | Un primer només fa un rectangle. El garbell, a la graella de 100, pas a pas | Caixa 8.1 i 8.2 · fitxa 3 |
| 2_5, 2_8 i «ADN dels nombres» · Factorització | Arbres de factors, la factorització amb potències i els nombres fets de peces | Arbres amb la targeta, de nombres amb tres factors primers com a molt (12 = 2 · 2 · 3), sense potències | Fitxa 4 |
| Repàs U2 | Tots els continguts, i el carnet d'identitat de cada nombre (múltiples, divisors i factorització) | El repàs, amb el carnet d'identitat, i «Què he après?» | Fitxa 5 |
| Examen U2 (i la seva adaptació) | Vuit exercicis: múltiples, caixes i boles, divisibilitat, criteris, arbres, primers i carnets | En DOCX, amb el motor comú. L'adaptació que ja existeix serveix de referència de mida | Examen |

**Les fitxes de la unitat 2**, en l'ordre del grup:

| Fitxa | Què porta | Activitats del grup | Estat |
|---|---|---|---|
| 1 · `ud2.html` | Els múltiples: la taula de la targeta, les llistes, la graella de 100, el truc de l'última xifra (2, 5 i 10) i el truc del 3 | 2_1, 2_3 | Feta |
| 2 · `ud2-repartir.html` | Repartir: files plenes, el residu, exacta o no, i la igualtat 37 = 5 · 7 + 2; què vol dir «divisor» | 2_2, 2_5 (pràctica) | Feta |
| 3 · `ud2-divisors.html` | Divisors i primers: els rectangles d'un nombre, múltiples i divisors, primer o no, i el garbell | 2_4, 2_7 | Feta |
| 4 · `ud2-factors.html` | Factorització: arbres amb la targeta, de tres factors primers com a molt; la recepta de cada nombre | 2_5, 2_8, «ADN» | Feta |
| 5 · `ud2-repas.html` | Repàs, el carnet d'identitat d'un nombre i «Què he après?» | Repàs U2 | Feta |
| Examen · `generadors/examens/ud2.js` | En DOCX, amb el motor comú: vuit exercicis, en l'ordre de l'examen del grup | Examen U2 | Fet |

**Queda fora, i per què.** No es rebaixa: no hi és.

- Els nombres de més de 999 (111.111.111, 110.000.001, 10.000…), perquè la regla D ho diu.
- Dividir amb calculadora per veure si surten decimals: el rectangle i la targeta ho diuen sense
  calcular (regla C).
- Els criteris del 6 i del 9, i els múltiples de 19 i de 600.
- Les potències a la factorització (2² · 3 · 5²).
- El GeoGebra: l'eina «Repartir» de la caixa fa el mateix, amb la quadrícula.

**Decisions del docent:**

- 25 de setembre de 2026: el pla, validat: quatre eines noves a la caixa (tasques 5 a 8), cinc
  fitxes i l'examen.
- 25 de setembre de 2026: la factorització hi va, però només amb nombres ben fàcils, de **tres
  factors primers com a molt**, comptant els repetits: 2 · 2 · 3, 3 · 3 · 5, 2 · 3 · 5. Com que
  l'arbre es fa amb la targeta, cada pas ha de ser una multiplicació de la targeta: els nombres
  arriben com a molt al 100.
- 25 de setembre de 2026: la fitxa 1, els múltiples. Per complir la regla 8, la tasca 5.2 de la
  caixa té també els casos de la regla trencada de la fitxa (el 12, el 13, el 21 i el 23).
- 25 de setembre de 2026: la fitxa 2, repartir en files. La igualtat va amb les files plenes al
  primer lloc (37 = 5 · 7 + 2), com a tot el curs; el grup l'escriu al revés (40 = 6 · … + 4), i és
  el mateix, perquè el rectangle es pot girar.
- 26 de setembre de 2026: les fitxes 3 (divisors i primers), 4 (la factorització) i 5 (el repàs), i
  l'examen. A la fitxa 4, a cada partició de l'arbre, el primer a l'esquerra i el que es torna a
  partir a la dreta: així totes les plantilles tenen la mateixa forma. L'«ADN dels nombres» del grup
  s'hi diu «la recepta», perquè les sigles en majúscules no són de Lectura Fàcil.
- 25 de setembre de 2026: el **criteri del 3** hi va, explicat bé i amb calma: és una bona ocasió
  per sumar. La suma de les xifres ha de donar directament un nombre de l'1 al 30, sense haver de
  tornar a sumar (res de 9897 → 33 → 6). Amb nombres de fins al 999 es compleix sempre: com a molt
  fa 9 + 9 + 9 = 27.

**Les regles trencades de la unitat:**

- Múltiples: «un múltiple de 3 acaba en 3». Ho desmunta la graella: el 12 i el 21 ho són, i el 13
  i el 23, no.
- Repartir: «37 entre 7 són 5», sense el residu. El dibuix ensenya que en sobren 2.
- Divisors i primers: «tots els senars són primers». El 9 fa un quadrat de 3 per 3.

---

## 7. La unitat 3: les fraccions, activitat per activitat

**La programació (26/9/2026) diu on van les fraccions.** La situació d'aprenentatge 3, «Com és de
gran Gaza?», les introdueix a partir de l'àrea: les unitats (m, km, m² i km²), l'àrea de rectangles
i de figures irregulars, sumar trossos d'àrea amb fraccions, les equivalents i la suma i la resta, i
al final els km² de Barcelona i de Gaza. La 4, «És gran l'ou del kiwi?», fa servir aquestes
fraccions per a la fracció d'un nombre, la multiplicació i la divisió de fraccions, els dobles i
els triples i els percentatges. El material del grup que hi ha és el de fraccions del curs 2025-26
(l'examen és del 13/3/2026). Es va fer primer com a unitat 4, i el 26/9/2026, amb la programació al
davant, es va passar a la 3. La pestanya d'inclusió de la programació ja proposa el mateix model:
les equivalents, amb cartolines quadriculades.

**El pla el va validar el docent el 26 de setembre de 2026.** El nucli: una fracció és un
rectangle partit en trossos iguals; el denominador diu quants trossos hi ha, i el numerador,
quants se'n pinten. Totes les fraccions es dibuixen amb el mateix rectangle, perquè es puguin
comparar: és el que fan els cercles del grup, però amb la quadrícula del curs.

| Activitat del grup | Què hi fa el grup | Què en fa aquest material | On |
|---|---|---|---|
| Fraccions 0 i 2 | Pintar fraccions, parts iguals, el nom, el valor numèric i la més gran | Pintar trossos d'un rectangle, el numerador i el denominador, i el nom amb la targeta nova | Caixa 9 · fitxa 1 |
| Fraccions 2, 5 i 6 | Comparar, i els tipus: nul·la, pròpia, unitat i impròpia | Comparar amb el mateix rectangle; els tipus, amb un rectangle o més | Caixa 9 i 11 · fitxa 2 |
| Fraccions 3, 5 i 6 | Equivalents: el valor numèric, la multiplicació en creu, amplificar i simplificar | El mateix tros pintat, partit en trossos més petits; amplificar amb la targeta | Caixa 10 · fitxa 3 |
| Fraccions 7 a 12 | Sumar i restar pintant, amb el mateix denominador i amb denominadors diferents | Sempre el mateix denominador, pintant; i un full que explica per què 1/2 + 1/4 no pot donar 2/6 | Caixa 12 · fitxa 4 |
| Repàs i llista de comprovació | Tots els continguts, i el que cal saber fer per a l'examen | El repàs, i «Què he après?» fet a partir de la llista del grup | Fitxa 5 |
| Examen (i les dues adaptacions) | Taula de fraccions, equivalents, irreductibles i sumes | En DOCX, amb el motor comú; la segona adaptació, de referència de mida | Examen |

**Les fitxes de fraccions de la unitat 3**, en l'ordre del grup:

| Fitxa | Què porta | Activitats del grup | Estat |
|---|---|---|---|
| 1 · `ud3.html` | Què és una fracció: el de dalt i el de baix, pintar, el nom amb la targeta; trossos iguals | 0, 2 | Feta |
| 2 · `ud3-compara.html` | Els quatre tipus, comparar amb el mateix de baix i amb el mateix de dalt, i ordenar | 2, 4, 5, 6 | Feta |
| 3 · `ud3-equivalents.html` | Pintar el mateix tros, amplificar amb la targeta, dir si són equivalents i simplificar fàcil | 3, 5, 6 | Feta |
| 4 · `ud3-sumes.html` | Sumar i restar amb el mateix denominador, pintant i sense dibuix; el full de 1/2 + 1/4 | 7, 8, 9 | Feta |
| 5 · `ud3-repas.html` | El carnet de cada fracció, una de cada i «Què he après?» | Repàs i llista de comprovació | Feta |
| Examen · `generadors/examens/ud3.js` | En DOCX, amb el motor comú: vuit exercicis, amb les fraccions en format de fracció | Examen (i les dues adaptacions) | Fet |

**La part de mesura i àrea** (activitats 2 a 5, 8 i 9 de la programació), acabada el 26/9/2026:

| Fitxa | Què porta | Activitats de la programació | Estat |
|---|---|---|---|
| `ud3-area.html` (la primera, en ordre) | Què és més gran, el metre i el quilòmetre, l'àrea del rectangle i les figures amb quadrets sencers i mitjos | 2, 3, 4, 5 | Feta |
| `ud3-mapes.html` (abans del repàs) | Els km² de Barcelona (101) i de Gaza (365) amb quadrícula i contorn esquemàtic, i comparar-los | 8, 9 | Feta |
| Caixa · tasca 13 | L'àrea: comptar quadrets sencers i mitjos, amb la tasca tancada 13.2 | 4, 5 | Feta |
| Examen · exercicis 9 i 10 | L'àrea del rectangle i la unitat de mesura | 3, 4 | Fet |

Els km² es llegeixen com els blocs de la unitat 1: quadrats de 100, columnes de 10 i quadrets
solts. Regles trencades: comptar un mig com un quadret sencer, i «estret vol dir petit».

Les regles trencades de les fitxes: trossos desiguals (fitxa 1), «com més gran és el de baix, més
gran és la fracció» (fitxa 2), sumar el mateix dalt i baix per fer una equivalent (fitxa 3), i
sumar els de dalt i els de baix (fitxa 4, el full que va demanar el docent).

**Queda fora, i per què.** No es rebaixa: no hi és.

- El valor numèric amb decimals (7/8 = 0,875): els decimals són de la unitat 5, i caldria dividir
  amb calculadora (regla C).
- La multiplicació en creu, i les fraccions irreductibles de nombres grans (120/50) amb arbres i
  «jardins».
- Les sumes i restes amb denominadors diferents, que demanen el mínim comú múltiple.
- Els denominadors de més de 12 (trentens, quinzens…), i els cercles i les estrelles: a tot arreu,
  el mateix rectangle.

**Decisions del docent:**

- 26 de setembre de 2026: el pla, validat: quatre eines noves a la caixa (tasques 9 a 12), una
  targeta nova, cinc fitxes i l'examen.
- 26 de setembre de 2026 (vespre): amb la programació, les fraccions passen a la unitat 3. Falta
  completar-la amb la mesura i l'àrea. L'exercici de l'ou del kiwi de la fitxa 1 es canvia per un
  hort partit en trossos iguals, perquè el kiwi és de la unitat 4.
- 26 de setembre de 2026: la mesura i l'àrea, amb el pla validat. «1 km = 1.000 m» hi va com a
  única excepció a la regla dels 999. El mapa de Gaza hi va, amb el contorn esquemàtic i només
  les dades de mesura; el context de la situació es treballa a l'aula.
- 26 de setembre de 2026: la **targeta «Els noms de les fraccions»** hi va: un mig, un terç, un
  quart… fins al dotzè, amb els plurals. El grup les demana de memòria, i la regla B diu que el que
  s'ha de recordar va a una targeta.
- 26 de setembre de 2026: les sumes i restes, **sempre amb el mateix denominador**. I un full que
  expliqui amb el dibuix per què 1/2 + 1/4 no pot ser mai 2/6, sumant els de dalt i els de baix:
  si a mig rectangle hi afegeixes un tros, el resultat és més gran que la meitat, i 2/6 és un terç,
  més petit que la meitat.

**Les regles trencades de la unitat:**

- Comparar: «com més gran és el de baix, més gran és la fracció» (1/5 més gran que 1/3). Amb el
  mateix rectangle, els trossos de 1/5 són més petits.
- Sumar: «se sumen els de dalt i els de baix» (1/4 + 2/4 = 3/8). El dibuix ensenya que són 3/4.

---

## 8. La unitat 4: «És gran l'ou del kiwi?», activitat per activitat

**La programació (SA4, del 12 al 28 de gener, 11 sessions)** fa servir les fraccions de la unitat 3
per a la fracció d'un nombre i d'una fracció, la multiplicació i la divisió de fraccions, els
dobles i els triples i els percentatges, amb el context de l'ou del kiwi: petit en absolut, però
gran en relatiu. La pestanya d'inclusió ja proposa el model: repartir objectes, rectangles
subdividits i quadrícules de 10 × 10 per als percentatges.

**El pla el va validar el docent el 27 de setembre de 2026.** El nucli: una fracció d'un nombre és
repartir els quadrets en grups iguals i pintar-ne els que diu el de dalt; multiplicar dues
fraccions és fer un tros de tros del mateix rectangle; un percentatge és quants quadrets de cada
100; i el doble i el triple es llegeixen en dues files de quadrets, una sota l'altra.

| Activitat del grup | Què hi fa el grup | Què en fa aquest material | On |
|---|---|---|---|
| 1 · És gran o petit? i 2 · De dobles o de triples | Comparar mides, i el doble i el triple | Dues files de quadrets, amb ratlles cada tants quadrets com la fila petita: quantes vegades hi cap | Caixa 17 · fitxa 4 |
| 3 · Fracció d'un nombre | Repartir un nombre en parts i agafar-ne algunes | Repartir els quadrets en grups iguals i pintar-ne els que diu el de dalt; el nombre sempre es reparteix exacte | Caixa 14 · fitxa 1 |
| 4 · Fracció d'una fracció i 5 · Multipliquem fraccions | Multiplicar fraccions | El tros de tros: el mateix rectangle, partit en columnes per a la primera fracció i en files per a la segona. Només amb numerador 1, i el resultat amb denominador fins a 12 | Caixa 15 · fitxa 2 |
| 6 · Dividim fraccions | Dividir fraccions | **Fora**: la divisió de fraccions no té una imatge senzilla amb quadrets | — |
| 7 · Percentatges | Percentatges | Quants quadrets de cada 100 a la graella de 100, i la fracció coneguda: 10 %, 20 %, 25 %, 50 % i 75 % | Caixa 16 · fitxa 3 |
| 8 · Quin percentatge del kiwi és l'ou? | L'ou, com a percentatge del kiwi | **Fora com a càlcul**: demana un percentatge qualsevol. La idea (petit en absolut, gran en relatiu) es treballa, sense càlcul, a la fitxa 4 | Fitxa 4 |
| 9 · Dibuixem monstres | Fraccions multiplicades amb creativitat | **Fora**: activitat lliure de dibuix, que no es pot verificar | — |
| 10 · Projecte final i 11 · Avaluació | Un percentatge d'una foto, i l'avaluació individual | **Fora**: demana quadricular una foto pròpia, massa obert. L'examen ho substitueix amb casos fixos | Examen |
| Repàs | Tots els continguts | El repàs, i «Què he après?» | Fitxa 5 |

El valor decimal de les fraccions (1/8 = 0,125) és de la unitat 5.

**Les fitxes de la unitat 4** (`fitxes/ud4*.html`), en l'ordre de la caixa:

| Fitxa | Què porta | Estat |
|---|---|---|
| 1 · `ud4.html` | La fracció d'un nombre: repartir en grups iguals, pintar-ne 1 i més d'1 | Feta |
| 2 · `ud4-multfrac.html` | Multiplicar fraccions: el tros de tros, i el resultat com a fracció | Feta |
| 3 · `ud4-percentatges.html` | Els percentatges a la graella de 100, i la fracció de cada un | Feta |
| 4 · `ud4-dobletriple.html` | Dobles i triples, amb dues files de quadrets | Feta |
| 5 · `ud4-repas.html` | El repàs de la unitat, i «Què he après?» | Feta |

Els PDF es fan al Codespace amb `generadors/gen_pdf.py`.

**Les decisions, amb data:**

- 27 de setembre de 2026: el pla, validat. Només es multiplica (dividir fraccions queda fora, perquè
  no té una imatge senzilla amb quadrets), els dobles i els triples es llegeixen en una taula de
  dues files, i la unitat té cinc fitxes. Quatre eines noves a la caixa (tasques 14 a 17) i cap
  targeta nova: la de les taules i la dels noms de les fraccions ja hi són.
- 27 de setembre de 2026: la caixa. El tros de tros és una peça nova de `js/quadricula.js`,
  `graella2D`, la primera de dues dimensions: la primera fracció es pinta per columnes, la segona es
  ressegueix per files, i el resultat, on coincideixen, queda pintat i amb un traç gruixut (el
  color no és l'única diferència).
- 27 de setembre de 2026: les fitxes. Quatre casos per pàgina com a màxim: amb dibuixos de grups en
  files, cinc ja no hi caben. El denominador 6 no hi és a la fitxa 1, ni el cas 9 · 2 = 18 a la
  fitxa 4 (la fila no cap amb quadrets prou grans per pintar-hi); tots dos són a la caixa.
- 28 de setembre de 2026: l'examen. La programació no porta cap examen d'aquesta unitat, i l'ordre
  és el de les fitxes. L'únic apartat nou és el 6 d) (el 20 % com a fracció). La comparació de
  l'ou i l'ocell (fitxa 4, exercici 3) hi queda fora: és una valoració qualitativa, i cap pregunta
  de justificació oberta no entra a l'examen.

**Les regles trencades de la unitat:**

- Fracció d'un nombre: repartir en grups desiguals («5, 3 i 4 quadrets» com si fossin tres grups
  iguals). A la caixa, també dir el nombre de grups en lloc dels quadrets d'un grup.
- Multiplicar fraccions: sumar els denominadors en lloc de multiplicar-los (1/2 de 1/3 fet 1 de 5).
  El dibuix n'ensenya 6, de trossos.
- Percentatges: dir el 100 % sense que estigui tot pintat; a la caixa, també dir els quadrets que
  falten en lloc dels que hi ha.
- Dobles i triples: pensar que si un ou fa el doble, l'ocell també fa el doble (l'ou de kiwi fa
  el doble que el de gallina, però el kiwi és més petit que la gallina).

**Revisat el 30/9/2026:** l'exercici 3 de la fitxa 4 portava dos ous de 6 cm, i un ou de kiwi de
veritat en fa uns 12. Ara hi ha xifres aproximades reals: l'ou de kiwi, 12 cm; el de gallina,
6 cm; el kiwi, 40 cm, i la gallina, 50 cm. L'apartat b) pregunta si el kiwi és el doble de gran
perquè l'ou ho és.

---

## 8 bis. La unitat 5: «Decimals i arrel quadrada», activitat per activitat

**El material del grup.** La programació (SA5, de l'1 al 15 de març, 7 sessions) i, des del 29 de
setembre de 2026, el llibre del grup (`llibre_1ESO`, en LaTeX, unitat 5 amb vuit activitats; la
vuitena és un examen). El llibre és el que es fa servir per als casos (regla 8): 3,4 i 3,04, l'error
de la Berta (0,8 i 0,75), 5,86 truncat i arrodonit, 3,47 → 3,5, el √16 = 8 del Joel i √50 entre 7 i
8. Ull per a més endavant: el llibre parteix la SA6 en dues unitats (UD6 formes i UD7 mesura) i la
SA7 hi és la UD8. El material segueix les SA.

**El pla el va validar el docent el 29 de setembre de 2026.** El nucli: el quadrat de 100 quadrets
és 1, com el tot dels percentatges de la unitat 4. Una columna és 0,1 (una dècima) i un quadret és
0,01 (una centèsima): 2,43 es fa amb els mateixos blocs que el 243 de la unitat 1, i 1/4 = 0,25 són
els 25 quadrets del 25 %. L'arrel continua sent el costat del quadrat. El nivell 1 del criteri 5.1 és
justament aquest nucli: decimals exactes ↔ fracció, i √(a²) = a.

| Activitat del grup | Què hi fa el grup | Què en fa aquest material | On |
|---|---|---|---|
| 1 · Què en sabem? Quadrats de cartolina | Diagnòstic, i el costat de quadrats de 9, 16 i 25 | Els quadrats de cartolina són el graó físic de la fitxa de l'arrel | Fitxa 5 |
| 2 · Els decimals | Representar, ordenar, arrodonir i truncar | Els blocs, amb el quadrat de 100 com a unitat; comparar; arrodonir a les dècimes a la recta, i truncar | Caixa 18 i 19 · fitxes 1 i 2 |
| 3 · Operacions amb decimals | Sumar, restar, multiplicar i dividir | Sumar i restar amb la coma sota la coma, sense portar-ne, i amb euros i cèntims. **Multiplicar i dividir, fora** | Caixa 20 · fitxa 3 |
| 4 · De la fracció al decimal | Exactes i periòdics | Les fraccions de denominador 2, 4, 5 i 10 al quadrat de 100, i al revés (0,3 = 3/10). **Els periòdics, fora** | Caixa 21 · fitxa 4 |
| 5 · Quadrats perfectes i arrel | Quadrats perfectes, arrel exacta i no exacta, aproximar amb decimals | Els quadrats de la targeta (fins a 10 · 10), l'arrel com a costat, i les no exactes entre dos nombres. **Aproximar amb decimals, fora** | Caixa 2.3 i 2.4 · fitxa 5 |
| 6 · Mapa conceptual del bloc | Un mapa col·lectiu, i la reflexió emocional | Es fa amb el grup. A la fitxa de repàs, el carnet d'un nombre (fracció, decimal, percentatge i quadrets) en fa el paper | Fitxa 6 |
| 7 · Projecte de les rajoles | Mesurar l'aula i calcular les rajoles | Un plànol quadriculat amb les mesures donades: files per columnes, i si l'última fila és mitja rajola, en cal una de sencera | Fitxa 6 |
| 8 · Examen (només al llibre) | Set exercicis | L'examen, en el mateix ordre | Examen |

**Queda fora, i per què:** multiplicar i dividir decimals, també per 10 i per 100 (no tenen una imatge
senzilla amb quadrets i surten de la targeta), i per això el problema de les pomes; aproximar una
arrel amb decimals (3,1² = 9,61) i les arrels de més de 100 (√144, √169), perquè la targeta acaba a
10 · 10; el truc dels factors 2 i 5 del denominador (nivell 3); mesurar l'aula de debò (el mateix
llibre proposa donar les mesures a l'alumnat amb suports); i la calculadora, que la programació fa
essencial per primer cop: aquí no hi entra (regla C).

**La caixa de la unitat 5**, amb les regles trencades de les fitxes a les tasques tancades:

| Tasca | Què fa | La regla trencada, o la confusió de debò |
|---|---|---|
| 18 · Decimals | 18.1 Fes el decimal (2,43) · **18.2 Quin decimal és?** · **18.3 Quin és més gran?** | 18.2: girar les columnes i els quadrets (3,4 per 3,04) i llegir-lo sense coma (243). 18.3: «més xifres vol dir més gran» (0,75 i 0,8) |
| 19 · Arrodonir | 19.1 El decimal a la recta (3,47) · **19.2 Arrodoneix** | Arrodonir sempre avall, o tallar (3,47 → 3,4); anar amunt quan no toca; arrodonir a les unitats |
| 20 · Sumar decimals | 20.1 Suma i resta (2,5 + 1,35) · **20.2 Quant és?** | Les xifres a la dreta, sense mirar la coma (2,5 + 1,35 = 1,60); sumar el que hi ha després de la coma com si fos igual (5 + 35 = 40, i 3,40) |
| 21 · Fracció i decimal | 21.1 Pinta la fracció (1/4) · **21.2 De fracció a decimal** | El de baix després de la coma (1/4 = 0,4); la barra com una coma (1/4 = 1,4) |
| 2 · Quadrats | **2.4 Entre quins dos nombres?**, al costat de la 2.3 | «L'arrel és la meitat» (√20 entre 10 i 11); passar-se d'un (5 i 6) |

**Les fitxes de la unitat 5** (`fitxes/ud5*.html`), en l'ordre de la programació:

| Fitxa | Què porta | Regla trencada | Estat |
|---|---|---|---|
| 1 · `ud5.html` | Els decimals: llegir-los i escriure'ls amb blocs, el zero que manté el lloc, el valor de cada xifra, i comparar | «Més xifres vol dir més gran» (0,75 i 0,8) | Feta (29/9/2026) |
| 2 · `ud5-arrodonir.html` | Arrodonir i truncar a les dècimes, amb la recta, que és una columna de 10 quadrets ajaguda | Arrodonir sempre avall (3,47 → 3,4): l'Oriol | Feta (29/9/2026) |
| 3 · `ud5-sumes.html` | Sumar i restar amb la coma sota la coma, amb euros i cèntims | No alinear la coma (2,5 + 1,35 = 1,60): la Júlia | Feta (29/9/2026) |
| 4 · `ud5-fraccions.html` | De la fracció al decimal al quadrat de 100, i al revés | 1/4 = 0,4: en Pol | Feta (29/9/2026) |
| 5 · `ud5-arrel.html` | Quadrats perfectes, l'arrel com a costat, i les no exactes entre dos nombres | «L'arrel és la meitat» (√16 = 8): en Joel | Feta (29/9/2026) |
| 6 · `ud5-repas.html` | El carnet d'un nombre, «Una de cada», «Què he après?» i les rajoles | — | Feta (29/9/2026) |

**L'examen** (`generadors/examens/ud5.js`, fet el 29/9/2026): vuit exercicis, en l'ordre de
l'examen del llibre (el valor, l'ordre, arrodonir i truncar, sumar i restar, de fracció a decimal,
l'arrel, els diners i les rajoles). El valor i l'ordre van en dos exercicis perquè cada un sigui d'un
sol tipus. Cada exercici té l'a) resolt i tres apartats per fer, de les fitxes; l'únic «nou» és el
8 d) (3 m per 4,5 m). Les regles trencades són l'«error típic» del solucionari.

**Les decisions, amb data:**

- 29 de setembre de 2026: el pla, validat, amb les tres recomanacions. **Els decimals s'escriuen fins
  a 9,99, amb dues xifres decimals com a molt**: 999 centèsimes, el mateix límit de sempre, amb els
  blocs de la unitat 1 (les mil·lèsimes, com 0,125 = 1/8, en demanarien 1.000). **Els decimals
  periòdics, fora**: el nivell 1 no els demana. **Una targeta nova, «Decimals i arrels»**: una cara
  amb els blocs i els noms (unitat, dècima, centèsima) i l'altra amb les cares d'un nombre (1/2 = 0,5
  = 50 %…) i els quadrats de l'1 al 10. És el «Quadern d'eines» del llibre i la fitxa de quadrats
  perfectes que proposa la pestanya d'inclusió.
- 29 de setembre de 2026: la caixa. Quatre eines noves (tasques 18 a 21) i una subtasca tancada a
  Quadrats (la 2.4): l'arrel ja hi era, a la 2.3. Peces noves a `js/quadricula.js`: `dec` (el
  decimal escrit a partir de les centèsimes), `quadrat100` (pintat per columnes, sense números),
  `recta` (el segon model del curs, per a l'arrodoniment) i els blocs amb una segona part (el
  segon sumand, o el que es resta). `comprova.py` calcula exactes les igualtats amb decimals i vigila
  el límit de 9,99.
- 29 de setembre de 2026: la targeta «Decimals i arrels» (`targetes/decimals.html`, de
  `generadors/fitxes/targeta_decimals.py`). Cara 1, «Els decimals»: les tres peces amb el nom i el
  nombre (1 unitat = 1, 1 dècima = 0,1, 1 centèsima = 0,01), que 10 de les petites fan 1 de les
  grans, 2,43 amb els blocs i la taula de posicions, com es llegeixen 2,43 i 3,04, i les tres regles
  (comparar igualant les xifres, arrodonir a les dècimes, sumar amb la coma sota la coma). Cara 2,
  «Un nombre, moltes cares»: 1/2, 1/4, 3/4, 1/5 i 1/10 al quadrat de 100, amb el decimal i el
  percentatge (els cinc de la unitat 4), i els quadrats i les arrels de 1 · 1 a 10 · 10, amb el
  quadrat de 4 per 4 i dues regles: l'arrel és el costat, no la meitat, i si no és a la llista és
  entre dos nombres. Cap dibuix nou (regla B): els blocs de la unitat 1 i el quadrat de 100 de la
  unitat 4, pintat per columnes com a la caixa.
- 29 de setembre de 2026: la fitxa 1, «Els decimals» (`fitxes/ud5.html`, de
  `generadors/fitxes/fitxa_ud5.py`). És la fitxa de centenes, desenes i unitats de la unitat 1 amb
  els mateixos blocs, ara amb el quadrat de 100 com a unitat. Set pàgines: el model (2,43), mira els
  blocs, escriu les xifres i pinta, què val el 7 (el llibre), marca el decimal (el zero que guarda
  el lloc), quin és més gran (la regla trencada, l'error de la Berta) i la vida (salts, alçades i
  ampolles, i ordenar 2,5, 2,05 i 2,55). El mateix dia, «quadrets sols» de la caixa (tasca 18) va
  passar a «quadrets solts», com a la unitat 1: la mateixa paraula per a la mateixa cosa.
- 29 de setembre de 2026: la fitxa 2, «Arrodonir i truncar» (`fitxes/ud5-arrodonir.html`, de
  `generadors/fitxes/fitxa_ud5_arrodonir.py`). El pont entre els dos models: la recta de 3,4 a 3,5
  és una columna de 10 quadrets ajaguda, un quadret per centèsima (el graó físic és una tira de 10
  quadrets). Cinc pàgines: el model (3,47), marca el decimal a la recta, arrodoneix i trunca (5,86 i
  6,78, del llibre), la regla trencada (l'Oriol sempre arrodoneix avall; l'apartat c, on encerta, és
  a posta) i la vida (alçada, quilòmetres i quilos, i 0,96 → 1,0 per als nivells alts).
- 29 de setembre de 2026: la fitxa 3, «Sumar i restar decimals» (`fitxes/ud5-sumes.html`, de
  `generadors/fitxes/fitxa_ud5_sumes.py`). Es sumen quadrats amb quadrats, columnes amb columnes i
  quadrets amb quadrets: la coma va sota la coma. L'operació en columna té una casella per xifra i la
  coma impresa; s'hi escriuen els dos nombres, amb el zero que iguala (3,2 és 3,20).
  Cinc pàgines: el model (2,5 + 1,35 = 3,85, el cas del llibre), quatre sumes, quatre restes, la regla
  trencada (la Júlia posa les xifres a la dreta; l'apartat c, amb les mateixes xifres decimals, surt
  bé a posta) i la vida amb euros i cèntims (un euro és un quadrat de 100 cèntims). Les operacions en
  columna i les de la Júlia van dins de `.revisa`: l'operació sencera va escrita a la frase del costat,
  i aquesta sí que es comprova.
- 29 de setembre de 2026: la fitxa 4, «De la fracció al decimal» (`fitxes/ud5-fraccions.html`, de
  `generadors/fitxes/fitxa_ud5_fraccions.py`). El quadrat de 100 pintat per columnes, com a la caixa
  i a la targeta. Cinc pàgines: el model (1/4 = 0,25 = 25 %), pinta la fracció i escriu el decimal
  (1/2, 1/5, 3/4 i 3/10), del decimal a la fracció (0,3, 0,7, 0,5 i 0,25), la regla trencada (en Pol
  posa el de baix després de la coma; l'apartat d, 1/10 = 0,1, encerta a posta) i la vida amb
  fraccions d'euro en cèntims.
- 29 de setembre de 2026: la fitxa 5, «Quadrats i arrels» (`fitxes/ud5-arrel.html`, de
  `generadors/fitxes/fitxa_ud5_arrel.py`). L'arrel és el costat del quadrat, com a la unitat 1, i el
  dibuix de les no exactes és el d'allà. Sis pàgines: el model (√16 = 4, amb els quadrats de
  cartolina), compta el costat (9, 25, 36 i 49), l'arrel amb la targeta (√64, √81, √4, √100 i √49,
  del llibre), la regla trencada (en Joel diu que l'arrel és la meitat; amb el 4 encerta a posta),
  entre quins dos nombres (√13, √20, √50 i √90) i la vida (terrenys quadrats en m², i 30 rajoles que
  no fan un quadrat). «Fa» ha passat a «mesura» o «té» (regla I).
- 29 de setembre de 2026: la fitxa 6, el repàs (`fitxes/ud5-repas.html`, de
  `generadors/fitxes/fitxa_ud5_repas.py`). Com el repàs de la unitat 4: el carnet d'un nombre (fa el
  paper del mapa conceptual del grup: fracció, decimal, percentatge i quadrets de 100 del mateix
  nombre), «Una de cada» (un apartat per fitxa), «Què he après?» (vuit frases, amb la taula de on es
  repassa al solucionari) i les rajoles (el projecte del grup, amb un plànol quadriculat i les mesures
  donades: l'última fila de mitges rajoles es compta sencera).
- 29 de setembre de 2026: l'examen (`generadors/examens/ud5.js`). Vuit exercicis en comptes de set: el
  valor i l'ordre, separats. El motor dels exàmens (comú a 1r i 4t) avisa de qualsevol «sencer»; a les
  rajoles es diu «cal una fila més de rajoles» per no tocar-lo.

## 8 ter. La unitat 6: «Sentit espacial», activitat per activitat

**El material del grup.** La programació (SA6, del 5 d'abril al 10 de maig, 16 sessions) i el llibre,
que la parteix en dues unitats: la UD6 (formes: vocabulari, angles, polígons, triangles, GeoGebra,
el mural i les Fotomàtiques) i la UD7 (mesura: magnituds, unitats, superfície, escales, perímetres,
la circumferència i π, àrees). La nostra unitat 6 segueix la programació: la UD6 del llibre, i els
perímetres i la circumferència de la UD7. La resta de la UD7 ja és a la unitat 3 (l'àrea comptant
quadrets, m, km, m², escales) o queda fora.

**El pla el va validar el docent el 29 de setembre de 2026.** El nucli: la cantonada d'un quadret és
l'angle recte (agut, més petit; obtús, més gran; pla, una recta). El perímetre és comptar els costats
de quadret de la vora; l'àrea, de la unitat 3, és comptar els quadrets de dins. Els polígons, al
geoplà, que és una quadrícula de punts.

**La caixa de la unitat 6:**

| Tasca | Què fa | La regla trencada, o la confusió de debò |
|---|---|---|
| 22 · Angles | 22.1 Obre l'angle (amb la cantonada al vèrtex i la llargada dels costats) · **22.2 Quin angle és?** | «Costats més llargs, angle més gran»: la llargada no canvia l'angle |
| 23 · Polígons | 23.1 El polígon al geoplà (set formes) · **23.2 Com es diu?** | «Un quadrat girat ja no és un quadrat»; comptar malament els costats d'un còncau |
| 24 · Triangles | 24.1 Els tres angles (junts fan un angle pla) · **24.2 Quin triangle és?** | «Un triangle més gran té els angles més grans»; un rectangle girat |
| 25 · Perímetre | 25.1 Perímetre i àrea (el rectangle, la vora i els de dins) · **25.2 Quin és el perímetre?** | Donar l'àrea; sumar només dos costats |

**Les fitxes de la unitat 6**, en l'ordre de la programació:

| Fitxa | Què porta | Regla trencada | Estat |
|---|---|---|---|
| 1 · `ud6.html` | Punts, rectes i angles, amb la cantonada del quadret; el rellotge | «Costats més llargs, angle més gran»: en Marc | Feta (29/9/2026) |
| 2 · `ud6-poligons.html` | Polígons al geoplà: costats, vèrtexs, noms, regulars i còncaus; senyals i objectes | «Un quadrat girat ja no és un quadrat»: en Nil | Feta (29/9/2026) |
| 3 · `ud6-triangles.html` | Triangles pels costats (marques) i pels angles; els tres angles fan un angle pla | «Un triangle més gran té els angles més grans»: en Pau | Feta (29/9/2026) |
| 4 · `ud6-perimetre.html` | La vora de figures de quadrets, del rectangle i dels polígons regulars; mateixa àrea, perímetres diferents | Comptar els quadrets de dins (l'àrea): la Carlota | Feta (29/9/2026) |
| 5 · `ud6-cercle.html` | Centre, radi i diàmetre (el doble del radi); la vora, una mica més de 3 vegades el diàmetre | Calcular la vora amb el radi: la Nerea | Feta (29/9/2026) |
| 6 · `ud6-repas.html` | «Una de cada», «Què he après?» i «La meva Fotomàtica» | — | Feta (29/9/2026) |

**Queda fora, i per què:** GeoGebra (la caixa fa de laboratori); el transportador i els graus (els
angles es comparen amb la cantonada; 90° i 180° només com a nom, a la targeta); calcular amb
π = 3,14 (demana multiplicar decimals); la condició d'existència del triangle; la massa i la
capacitat; les àrees amb fórmules i l'àrea del cercle; els polígons estrellats i els mosaics; el
mural i les presentacions, que es fan amb el grup.

**Les decisions, amb data:**

- 29 de setembre de 2026: el pla, validat, amb les tres recomanacions. **Els angles es comparen amb
  la cantonada del quadret**, sense transportador. **La circumferència, només la idea**: radi,
  diàmetre i «una mica més de 3 vegades el diàmetre». **Els lliuraments, en tres passos**: la caixa;
  la targeta i les fitxes 1 a 3; les fitxes 4 a 6 i l'examen. Un sol ZIP per pas.
- 29 de setembre de 2026: la caixa (tasques 22 a 25). Peces noves a `js/quadricula.js`: `angle`
  (amb la cantonada), `geopla`, `triangle` (els angles numerats), `anglesJunts` (els tres angles
  fan un angle pla), `vora` (el perímetre) i els tipus d'angle i de triangle, calculats amb enters.
- 29 de setembre de 2026 (pas 2): la targeta «Formes» (`targetes/formes.html`) i les fitxes 1 a 3
  (`fitxes/ud6.html`, `ud6-poligons.html` i `ud6-triangles.html`). Les peces de dibuix són a
  `generadors/fitxes/peces_geo.py`: l'angle amb la cantonada discontínua, les peces bàsiques, les
  rectes, el geoplà, els polígons regulars, el triangle amb ratlletes i angles numerats, els angles
  junts i el rellotge. La targeta porta també el perímetre i la circumferència, perquè serveixi per a
  tota la unitat. Els casos, del llibre: l'estrella, la regla i la llanterna; el rellotge; els noms de
  3, 5, 8 i 6 costats; els costats 4-4-4, 5-5-8 i 3-4-6; el senyal de perill.
- 29 de setembre de 2026 (pas 3): les fitxes 4 a 6 (`ud6-perimetre.html`, `ud6-cercle.html` i
  `ud6-repas.html`) i l'examen (`generadors/examens/ud6.js`, vuit exercicis en l'ordre de les
  fitxes; els angles de l'exercici 1 són dibuixos amb la cantonada; els apartats «nous» són el 4 d i
  el 7 d). La circumferència té una regla trencada que no era al pla: la Nerea del llibre calcula la
  vora amb el radi. «La meva Fotomàtica», al repàs, és una plantilla per al projecte del grup.

## 8 quater. La unitat 7: «Llenguatge algebraic i patrons», activitat per activitat

**El material del grup.** La programació (SA7, del 19 de maig a l'1 de juny, 6 sessions) i el llibre,
on és la UD8 (7 activitats). Tanca el curs i obre l'àlgebra, però **no fa equacions**: reconèixer
patrons, traduir enunciats a símbols i interpretar gràfics i taules.

**El pla el va validar el docent el 29 de setembre de 2026.** El nucli: els patrons de quadrets, què
hi ha de fix i què s'hi afegeix, i quants en té la figura següent (la taula del 3, els salts de la
recta de la unitat 2). La figura n té a · n + b quadrets. «El triple d'un nombre» s'escriu 3 · n. Un
gràfic de barres són columnes de quadrets.

**La caixa de la unitat 7:**

| Tasca | Què fa | La confusió de debò |
|---|---|---|
| 26 · Patrons | 26.1 El patró (cinc patrons, la figura de l'1 al 10, la taula i la regla) · **26.2 Quants en té la següent?** | Sumar-ne sempre 1; multiplicar per 2 (en Pau del llibre) |
| 27 · Símbols | 27.1 La paraula i el símbol (el dibuix i el càlcul per a una n) · **27.2 Quin és el símbol?** | El triple fet suma (n + 3); el més fet producte (5 · n); al revés (1 − n) |
| 28 · Gràfics | 28.1 Llegeix el gràfic (tres enquestes, una del llibre) · **28.2 Quantes persones?** | Llegir la ratlla de sobre o la de sota |

**Les fitxes de la unitat 7:**

| Fitxa | Què porta | Regla trencada | Estat |
|---|---|---|---|
| 1 · `ud7.html` | Patrons de quadrets: què és fix, què creix, la figura següent; patrons de nombres | En Pau: 2, 4, 6, 8 «creix multiplicant per 2» | Feta (29/9/2026) |
| 2 · `ud7-regla.html` | La taula figura–quadrets i la regla a · n + b; la figura 10 | La Ivet: 5, 8, 11, 14 és 3 · n (oblida la part fixa) | Feta (29/9/2026) |
| 3 · `ud7-simbols.html` | De la paraula al símbol; calcular per a una n | La Zoe: «si n = 3, 2n = 23» | Feta (29/9/2026) |
| 4 · `ud7-grafics.html` | Llegir i fer gràfics de barres de quadrets; el meu gràfic d'una setmana | La barra el doble d'alta amb l'eix que no comença a zero: en Martí | Feta (29/9/2026) |
| 5 · `ud7-repas.html` | Repàs, «El meu curs» (un exemple de cada unitat) i un patró de l'entorn | — | Feta (29/9/2026) |

**Queda fora, i per què:** les equacions (a 2n); Fibonacci i la proporció àuria (ja a la SA2; només
de repte); els gràfics de línia, com el trajecte de la Marta (un altre model); els nombres
triangulars i els termes com n²; Desmos (la caixa en fa el paper); el mapa del curs i la presentació
del dossier, amb el grup.

**Les decisions, amb data:**

- 29 de setembre de 2026: el pla, validat, amb les tres recomanacions. **El producte, sempre amb el
  punt: 2 · n** (la targeta dirà que el grup ho escriu 2n). **Una targeta nova, «Patrons i
  símbols»**. **Només gràfics de barres i taules.** Els lliuraments, en tres passos.
- 29 de setembre de 2026: la caixa (tasques 26 a 28). Peces noves a `js/quadricula.js`: `patro` (la
  part fixa, en taronja, i a files de n quadrets) i `barres` (el gràfic de barres de quadrets). El
  mateix dia, els números dels angles de la tasca 24 (unitat 6) van passar a sobre d'un cercle del
  color del fons: en mode fosc no tenien prou contrast sobre el blau.
- 29 de setembre de 2026 (pas 2): la targeta «Patrons i símbols» (`targetes/patrons.html`) i les fitxes
  1 a 3 (`ud7.html`, `ud7-regla.html` i `ud7-simbols.html`). En paper, la part fixa dels patrons és
  blanca i discontínua (a la caixa, taronja). Les frases «s'hi afegeix» i «quants n'hi ha» de la
  caixa (tasques 26 i 28) han passat a «què creix» i «quantes persones»: sense pronoms febles
  (regla I). La tasca 28.2 ara es diu «Quantes persones?».
- 29 de setembre de 2026 (pas 3): les fitxes 4 i 5 (`ud7-grafics.html` i `ud7-repas.html`) i l'examen
  (`generadors/examens/ud7.js`, vuit exercicis, dos per part; el gràfic de barres, com a imatge; l'únic
  apartat «nou» és el 2 d). La lectura crítica del llibre compara dos cursos; aquí, «classe A» i
  «classe B» (anonimat: cap nom de curs al material). «El meu curs», al repàs, fa el paper del mapa
  conceptual final del grup: una idea i un exemple de cada unitat de l'any. **Amb aquesta, les set
  unitats del curs són fetes.**

---

## 9. L'avaluació

Amb els criteris del PI. Cada solucionari acaba amb «Què mirar per avaluar»: accions que es
veuen, sempre amb la targeta al davant, escrites perquè es puguin passar al PI tal com són.

Mai no s'avalua el que es recorda, sinó el que es fa amb la targeta al davant.

Cada unitat té una **fita realista** (apartat 4 bis) i el PI es revisa **al desembre**, en acabar la
unitat 3: és el moment de mirar si les fites de les unitats 4 a 7 s'han d'ajustar.

---

## 10. Els exàmens

Amb el motor comú, [`../../comu/examens/nucli.js`](../../comu/examens/nucli.js), i les regles de
[`../../comu/docs/EXAMENS-DOCX.md`](../../comu/docs/EXAMENS-DOCX.md), les mateixes que a l'altre
curs. El contingut va a `generadors/examens/udN.js` i les dades privades, a
`generadors/examens-privat.json`, que el `.gitignore` de l'arrel ja deixa fora. Els DOCX surten a
`docx/`, que tampoc no es puja.

El que és propi d'aquest curs: sense calculadora, l'avís és el de la **targeta de les taules**; la
capçalera diu «Matemàtiques», i res no diu «adaptat», tampoc a les propietats del fitxer. Els
apartats surten de les fitxes de la unitat, i un exercici que necessita una clau (el nom dels
nombres) la porta a la mateixa pàgina, com a la fitxa.

**L'examen de la unitat 1** (`generadors/examens/ud1.js`) segueix l'ordre de l'examen del grup:
1 la targeta, 2 el número que falta, 3 girar el rectangle, 4 partir-lo pel 10, 5 el quadrat, 6
l'arrel, 7 entre quins dos nombres (nivells alts), 8 centenes, desenes i unitats, 9 el nom del
nombre i 10 l'ordre de les operacions. Els seus exercicis 7 i 8 (propietats de les potències i
potències de 10) no hi són. Dels quaranta apartats, només dos són nous (el 7c i el 7d).

**L'examen de la unitat 4** (`generadors/examens/ud4.js`): vuit exercicis, dos per cada part de la
unitat i en l'ordre de les fitxes: 1 i 2 la fracció d'un nombre, 3 i 4 el tros de tros, 5 i 6 els
percentatges, 7 i 8 els dobles i els triples. Comparteixen pàgina els exercicis 3 i 4, i el 7 i el
8; els altres van sols, perquè amb les files de fraccions o les graelles no hi caben de dos en dos.
L'exercici 5 té una peça nova, la graella de 100 amb els quadrets pintats (és a `ud4.js`, no al
nucli). Dels trenta-dos apartats, només un és nou (el 6 d). Les regles trencades de les fitxes no
són exercicis apart: són l'«error típic» dels apartats, al solucionari, com a les unitats 2 i 3.

/* ============================================================================
   dades/unitats.js · les set unitats i les targetes de consulta
   ----------------------------------------------------------------------------
   Una unitat per situació d'aprenentatge (SA) de la programació del grup, amb
   els mateixos números i títols. Ho llegeix index.html, i eines/comprova.py
   comprova que el que diu aquí quadri amb el que hi ha al disc.

   Camps d'una unitat:
     num, titol   el número i el títol de la SA del grup
     dates        quan la fa el grup (orientatiu: el calendari no mana)
     sessions     sessions de la SA del grup
     nucli        l'única idea que es treballa, dibuixada a la quadrícula.
                  És una PROPOSTA: es valida unitat per unitat abans d'escriure
                  la fitxa (vegeu docs/MAPA-ADAPTACIO.md)
     material     el graó físic de l'aula de suport, abans de la fitxa
     criteris     els criteris de la SA del grup, com a referència. L'avaluació
                  es fa amb els criteris propis del PI
     fitxes       les fitxes de la unitat, en l'ordre de classe. Cada una té dos
                  camps: fitxa (el camí, fitxes/udN.html) i titol. Una unitat en pot
                  tenir més d'una: la segona i les següents es diuen udN-nom.html.
                  Sense cap, []
     tasques      les tasques de la caixa d'eines de la unitat (caixa-eines?task=n),
                  si en té. eines/comprova.py mira que existeixin

   Camps d'una targeta de consulta:
     id, titol, descripcio, fitxer (l'HTML), pdf, unitat (on neix)
   ========================================================================== */

window.UNITATS = [
  {
    num: 1,
    titol: "Nombres naturals",
    dates: "des del 9 de setembre",
    sessions: "13 i un examen",
    nucli: "Multiplicar és fer un rectangle de quadrets: 3 · 4 són 3 files de 4. " +
           "3² és un quadrat de 3 per 3.",
    material: "Miniblocs: fer el rectangle de 3 per 4 i comptar-ne els quadrets.",
    criteris: "1.3, 2.1, 8.1",
    fitxes: [
      { fitxa: "fitxes/ud1.html", titol: "Rectangles de quadrets" },
      { fitxa: "fitxes/ud1-nombres.html", titol: "Centenes, desenes i unitats" },
      { fitxa: "fitxes/ud1-ordre.html", titol: "L'ordre de les operacions" },
      { fitxa: "fitxes/ud1-repas.html", titol: "Repàs de la unitat i «Què he après?»" }
    ],
    tasques: [0, 1, 2, 3, 4]
  },
  {
    num: 2,
    titol: "Divisibilitat",
    dates: "del 3 al 19 de novembre",
    sessions: "11",
    nucli: "Els divisors de 12 surten dels rectangles que es poden fer amb 12 quadrets. " +
           "Un nombre primer només en fa un: una fila.",
    material: "Miniblocs: fer tots els rectangles de 12, i després els de 7.",
    criteris: "1.4, 3.2, 4.2, 5.2",
    fitxes: [
      { fitxa: "fitxes/ud2.html", titol: "Els múltiples" },
      { fitxa: "fitxes/ud2-repartir.html", titol: "Repartir en files" },
      { fitxa: "fitxes/ud2-divisors.html", titol: "Divisors i primers" },
      { fitxa: "fitxes/ud2-factors.html", titol: "La factorització" },
      { fitxa: "fitxes/ud2-repas.html", titol: "Repàs de la unitat i «Què he après?»" }
    ],
    tasques: [0, 5, 6, 7, 8]
  },
  {
    num: 3,
    titol: "Com és de gran Gaza?",
    dates: "del 23 de novembre al 18 de desembre",
    sessions: "15",
    nucli: "L'àrea és comptar quadrets. Una fracció és un rectangle partit en trossos iguals: " +
           "el de baix diu quants n'hi ha, i el de dalt, quants se'n pinten.",
    material: "Quadrícula i tires de paper: comptar els quadrets d'una figura, ajuntar dues meitats i doblegar una tira en trossos iguals.",
    criteris: "1.2, 5.2, 6.1, 9.1",
    fitxes: [
      { fitxa: "fitxes/ud3-area.html", titol: "Mesurar l'àrea" },
      { fitxa: "fitxes/ud3.html", titol: "Què és una fracció" },
      { fitxa: "fitxes/ud3-compara.html", titol: "Els tipus i comparar" },
      { fitxa: "fitxes/ud3-equivalents.html", titol: "Fraccions equivalents" },
      { fitxa: "fitxes/ud3-sumes.html", titol: "Sumar i restar" },
      { fitxa: "fitxes/ud3-mapes.html", titol: "Quants km²? Barcelona i Gaza" },
      { fitxa: "fitxes/ud3-repas.html", titol: "Repàs de la unitat i «Què he après?»" }
    ],
    tasques: [0, 9, 10, 11, 12, 13]
  },
  {
    num: 4,
    titol: "És gran l'ou del kiwi?",
    dates: "del 12 al 28 de gener",
    sessions: "11",
    nucli: "Un terç de 12 és repartir 12 quadrets en 3 grups iguals. " +
           "Multiplicar dues fraccions és fer un tros de tros del mateix rectangle. " +
           "Un percentatge és quants quadrets de cada 100. " +
           "El doble i el triple es llegeixen en dues files de quadrets, una sota l'altra.",
    material: "Miniblocs: repartir 12 en 3 grups iguals. Quadrícula de 100: pintar-ne 25. " +
              "El tros de tros: un rectangle partit en columnes i en files alhora. " +
              "Dues files de quadrets per comparar mides.",
    criteris: "1.3, 2.1, 5.1, 6.1",
    fitxes: [
      { fitxa: "fitxes/ud4.html", titol: "La fracció d'un nombre" },
      { fitxa: "fitxes/ud4-multfrac.html", titol: "Multiplicar fraccions" },
      { fitxa: "fitxes/ud4-percentatges.html", titol: "Els percentatges" },
      { fitxa: "fitxes/ud4-dobletriple.html", titol: "Dobles i triples" },
      { fitxa: "fitxes/ud4-repas.html", titol: "Repàs de la unitat" }
    ],
    tasques: [14, 15, 16, 17]
  },
  {
    num: 5,
    titol: "Decimals i arrel quadrada",
    dates: "de l'1 al 15 de març",
    sessions: "7",
    nucli: "El quadrat de 100 quadrets és 1: una columna és 0,1 (una dècima) i un quadret és 0,01 " +
           "(una centèsima). 2,43 són 2 quadrats, 4 columnes i 3 quadrets. " +
           "L'arrel és el costat del quadrat.",
    material: "Quadrícula de 100: pintar una columna i un quadret. " +
              "Quadrats de cartolina: buscar el costat d'un quadrat de 9 i de 16 quadrets.",
    criteris: "5.1, 7.1, 8.1",
    fitxes: [
      { fitxa: "fitxes/ud5.html", titol: "Els decimals" },
      { fitxa: "fitxes/ud5-arrodonir.html", titol: "Arrodonir i truncar" },
      { fitxa: "fitxes/ud5-sumes.html", titol: "Sumar i restar decimals" },
      { fitxa: "fitxes/ud5-fraccions.html", titol: "De la fracció al decimal" },
      { fitxa: "fitxes/ud5-arrel.html", titol: "Quadrats i arrels" },
      { fitxa: "fitxes/ud5-repas.html", titol: "Repàs de la unitat" }
    ],
    tasques: [0, 2, 18, 19, 20, 21]
  },
  {
    num: 6,
    titol: "Sentit espacial",
    dates: "del 5 d'abril al 10 de maig",
    sessions: "16",
    nucli: "La cantonada d'un quadret és l'angle recte: agut és més petit, obtús és més gran. " +
           "Polígons al geoplà. El perímetre és comptar els costats de quadret de la vora; " +
           "l'àrea, els quadrets de dins.",
    material: "Geoplà: fer un rectangle i resseguir-ne la vora comptant. " +
              "Un full: la cantonada és l'angle recte.",
    criteris: "1.1, 3.1, 5.1, 6.1, 7.1, 9.1",
    fitxes: [
      { fitxa: "fitxes/ud6.html", titol: "Punts, rectes i angles" },
      { fitxa: "fitxes/ud6-poligons.html", titol: "Polígons" },
      { fitxa: "fitxes/ud6-triangles.html", titol: "Triangles" }
    ],
    tasques: [22, 23, 24, 25, 13]
  },
  {
    num: 7,
    titol: "Patrons i llenguatge algebraic",
    dates: "del 19 de maig a l'1 de juny",
    sessions: "6",
    nucli: "Patrons de quadrets: quants en té la figura següent.",
    material: "Miniblocs: fer les tres primeres figures d'un patró i la quarta.",
    criteris: "2.1, 3.1, 4.1, 5.1, 7.2",
    fitxes: []
  }
];

window.TARGETES = [
  {
    id: "taules",
    titol: "Les taules de multiplicar",
    descripcio: "Les deu taules, en files com les de primària però amb el punt: " +
                "3 · 4 = 12. Es fa servir tot el curs, a les dues aules.",
    fitxer: "targetes/taules.html",
    pdf: "pdf/targeta-taules.pdf",
    unitat: 1
  },
  {
    id: "fraccions",
    titol: "Els noms de les fraccions",
    descripcio: "Del mig al dotzè, amb el plural i el dibuix de cada una. A l'altra cara, " +
                "com es llegeix una fracció, els tipus, les equivalents i com se suma.",
    fitxer: "targetes/fraccions.html",
    pdf: "pdf/targeta-fraccions.pdf",
    unitat: 3
  },
  {
    id: "decimals",
    titol: "Decimals i arrels",
    descripcio: "El quadrat de 100 és 1: la columna és 0,1 i el quadret, 0,01. Com es llegeix un " +
                "decimal, i com es compara, s'arrodoneix i se suma. A l'altra cara, la fracció, el " +
                "decimal i el percentatge al mateix quadrat, i els quadrats i les arrels fins al 100.",
    fitxer: "targetes/decimals.html",
    pdf: "pdf/targeta-decimals.pdf",
    unitat: 5
  },
  {
    id: "formes",
    titol: "Formes",
    descripcio: "La cantonada d'un quadret és l'angle recte: agut, recte, obtús i pla. Punt, segment, " +
                "semirecta i recta. A l'altra cara, els noms dels polígons, els triangles pels costats " +
                "i pels angles, el perímetre i la circumferència.",
    fitxer: "targetes/formes.html",
    pdf: "pdf/targeta-formes.pdf",
    unitat: 6
  }
];

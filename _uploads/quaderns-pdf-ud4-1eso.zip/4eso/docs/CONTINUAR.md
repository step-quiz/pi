# Feina pendent

> **Des del 6/11/2026**, el mapa del lloc, la closca de pantalla (capçalera, botons, colors) i les seves regles són a [`comu/docs/SITE-MAP.md`](../../comu/docs/SITE-MAP.md). Aquest document parla del que és propi d'aquest curs; on parli de pàgines o enllaços d'abans (`fitxes/`, la caixa sencera, `?task=n`, «← unitat N»), mana el mapa.

*(Abans es deia `handout.md`. Conserva la traça del que queda obert.)*

**Per a:** una altra IA (o una altra persona) que reprengui aquest projecte.
**De:** Claude, en una sessió sense accés a la cerca web.
**Data del paquet:** 4 de setembre de 2026.

---

## 0. En una frase

Hi ha material de Matemàtiques Aplicades adaptat per a alumnat amb
dificultats de tipus cognitiu.

> **ACTUALITZACIÓ · 4 de setembre de 2026.** La feina pendent que descrivia l'apartat 4
> **ja està feta**. Es va poder accedir a `mathisvisual.com` i les troballes són a
> `VERIFICACIO-MATHISVISUAL.md`. Les que valien la pena ja estan incorporades al mapa
> (tercera versió). Els apartats 4, 5 i 6 d'aquest handout queden com a registre històric:
> **no cal tornar a fer aquella feina.**
>
> L'única cosa que necessitava el docent, el graó de percentatge de la U2 (apartat 5 del
> mapa), **ja és a la fitxa**: `u2/fitxa.html` porta la barra amb l'escala de 0 a 100 %
> (`BARRA_ESCALA`) entre la barra partida i el factor. Només falta que el docent el doni per
> bo a l'aula.

---

## 1. Context

**L'alumnat.** Dificultats de tipus cognitiu; fa la meitat de les hores de matemàtiques a l'aula de
suport i l'altra meitat a l'aula ordinària. El perfil és molt desigual (la visió gràfica és la via
d'entrada; el càlcul i l'expressió escrita, els colls d'ampolla), i això condiciona tot el material.
El detall és al fitxer privat del docent, fora del repositori (6/11/2026: el repositori i el web són públics).

**El principi de tot el material:** aquest alumnat pot arribar a la *decisió* del nivell del grup, però
no al *càlcul* ni a la *redacció* del nivell del grup. Com que Matemàtiques Aplicades és la matèria de
decidir amb dades, la competència nuclear li és accessible si es descarrega el càlcul a
la calculadora i es basteix l'expressió amb frases model.

**El docent** té el seu propi ecosistema: un llibre digital amb activitats en PDF de 1r a
secundària, un banc d'exercicis autocorrectius (`repas-main`) i les programacions didàctiques
en full de càlcul. El material adaptat s'hi recolza en comptes de substituir-lo.

---

## 2. Què hi ha en aquest paquet

El projecte ja no és una carpeta de fitxers solts: vegeu `docs/ARQUITECTURA.md`.
Els documents que importen són `README.md`, `docs/CRITERIS-DISSENY.md` i
`docs/MAPA-ADAPTACIO.md`.

**El mapa** és el document de referència. Conté el perfil, el principi d'adaptació,
l'articulació suport/aula ordinària, els criteris de disseny, l'inventari i el detall
unitat per unitat amb les fites d'avaluació.

**Les set fitxes** segueixen totes la mateixa estructura: pàgines de concepte sense text
seguit, sis o set exercicis amb el primer apartat ja resolt, i un solucionari per al
professorat amb els errors típics i la traça als criteris d'avaluació.

**L'aplicació** té deu mòduls: Recta, Doble recta, Percentatges, Escales, Paràboles,
Equacions, Calculadora, Com ho dic, Aplanar (U6) i Probabilitat (U7).

---

## 3. Restriccions que NO s'han de trencar

Aquestes no són preferències: són el resultat d'iterar amb el docent, i algunes van
sortir de correccions seves.

**A les fitxes:**

1. **Blanc i negre estricte.** S'imprimeixen en B/N i no se sap com quedaran els colors.
   Cap valor cromàtic a cap fitxa: només negres, blancs i grisos. Les diferències es fan
   amb nivells de gris, gruix de línia i tipus de traç. *Hi ha un test que ho comprova;
   mantén-lo.*
2. **Cap paràgraf a les pàgines de l'alumnat.** El dibuix explica, les paraules només
   etiqueten. El que seria una frase explicativa ha de ser una pantalla de calculadora,
   una barra, una cadena de fletxes o un pictograma.
3. **Consignes completes però curtes**, en imperatiu. «Encercla el nombre que té xifres
   decimals que s'acaben», no «Encercla el que s'acaba». El docent va demanar
   explícitament que fossin una mica més llargues i precises, no telegràfiques.
4. **Cos de 14 pt cap amunt**, molt d'aire, caselles d'1,5 cm per escriure.
5. **El primer apartat de cada exercici, resolt en lletra manuscrita** (classe `.ms`, amb
   una pila de fonts cursives i `cursive` com a últim recurs).
6. **Els gràfics es generen per càlcul**, mai a mà, perquè vèrtexs, barres i marques dels
   eixos caiguin exactament on toca. Els scripts són a `generadors/`.
7. **A cada unitat hi ha «la regla trencada»**: un exercici que trenca la regla que
   l'alumnat s'haurà fabricat als apartats anteriors. Està documentat al mapa, apartat 5.
   És l'evidència d'avaluació més valuosa de cada fitxa. No l'eliminis en simplificar.

**A l'aplicació:**

8. **Fitxer únic, vainilla, sense CDN ni dependències.** El filtre del centre bloqueja
   recursos externs. `localStorage` va dins d'un embolcall protegit.
9. **Cada eina s'obre ja resolta** amb un exemple marcat i un botó que la buida.
10. **Paper i pantalla mostren el mateix cas.** Els 300 € de la U2, el 1:100 amb 8 cm de
    la U3, el `x+3=7` de la U4 i els tres fenòmens de la U5 són idèntics a la fitxa i a
    l'app, perquè no hagi d'aprendre dues vegades el mateix.

---

## 4. La feina pendent, i per què no l'he pogut fer

> **RESOLT.** Vegeu `VERIFICACIO-MATHISVISUAL.md`. Es conserva el que segueix perquè
> explica d'on venien les afirmacions i per què calia comprovar-les.

El docent em va presentar **`https://mathisvisual.com/`** com un recurs que podria
millorar aquests materials. **No hi he pogut accedir.** Ho vaig intentar per dues vies i
totes dues van fallar:

- **No tenia cap eina de cerca web.** El docent va dir que l'activava, però en buscar
  entre les eines disponibles només apareixien les de Google Drive. Cap eina de cerca ni
  de lectura de pàgines.
- **El contenidor bloqueja el domini.** `curl` a `https://mathisvisual.com/` i a
  `https://www.mathisvisual.com/` retorna **403 amb la capçalera
  `x-deny-reason: host_not_allowed`**. La llista de dominis permesos només inclou
  repositoris de paquets (PyPI, npm, GitHub, Ubuntu) i `api.anthropic.com`.

Per tant, **tot el que vaig dir sobre aquell lloc surt de la meva memòria d'entrenament,
no d'haver-lo consultat.** Ho vaig advertir al docent, però queda escrit aquí perquè no
es propagui com si fos verificat.

---

## 5. El que vaig afirmar de memòria i que cal comprovar

| Afirmació | Confiança | Cal verificar |
|---|---|---|
| És un projecte de Kyle Pearce, de l'entorn de Make Math Moments amb Jon Orr | mitjana | autoria i vinculació |
| El seu artefacte central són animacions silencioses, sense narració i amb text mínim | mitjana-alta | format real dels recursos |
| El marc de fons és el *concreteness fading*: concret → visual → simbòlic | mitjana | si ho anomenen així i com ho estructuren |
| Prioritzen models com la recta numèrica doble, les matrius i el model d'àrea | mitjana-baixa | quins models fan servir de debò i en quin ordre |
| Condicions de reutilització del material | **no comprovat** | llicència; no assumeixis que es pot reutilitzar |

**Important:** els dos canvis que vaig fer inspirats en aquesta idea —reordenar les dues
primeres pàgines de la U2 i afegir el model d'àrea a la U6— **no depenen que aquestes
afirmacions siguin certes**. Es fonamenten en didàctica del raonament proporcional i en
el model d'àrea, que estan ben establerts pel seu compte. Si en revisar el web resulta
que la meva memòria era imprecisa, **no desfacis aquests canvis**: revisa'ls, però no els
donis per invàlids.

---

## 6. Què buscar concretament

Quan hi puguis accedir, no cal un resum del lloc. Cal respondre aquestes preguntes:

1. **Quins models visuals fan servir i amb quina freqüència?** Concretament: doble recta
   numèrica, model d'àrea, matrius, barres, taules de raons. Ens interessa saber quins
   models es repeteixen entre temes, perquè per a aquest alumnat **reutilitzar el mateix
   model val més que tenir-ne molts**.
2. **En quin ordre presenten concret, visual i simbòlic?** Hi ha algun pas intermedi que
   nosaltres ens saltem?
3. **Com formulen les preguntes d'obertura?** Si són del tipus «què hi notes», és
   directament aprofitable: l'expressió escrita és el coll d'ampolla, i qualsevol resposta que
   es pugui donar assenyalant o oralment obre la porta.
4. **Tracten percentatges, escales o probabilitat?** Són les nostres U2, U3 i U7, i les
   tres comparteixen ara el mòdul de la doble recta.
5. **Quina és la llicència?** Determina si es pot fer res més que adoptar-ne l'enfocament.

---

## 7. On aniria a parar cada troballa

| Si trobes… | Va a parar a… |
|---|---|
| Un model visual millor per a percentatges | `u2/fitxa.html` pàgines 1-2 i mòdul Doble recta |
| Un model per a escales o raons | `u3/fitxa.html` i mòdul Doble recta |
| Una manera millor de presentar la mitjana ponderada | `u6/fitxa.html` pàgina 4 (model d'àrea) |
| Un model per a probabilitat | `u7/fitxa.html` i mòdul Doble recta |
| Un patró d'obertura silenciosa | totes les pàgines 1 de les fitxes |
| Una progressió d'animació aprofitable | mòduls de l'app, que ja fan revelació pas a pas |

**Els dos buits que tenia l'app,** l'estadística i l'atzar, es van omplir el 30/9/2026 amb
dos mòduls nous: Aplanar (la mitjana de la U6, tasca 8) i Probabilitat (la barra del dau de
la U7, tasca 9). Per a la U7, un arbre interactiu continua sent l'addició natural.

**Un punt pendent i independent d'això:** la disposició de tecles i l'etiqueta `FORMAT`
del mòdul Calculadora estan pendents de contrastar amb una Casio fx-82SP CW real. Hi ha
una constant `SEP_DECIMAL` per si les calculadores del centre estan configurades amb coma
en comptes de punt.

---

## 8. Com regenerar els gràfics

Els SVG estan incrustats a les fitxes, però es generen amb scripts:

```
generadors/gen_grafics.py    → paràboles de la U5
generadors/gen_grafics2.py   → diagrames de punts, barres i arbres de la U6 i la U7
generadors/gen_grafics3.py   → barres de percentatge de la U2 i model d'àrea de la U6
generadors/gen_grafics4.py   → doble recta de la U2, repartiment de la U6, barra d'atzar de la U7
generadors/gen_grafics5.py   → doble recta del mapa (U3) i les dues paràboles de la vida (U5)
generadors/posa_grafics.py   → els executa tots i posa cada gràfic a la seva fitxa
```

> **29/9/2026.** `aplica_millores.py` i els marcadors `§NOM§` ja no hi són. Ara cada gràfic
> va entre `<!--grafic:NOM-->` i `<!--/grafic-->`, i n'hi ha prou amb
> `python3 generadors/posa_grafics.py`. El que segueix és el text d'abans.


Cada script escriu un `.json` amb els SVG i **imprimeix les comprovacions numèriques**
(vèrtexs, talls, sumes, percentatges). Si en modifiques un, mira que les comprovacions
segueixin quadrant abans de tornar a incrustar-los.

Per incrustar-los, les fitxes fan servir marcadors `§NOM§` que se substitueixen pel
contingut del JSON. Els fitxers d'aquest paquet ja tenen les substitucions fetes.

---

## 9. Una última cosa

El docent d'aquest projecte corregeix bé i de pressa. Dues correccions seves que van
canviar el rumb del material, per si serveixen d'orientació sobre com treballa:

- La primera versió de la fitxa de la U1 tenia unes 700 paraules i em va dir que era
  **impossible** que l'alumnat la llegís. Tenia raó, i d'aquí va sortir tot el criteri de
  disseny.
- Va demanar el blanc i negre quan les fitxes ja estaven fetes en color, perquè
  s'imprimeixen així al centre. També tenia raó.

Si dubtes entre fer una cosa i preguntar-la, **fes-la i explica què has decidit i per
què**, però no toquis l'ordre de les pàgines conceptuals d'una fitxa ja validada sense
dir-l'hi: aquesta sí que la va voler aprovar.

---

## 10f. 5/11/2026: la interfície de la unitat i els botons

Canvis de pantalla encarregats pel docent, als dos cursos (`css/tokens.css`, `css/lloc.css`,
`comu/js/unitat.js`):

- **Etiqueta del curs.** Al lloc de la matèria, les pàgines de la unitat, la del curs i la caixa
  d'eines diuen el curs (a 4eso/ amb «Aplicades»; a 1eso/, només el curs). L'excepció a l'anonimat
  és només per a aquestes tres pàgines de cada curs (`comprova.py`, apartat ANONIMAT).
- **Unitat.** Una bombolla (fitxes d'activitats a l'esquerra, quadern a la dreta), la caixa
  d'eines a sota, i dos desplegables sempre plegats: «Més eines» (fitxa de repàs i targetes de
  consulta) i el detall per al professorat.
- **Sense botons PDF a la unitat** (6/11/2026): cada fitxa, repàs i targeta és un únic botó que porta
  a la pàgina HTML, i els PDF es baixen des de la barra de dalt de la fitxa. També són botons els
  enllaços «Per al professorat» de la portada i els `?task=n` de la pàgina del curs.
- **Hover.** Una sola regla a `tokens.css`: vora negra pura de 3 px a tot el que es clica (enllaços,
  botons, pestanyes, `summary`, selectors). Les ombres de hover velles s'han tret.
- **Botons de tornada** («← inici», «← unitat N»): botó 3D petit, amb lletra monoespaiada, cara
  crema, vora blau fosc i cantell blau grisós; es prem 2 px en clicar-hi. Classe `.torna-boto` per
  a un enllaç solt; `.tornar a` i `.navega a:first-child` ja el porten.
- **PDF.** `tokens.css` és una dependència de l'empremta, i només hi he afegit regles que no
  s'apliquen a cap bloc del PDF; per això `empremtes.json` s'ha tornat a calcular i els PDF no
  s'han refet.

## 10f. 6/11/2026: els botons «PDF alumnat» i «PDF solucionari», el quadern de la UD4 i el motor comú

- **Els botons del quadern.** «Imprimeix» i «Imprimeix el solucionari» ara són «PDF alumnat» i
  «PDF solucionari», amb el text, la icona i l'estil de la resta del lloc (decisió del docent).
  Com que el quadern depèn del filtre, no hi ha PDF fets d'abans: cada botó obre el diàleg
  d'imprimir amb el filtre posat («Desa com a PDF»), i el títol de la pestanya, que serà el nom del
  fitxer, acaba en «· alumnat» o «· solucionari».
- **El quadern de la UD4** (`u4/quadern.html`, `generadors/quadern/ud4.py`): 7 blocs, un per
  exercici de la fitxa. La regla trencada (el negatiu que té sentit: el congelador, el pàrquing)
  surt ja entre els tres primers apartats dels blocs 5 i 7. La balança és a `generadors/quadern/peces.py`.
- **El motor és comú.** `generadors/gen_quadern.py` ara només diu el curs; el motor és
  `../comu/generadors/quadern.py`, i el full d'estil, el filtre i les proves també són comuns
  (`../comu/css/quadern.css`, `../comu/js/quadern.js`, `../comu/eines/quaderns.py`,
  `../comu/eines/prova_quadern.py`). Així `1eso/` fa els seus (UD2 i UD3) amb la mateixa màquina.
  `4eso/css/quadern.css`, `4eso/js/quadern.js` i `4eso/eines/prova_quadern.py` ja no existeixen.
- **Pendent:** que el docent revisi i provi a l'aula els quaderns de la UD3 i la UD4.

## 10e. 5/11/2026: l'esquema de navegació curs → unitat → fitxa, quadern o caixa

- **El problema.** La navegació «endavant, enrera, endins, a fora» es trencava: des de la unitat
  s'obria una fitxa, però el «← totes les fitxes» de la fitxa portava a `fitxes.html`, una llista
  plana del curs que se saltava la unitat (i d'allà, «← inici» portava a la pàgina del professorat,
  no a la portada).
- **Què es va fer (decisions del docent).** Cada fitxa, fitxa de repàs, targeta i quadern torna a
  **la seva unitat** («← unitat N»). Les targetes de consulta viuen dins de la unitat on neixen
  (camp `unitats` de `TARGETES`; 1eso/ té el camp `unitat`), i s'obren amb `?ud=N` perquè
  `comu/js/torna.js` les faci tornar a la unitat d'on venen. `fitxes.html` i `quadern.html` (i
  `js/lloc.js`) s'han eliminat: el detall per al docent (camí mínim, fita, regla trencada…) és ara
  plegat a la pàgina de cada unitat (`comu/js/unitat.js`), i les mosaiques «Fitxes» i «Quadern» de
  la pàgina del curs han desaparegut. `404.html` porta les adreces velles a la portada.
- **Generadors.** `gen_repas.py` (aquí) i `generadors/fitxes/peces_comunes.py` (a 1eso/) fan la
  barra de dalt nova; les 60 pàgines ja fetes són idèntiques al que surt dels generadors.
- **Empremtes dels PDF.** La barra de dalt i l'script de les targetes només es veuen a la pantalla
  i no arriben mai al PDF; per això `eines/empremta.py` (i `paper.py` a 1eso/) ja no els compten a
  l'empremta, i els PDF no s'han hagut de tornar a fer. `pdf/empremtes.json` es va tornar a
  calcular una sola vegada.
- **Proves.** `eines/comprova.py`, apartat NAVEGACIÓ (el primer enllaç de cada fitxa, targeta i
  quadern torna a la unitat que toca, i cap pàgina no enllaça les llistes planes), i
  `comu/eines/prova_portada.py` (en un navegador: clica «← unitat» de cada pàgina de cada unitat,
  l'«enrere» i l'«endavant» del navegador, i la branca del professorat).

## 10d. 5/11/2026: el quadern d'activitats de la UD3

- **Què és.** `u3/quadern.html`: activitats per practicar després de la fitxa, un bloc per
  exercici de la fitxa. Cada bloc té una activitat germana i una de repte. El filtre tria
  quants apartats té cada activitat (a) resolt i 3, 6 o 12 per fer) i si hi ha les de repte.
  Es descriu al `README.md`, apartat «El quadern d'activitats». Des de la portada:
  unitat 3 → «Quadern d'activitats» (abans, `index.html` → `quadern.html`, que ja no hi és).
- **Com està fet.** `generadors/gen_quadern.py` és el motor (les peces i la pàgina) i
  `generadors/quadern/ud3.py`, el contingut, amb els números calculats. `eines/comprova.py`
  torna a generar el quadern i avisa si el fitxer de `quadern/` és diferent;
  `eines/prova_quadern.py` prova el filtre al navegador.
- **Decisions del docent (5/11/2026):** un web amb botons, sense PDF fixos; les de repte,
  marcades amb una estrella discreta; començar per la UD3, que és la que fa ara. La primera
  versió doblava el nombre d'activitats de petit a mitjà; el docent la va corregir el mateix
  dia: **mitjà no vol dir el doble d'activitats, sinó el doble d'apartats a cada activitat**
  (petit 3, mitjà 6, elevat 12, sempre amb l'a resolt), i una activitat de repte per bloc que
  creix igual.
- **Pendent:** que el docent el revisi i el provi a l'aula; després, els quaderns de les
  altres sis unitats, amb el de la UD3 com a model.

## 10c. 6/10/2026: «enters», els rètols de precisió i els pendents al dia

- **«Nombres enters», no «sencers».** La fitxa i el repàs de la UD1 i la caixa d'eines deien
  «nombres sencers», i l'examen, «enters», que és el que va decidir el docent en revisar-lo
  (`comu/docs/EXAMENS-DOCX.md`). «Coses senceres» passa a «quantitats enteres, sense
  decimals». `eines/comprova.py` ara ho vigila, com a `1eso/`. PDF de la UD1 i del repàs refets.
- **Les targetes de precisió de la caixa (1.1) diuen el mateix que el paper:** «Ho dic»,
  «Ho compro» i «Ho tallo», com la fitxa i la targeta de la calculadora (regla 8). A sota hi ha
  la frase literal de Lectura Fàcil, que ja hi era. Al mòbil van una sota l'altra: de costat,
  la tercera sortia de la pantalla. `eines/auditoria.py`: 0 problemes en 68 estats.
- **Pendents al dia:** el mòdul d'estadística i d'atzar ja hi és des del 30/9 (vegeu més avall),
  i el `README.md` de l'arrel ja no diu que les unitats 2 a 7 no tenen examen.

## 10b. 30/9/2026: el que 4eso/ agafa de 1eso/

Sis blocs, de la comparativa entre les dues carpetes. Tot passa `eines/comprova.py`,
`eines/mesura.py` i `eines/auditoria.py` (0 problemes en 68 estats i 17 pàgines de paper).
Tot queda tancat el 30/9/2026, per encàrrec del docent: les targetes, els repassos i els apartats
«nou» dels exàmens es van revisar el mateix dia (vegeu més avall).

| Bloc | Què s'ha fet |
|---|---|
| Targetes de consulta | `targetes/`: la calculadora (les cinc seqüències de tecles), percentatges i escales, i paràboles, dades i atzar. Un PDF per targeta, a doble cara |
| Fitxes de repàs | `uN/repas.html`, una per unitat: dibuix de la unitat, «Una de cada» i «Què he après?». Les fa `generadors/gen_repas.py` |
| Exàmens | `generadors/examens/ud2.js` a `ud7.js`, amb el motor comú. Els apartats nous porten «nou» al solucionari |
| Regla G | a les regles trencades de la U2 (5c), la U3 (6c) i la U7 (4c), la refutació és un dibuix: una recta de preus o l'arbre |
| Caixa d'eines | dos mòduls nous: Aplanar (la mitjana de la U6, tasca 8) i Probabilitat (la barra del dau de la U7, tasca 9) |
| La doble recta | declarada model del curs (`CRITERIS-DISSENY.md`, regla 10) i amb el cas «Equació x + 3 = 7» per a la U4 |

**Decidit el 30/9/2026:** les targetes es poden tenir a la taula a l'examen, com a `1eso/` (la
de la calculadora ja ho diu), i el contingut de cada «Una de cada» queda com és: un apartat per
cada tipus d'exercici de la fitxa, amb els comptes comprovats. Els apartats «nou» dels exàmens es van revisar el
30/9/2026, per encàrrec del docent: cada xifra comprovada, i el mateix tipus d'ítem que la fitxa.

**La revisió del 30/9/2026.** Es van llegir totes les fitxes, repassos i targetes dels dos cursos.
A `4eso/` es van arreglar: la barra enganyosa de la U6, que fa el doble d'alt i no «molt més del
doble»; «Ell» en dues frases sobre el rol als productes (U6 i U7), que deien el gènere; dues
concordances («En falten 1», «em faltarien 1 €»); una nota d'història al solucionari de la U3; i
el «Per avaluar» dels repassos, que ara diu la lletra de l'apartat de la regla trencada. La
llista de `1eso/` és a `1eso/docs/MAPA-ADAPTACIO.md`, apartat 4 bis.

---

## 10a. El que s'ha fet en aquesta sessió

Set blocs de feina d'accessibilitat i millora pedagògica. Tot passa `eines/comprova.py`,
`eines/auditoria.py` (0 problemes en 56 estats) i les proves funcionals en Chromium.

| Bloc | Què s'ha fet |
|---|---|
| Retroacció literal | «Correcte.» / «Incorrecte.» sempre amb la mateixa forma, i la pista proposa **un camí diferent**, no repeteix la consigna |
| Passos | rètol `Inici ● ● ○ ○ ○ Final` i «Pas 2 de 5» a cinc tasques; **un sol pas a la vista** |
| Contrast i dianes | paleta de pantalla refeta (17 parelles, clar i fosc), `:focus-visible` a tot arreu, `prefers-reduced-motion` ampliat, botons desactivats que es veuen desactivats |
| Lectura Fàcil | `dades/textos.js` reescrit amb UNE 153101 i literalitat TEA, i el test ho comprova a cada passada |
| Resum i codi | targeta final amb recomptes, codi de verificació imprimible i `verifica.html` per llegir-lo |
| A la vida de cada dia | una pàgina nova a cada fitxa: context real i segona situació per veure si generalitza |
| Teclat | el mòdul Calculadora contrastat amb el manual oficial (EXE, 10 xifres, punt decimal) i operable amb el teclat de l'ordinador |

**Resolt d'aquesta llista:** «si els mòduls acumulen o buiden la pantalla entre passos».
Ara es buida a les Paràboles (i a la resta de tasques amb passos), i el dibuix sencer
només surt al final, com a conclusió.

També s'han fet accessibles amb teclat els dos dibuixos que només es podien tocar: la
recta de l'1.2 (fletxes i Retorn) i la paràbola (un cursor que llisca per la corba amb 40
salts, de manera que cau exactament al vèrtex i als talls).

---

## 10. Estat després de reorganitzar el projecte

El material s'ha convertit en un projecte estàtic amb responsabilitats separades: el CSS
de les fitxes era duplicat set vegades i ara és un sol full; la caixa d'eines era un
fitxer de 63 KB amb tot a dins i ara són vuit mòduls independents que es registren sols.
Res del contingut ha canviat en aquesta reorganització.

**El que continua obert**, per ordre de valor:

> **29/9/2026: el punt 1 és fet.** Els catorze PDF són al dia, amb la pàgina «A la vida de
> cada dia», el model resolt en lletra manuscrita (Caveat, ara dins de `fonts/`), tot el text
> de l'alumnat a 14 pt com a mínim i els rètols dels gràfics a 12 pt com a mínim. De passada,
> es va corregir un error de les paràboles de la U5: quan l'eix no començava en un nombre
> sencer, els números de les marques quedaven desplaçats («−0, 0, 2, 2, 4, 4»), i a les
> gràfiques de «talls = solucions» els talls no queien sobre el seu número. I el model d'àrea
> de la U6 escrivia «pes 0.5» i «6.6» amb punt: ara porta coma, com la taula de la fitxa.

1. **Regenerar els catorze PDF.** Les set fitxes tenen una pàgina nova, «A la vida de cada
   dia», i els PDF de `pdf/` encara no la porten: no s'han pogut regenerar perquè al
   contenidor no hi ha xarxa i WeasyPrint no s'hi pot instal·lar. L'ordre és aquest:

   ```
   pip install weasyprint --break-system-packages
   python3 eines/mesura.py          # cada pàgina ha de cabre en un A4
   python3 generadors/gen_pdf.py    # falla sol si el PDF no té tantes pàgines com blocs
   ```
   
   ```   
   cd /workspaces/pi
   python3 eines/comprova.py        # última passada, ha de dir "Tot correcte."
   git status                       # mira què ha canviat abans de res
   git add -A
   git commit -m "Accessibilitat i generalització: retroacció literal, passos amb principi i final, contrast WCAG 2.2 AA, Lectura Fàcil, resum amb codi de verificació,   pàgina «A la vida de cada dia» i teclat a la calculadora"
   git push
   ```


   Les pàgines noves es van mesurar amb Chromium, que dona alçades un 10 % altes perquè no
   hi ha la font Carlito. Amb aquesta mesura, la més plena és la de la U3 (27,4 cm) i queda
   per sota de quatre pàgines que ja existien i que `mesura.py` ja havia donat per bones
   (fins a 30,3 cm amb el mateix criteri). Tot i així, **qui mana és `mesura.py`**.

1. **El teclat del mòdul Calculadora**, pendent de contrastar amb una Casio fx-82SP CW
   real. El que s'ha corregit amb el manual oficial ja no cal comprovar-ho: la tecla
   d'executar és **EXE** (abans el mòdul deia `=`, que no existeix a l'aparell), la
   pantalla dona 10 xifres (√7 = `2.645751311`, abans en deia 7) i en escriure el decimal
   sempre és un punt. Queda per mirar **amb l'aparell a la mà**:

   - com estan configurades les calculadores del centre (menú CONFIG → Config cálculo →
     Entrada/Salida). El mòdul assumeix `E Mat/S Decimal` a la constant `ENTRADA_SORTIDA`;
     si estan de fàbrica (`E Mat/S Mat`), canvia-la i els casos afegiran sols SHIFT abans
     d'EXE quan el resultat no sigui sencer;
   - si el símbol decimal dels **resultats** és punt o coma (constant `SEP_DECIMAL`);
   - la posició de `√` i de `SHIFT` al mapa del teclat. La tecla `FORMAT` s'ha tret: obre
     un menú del qual no es pot estar segur sense l'aparell, i amb `E Mat/S Decimal` no cal.
2. **Les gràfiques antigues de `gen_grafics.py`.** L'etiqueta de l'eix vertical sortia fora
   del dibuix i es llegia «ra (m)» en comptes de «altura (m)». Està corregit al generador i
   les vuit gràfiques enganxades a `u5/fitxa.html` s'han substituït per les noves. L'única
   que no s'ha pogut substituir és `PILOTA_GRAN` (la de la pàgina 1 de la U5): la versió que
   hi ha a la fitxa no coincideix amb la que genera l'script, segurament perquè es va
   retocar a mà. Si algun dia es regenera, mira-la abans.
3. ~~**No hi ha mòdul d'estadística ni d'atzar.**~~ **FET · 30 de setembre de 2026:** Aplanar
   (la mitjana de la U6, tasca 8) i Probabilitat (la barra del dau de la U7, tasca 9). Per a
   la U7, un arbre interactiu continua sent l'addició natural, i `VERIFICACIO-MATHISVISUAL.md`
   §6 avisa que allà no hi ha res per copiar de fora.
4. **El graó «raó → taxa» de la U3.** Ja hi ha el pas del preu unitari, però es podria
   marcar més com a pas propi.
